package com.demo;



import aidl.client.AidlConnectStateListener;
import aidl.client.AidlEventListener;
import aidl.client.CommonAidlManager;
import aidl.client.R;
import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/*Aidl Client*/
public class MainActivity extends Activity{
	final String TAG = "aidl client";
	
	private Button get;
	private TextView msgTextView;
	private int count = 0;
	

	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		get = (Button) findViewById(R.id.get);
		msgTextView = (TextView) findViewById(R.id.message);

		CommonAidlManager.getInstance().setAidlEventListener(new AidlEventListener() {
			@Override
			public void onEvent(final String data) {
				if(msgTextView != null) {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							msgTextView.append("\n");
							msgTextView.setText(data);
						}
					});
				}
			}

			@Override
			public String getMessageFromClient() {
				return "getMessageFromClient";
			}
		});
		CommonAidlManager.getInstance().setAidlConnectStateListener(new AidlConnectStateListener() {
			@Override
			public void onServiceConnected() {
				//不能在UI线程中执行耗时操作
				new Thread(new Runnable() {
					@Override
					public void run() {
						boolean result = CommonAidlManager.getInstance().sendMessage("do something");
					}
				}).start();
			}

			@Override
			public void onServiceDisconnected() {

			}

			@Override
			public void binderDied() {

			}
		});
		CommonAidlManager.getInstance().connectAidl(getApplicationContext());

		get.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				try{
					// 获取并显示远程Service的状态
					if(CommonAidlManager.getInstance().isBinded()){
						new Thread(new Runnable() {
							@Override
							public void run() {
								boolean result = CommonAidlManager.getInstance().sendMessage("click");
							}
						}).start();
					}else{
						Toast.makeText(getApplicationContext(), "还没连接成功", Toast.LENGTH_SHORT).show();
					}
				}catch (Exception e){
					e.printStackTrace();
				}
			}
		});
	}
	

	
	@Override
	public void onDestroy(){
		super.onDestroy();
        CommonAidlManager.getInstance().destory(getApplicationContext());
	}
}


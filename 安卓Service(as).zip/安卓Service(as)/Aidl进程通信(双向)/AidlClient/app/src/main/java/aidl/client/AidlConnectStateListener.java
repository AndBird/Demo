package aidl.client;

/**
 * 服务端连接状态Listener
 * */
public interface AidlConnectStateListener {
    /**
     * Service连接上
     * */
    public void onServiceConnected();
    /**
     * Service 连接断开
     * */
    public void onServiceDisconnected();
    /**
     * Binder是可能意外死亡的，这往往是由于服务端进程意外停止导致的，此时我们需要重新连接服务
     * */
    void binderDied();
}

package common.aidl.cofig;

public class CommonAidlConfig {
    /**
     * 用于区分aidl调用绑定service和本地绑定service
     * */
    public static final String INTENT_AIDL_KEY = "is_aidl";
    public static final String INTENT_AIDL_KEY_VALUE = "is_aidl_true";

    /**
     * aidl调用权限
     * */
    public static final String COMMON_AIDL_PERMISSION = "com.ly.aidl.permission.REMOTE_SERVICE_PERMISSION";
    /**
     * 远端Service Action
     * */
    public static final String COMMON_AIDL_ACTION = "com.ly.aidl.action.AIDL_SERVICE";
    /**
     * 远端Service应用的包名
     * */
    public static final String REMOTE_SERVICE_PACKAGE = "aidl.service";



}

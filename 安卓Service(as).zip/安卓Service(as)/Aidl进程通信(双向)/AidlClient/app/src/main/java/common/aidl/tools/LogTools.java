package common.aidl.tools;

import android.util.Log;

import java.io.PrintWriter;
import java.io.StringWriter;

public class LogTools {
    private static boolean isDebug = true;

    public static void setDebug(boolean isDebug){
        LogTools.isDebug = isDebug;
    }

    public static void printInfo(String Tag, String msg){
        if(isDebug){
            Log.e(Tag, msg);
        }
    }

    public static void printInfo(String Tag, Throwable ex){
        if(isDebug){
            String msg = null;
            try {
                StringWriter stringWriter = new StringWriter();
                PrintWriter printWriter = new PrintWriter(stringWriter);
                ex.printStackTrace(printWriter);
                msg = stringWriter.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }

            Log.e(Tag, msg);
        }
    }
}

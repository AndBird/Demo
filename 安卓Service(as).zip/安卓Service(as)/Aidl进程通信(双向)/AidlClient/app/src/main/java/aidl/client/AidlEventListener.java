package aidl.client;

/**
 * 服务端消息处理Listener
 * */
public interface AidlEventListener {
    /**
    * 收到服务端消息
    * */
    public void onEvent(String data);

    /**
     * 从Client端取消息
     */
    String getMessageFromClient();
}

package aidl.client;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;

import com.service.aidl.ClientCallBack;
import com.service.aidl.RemoteAidlInterface;
import common.aidl.cofig.CommonAidlConfig;
import common.aidl.tools.LogTools;

/**
 * ip切换控制
 *
 * */
public class CommonAidlManager {
    private static final String TAG = "CommonAidlManager";


    private Context mContext;
    /**
     * 服务端消息处理
     * */
    private AidlEventListener mAidlEventListener = null;
    /**
     * 服务端连接状态
     * */
    private AidlConnectStateListener mAidlConnectStateListener = null;

    /**
     * 当Binder死亡时，是否需要重新绑定服务
     * */
    private boolean mNeedRebindService = true;

    private CommonAidlManager(){}


    private static class CommonAidlManagerInstance{
        private volatile static CommonAidlManager instance = new CommonAidlManager();
    }


    /** Returns singleton class instance */
    public static CommonAidlManager getInstance(){
        return CommonAidlManagerInstance.instance;
    }

    public void init(Context context) {
        this.mContext = context;
    }


    private RemoteAidlInterface mRemoteService;
    private ServiceConnection mConn = new ServiceConnection(){
        @Override
        public void onServiceConnected(ComponentName name, IBinder service){
            // 获取远程Service的onBind方法返回的对象的代理,此方法运行在UI线程中
            LogTools.printInfo(TAG, "onServiceConnected " + name.toString());
            if(service != null){
                //用于将服务端的Binder对象转换为客户端需要的AIDL接口类型的对象
                mRemoteService = RemoteAidlInterface.Stub.asInterface(service);
                LogTools.printInfo(TAG, "onServiceConnected succ");

                try {
                    LogTools.printInfo(TAG, "" + (mRemoteService == null));
                    mRemoteService.registerListener(mClientCallBack);
                    //给binder设置死忙代理，当Binder死忙时就可以收到通知
                    service.linkToDeath(mDeathRecipient, 0);

                    if(mAidlConnectStateListener != null){
                        mAidlConnectStateListener.onServiceConnected();
                    }


                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                //判断Binder是否死忙
                //boolean binderAlive = service.isBinderAlive();
            }else{
                LogTools.printInfo(TAG, "onServiceConnected fail");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name){
            //此方法运行在UI线程中
            LogTools.printInfo(TAG, "onServiceDisconnected");
            mRemoteService = null;
            if(mAidlConnectStateListener != null){
                mAidlConnectStateListener.onServiceDisconnected();
            }
        }
    };


    /**
     * 本地Binder也不能执行耗时操作，否则挡着Service无法响应
     * */
    private ClientCallBack mClientCallBack = new ClientCallBack.Stub() {
        @Override
        public boolean sendMessageToClient(String msg) throws RemoteException {
            LogTools.printInfo(TAG, "ip server msg=" + msg);
            //在Binder池中不能访问UI相关内容
            if(mAidlEventListener != null){
                mAidlEventListener.onEvent(msg);
            }
            return true;
        }

        @Override
        public String getMessageFromClient() throws RemoteException {
            if(mAidlEventListener != null){
                return mAidlEventListener.getMessageFromClient();
            }
            return "Client back";
        }
    };


    private IBinder.DeathRecipient mDeathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
            //Binder是可能意外死亡的，这往往是由于服务端进程意外停止导致的，此时我们需要重新连接服务
            LogTools.printInfo(TAG,  "binderDied");
            try{
                if(mAidlConnectStateListener != null){
                    mAidlConnectStateListener.binderDied();
                }
                if (mRemoteService == null) {
                    return;
                }
                //移除之前绑定的代理,并重新绑定远程服务
                mRemoteService.asBinder().unlinkToDeath(mDeathRecipient, 0);
                mRemoteService = null;

                if(mNeedRebindService) {
                    bindService(mContext);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };


    private void bindService(Context context){
        try{
            LogTools.printInfo(TAG, "bindService");
            // 创建所需绑定的远程Service的Intent
            Intent intent = new Intent();
            intent.putExtra(CommonAidlConfig.INTENT_AIDL_KEY, CommonAidlConfig.INTENT_AIDL_KEY_VALUE);
            //intent.setClassName("aidl.service", "aidl.service.AidlService");
            //"com.aidl.action.AIDL_SERVICE"为远程Service在AndroidManifest.xml中定义的Action
            intent.setAction(CommonAidlConfig.COMMON_AIDL_ACTION);
            // 注意在 Android 5.0以后，不能通过隐式 Intent 启动 service，必须制定包名
            intent.setPackage(CommonAidlConfig.REMOTE_SERVICE_PACKAGE);
            //startService(intent);
            context.bindService(intent, mConn, Service.BIND_AUTO_CREATE);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 绑定Aidl
     *
     * */
    public void connectAidl(Context context){
        if(context != null) {
            this.mContext = context;
            if (mRemoteService == null) {
                bindService(context);
            }
        }else{
            LogTools.printInfo(TAG, "context is null");
        }
    }


    /**
     * 解除服务绑定
     * */
    public void destory(Context context){
        try{
            //解除监听接口
            if (mRemoteService != null && mRemoteService.asBinder().isBinderAlive()) {
                try {
                    mRemoteService.unregisterListener(mClientCallBack);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
            mRemoteService = null;
            // 解除绑定
            if(mConn != null){
                context.unbindService(mConn);
            }
            mConn = null;
            mContext = null;
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public void setAidlEventListener(AidlEventListener aidlEventListener) {
        this.mAidlEventListener = aidlEventListener;
    }


    public void setAidlConnectStateListener(AidlConnectStateListener aidlConnectStateListener) {
        this.mAidlConnectStateListener = aidlConnectStateListener;
    }

    public void setNeedRebindService(boolean needRebindService) {
        this.mNeedRebindService = needRebindService;
    }

    /**
     * 远程服务是否已绑定
     * */
    public boolean isBinded(){
        if(mRemoteService != null){
            return true;
        }
        return false;
    }

    /**
     * 向Server端发送指令
     *
     * @return : true=>发送成功
     * */
    public boolean sendMessage(String msg){
        try {
            if(mRemoteService != null) {
                return mRemoteService.doSomething(msg);
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return false;
    }
}

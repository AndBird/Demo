package com.demo;


import android.content.Intent;
import android.os.IBinder;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import common.aidl.service.CommonAidlService;
import common.aidl.tools.LogTools;

public class AidlServiceDemo extends CommonAidlService {
    private final String TAG = "aidl service";

    private Timer timer;
    private String msg = "远端消息:";
    private int count = 0;


    @Override
    public void onCreate(){
        super.onCreate();
        LogTools.printInfo(TAG, "onCreate");

        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                count++;
                String string = msg + count;
                LogTools.printInfo(TAG, "remote service msg=" + string);
                sendMessageToAidlClient(string);
            }
        }, new Date(), 5000);
    }


    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public void onDestroy(){
        LogTools.printInfo(TAG, "onDestroy");
        super.onDestroy();
        if(timer != null){
            timer.cancel();
            timer = null;
        }
    }
}

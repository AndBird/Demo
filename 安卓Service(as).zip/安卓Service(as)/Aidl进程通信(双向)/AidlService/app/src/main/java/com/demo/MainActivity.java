package com.demo;



import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import aidl.service.R;

/*Aidl Client*/
public class MainActivity extends Activity{
	final String TAG = "aidl client";
	
	private Button get;
	private TextView msgTextView;

	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		get = (Button) findViewById(R.id.get);
		msgTextView = (TextView) findViewById(R.id.message);

		msgTextView.setText("同应用的跨进程通信,参见不同应用的跨进程通信");

	}
}


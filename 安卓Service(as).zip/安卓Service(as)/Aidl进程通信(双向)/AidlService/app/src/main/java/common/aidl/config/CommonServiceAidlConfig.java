package common.aidl.config;

/**
 * Service端配置
 **/
public class CommonServiceAidlConfig {

    /**
     * 允许连接的应用包名,用于权限校验
     * */
    public static final String AUTH_CLIENT_PACKAGE = "aidl.client";
}

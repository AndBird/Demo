package common.aidl.service;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteCallbackList;
import android.os.RemoteException;

import com.service.aidl.ClientCallBack;
import com.service.aidl.RemoteAidlInterface;

import aidl.service.BuildConfig;
import common.aidl.config.CommonAidlConfig;
import common.aidl.config.CommonServiceAidlConfig;
import common.aidl.tools.LogTools;

public class CommonAidlService extends BaseKeepLiveService {
    private static final String TAG = CommonAidlService.class.getSimpleName();

    //intent

    private static CommonAidlService instance = null;

    private MyLocalBinder mMyLocalBinder = new MyLocalBinder();

    /**Service 是否自销毁*/
    private static boolean isStopSelf = false;
    /**是否是第一次onStartCommand*/
    private boolean isFirstOnStartCommand = true;



    /**activity 与服务绑定，回调*/
    private LocalBindActivityUpdateUILinstener mLocalBindActivityUpdateUILinstener;
    /**更新ActivityUI*/
    public interface LocalBindActivityUpdateUILinstener{
        /**
         * 更新
         * */
        public void update(String data);
    }


    public void setLocalBindActivityUpdateUILinstener(LocalBindActivityUpdateUILinstener localBindActivityUpdateUILinstener) {
        this.mLocalBindActivityUpdateUILinstener = localBindActivityUpdateUILinstener;
    }


    @Override
    public IBinder onBind(Intent intent) {
        try {
            if(intent != null && intent.hasExtra(CommonAidlConfig.INTENT_AIDL_KEY)){
                LogTools.printInfo(TAG, "aidl bind");
                //aidl调用
                /* 返回msgBinder对象:
                 * 1.在绑定本地Service的情况下，该msgBinder对象会直接
                 * 传给客户端的ServiceConnection对象的onServiceConnected方法的第二个参数；
                 * 2.在绑定远程Service的情况下，只将msgBinder对象的代理传给客户端的ServiceConnection对象
                 * 的onServiceConnected方法的第二个参数；
                 */

                /*同一个应用的权限校验：onBind()这里只能校验同一个应用多进程权限问题。onBind()是在客户端连接服务端时调用，如果客户端不能在此处通过校验则无发连接到服
                 * 务。如果客户端和服务端是两个应用，则无法在onBind()实现权限校验的功能，这里只能校验同一个应用内的多进程权限。
                 * 两个应用的权限校验应该放置到onTransact()方法中校验
                 * */
                int check = checkCallingOrSelfPermission(CommonAidlConfig.COMMON_AIDL_PERMISSION);
                if (check == PackageManager.PERMISSION_DENIED) {
                    LogTools.printInfo(TAG, "permission deny");
                    return null;
                }
                if(mRemoteClientBinder == null || !mRemoteClientBinder.isBinderAlive()){
                    mRemoteClientBinder = new RemoteClientBinder();
                }
                return mRemoteClientBinder;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        LogTools.printInfo(TAG, "local bind");
        return mMyLocalBinder;
    }

    /**
     * 本地服务绑定binder
     * */
    public class MyLocalBinder extends Binder {
        public CommonAidlService getService() {
            return CommonAidlService.this;
        }

        public String getMessage(){
            return "Local Service";
        }
    }


    /**
     * 远程修改ip的aidl Binder
     * */
    private RemoteClientBinder mRemoteClientBinder = null;
    /**远程client回调对象*/
    private RemoteCallbackList<ClientCallBack> mRemoteClientListenerList = new RemoteCallbackList<ClientCallBack>();

    /**
     * 继承Stub，也就是实现了ICat接口，并实现了IBinder接口
     *
     * */
    public class RemoteClientBinder extends RemoteAidlInterface.Stub{
        @Override
        public void registerListener(ClientCallBack clientCallBack)
                throws RemoteException {
            LogTools.printInfo(TAG, "registerListener");
            try{
                if(mRemoteClientListenerList != null && clientCallBack != null){
                    mRemoteClientListenerList.register(clientCallBack);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        @Override
        public void unregisterListener(ClientCallBack clientCallBack) throws RemoteException {
            LogTools.printInfo(TAG, "unregisterListener");
            try{
                if(mRemoteClientListenerList != null){
                    mRemoteClientListenerList.unregister(clientCallBack);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        @Override
        public boolean doSomething(String something) throws RemoteException {
            LogTools.printInfo(TAG, "service doSomething:" + something);
            return true;
        }


        @Override
        public boolean onTransact(int code, Parcel data, Parcel reply, int flags)
                throws RemoteException {
            //安全校验
            try{
                //包名验证
                LogTools.printInfo(TAG,  "onTransact");
                String packageName = null;
                String[] packages = getPackageManager().getPackagesForUid(getCallingUid());
                if(packages != null && packages.length > 0){
                    packageName = packages[0];
                }
                LogTools.printInfo(TAG, "packageName=" + packageName);
                if(packageName == null || !packageName.startsWith(BuildConfig.APPLICATION_ID) && !packageName.startsWith(CommonServiceAidlConfig.AUTH_CLIENT_PACKAGE)){
                    LogTools.printInfo(TAG, "onTransact 拒绝调用:" + packageName);
                    return false;
                }

                /*权限校验：客户端和服务端是同一个应用的，权限校验在onBind或onTransact中校验都能通过。如果
                 * 客户端和服务端是两个应用时无法在onBind()实现权限校验的问题，此时客户端的权限
                 * 校验可以放在onTransact中校验
                 * */
                int check = checkCallingOrSelfPermission(CommonAidlConfig.COMMON_AIDL_PERMISSION);
                //int check = checkPermission(IpAidlConfig.IP_AIDL_PERMISSION, getCallingPid(), getCallingUid());
                if (check == PackageManager.PERMISSION_DENIED) {
                    LogTools.printInfo(TAG, "onTransact permission deny");
                    return false;
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return super.onTransact(code, data, reply, flags);
        }
    }

    /**
     * 发送消息到客户端
     * */
    protected void sendMessageToAidlClient(String msg){
        try{
            if(mRemoteClientListenerList != null){
                int n = mRemoteClientListenerList.beginBroadcast();
                try {
                    for (int i = 0; i < n; i++) {
                        ClientCallBack listener = mRemoteClientListenerList.getBroadcastItem(i);
                        if (listener != null) {
                            boolean result = listener.sendMessageToClient(msg);
                            LogTools.printInfo(TAG, "client response:" + result);
                        }
                    }
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                mRemoteClientListenerList.finishBroadcast();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Override
    public void onCreate() {
        super.onCreate();
        try {
            LogTools.printInfo(TAG, "onCreate");
            isFirstOnStartCommand = true;
            instance = CommonAidlService.this;
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            LogTools.printInfo(TAG, "onStartCommand");
            //新增进程保活
            //系统将会重新创建服务并依次调用onCreate和onStartCommand（Android2.3.3以下版本只会调用onCreate根本不会调用onStartCommand，Android4.0可以办到）
            //flags =  START_STICKY;
            isFirstOnStartCommand = false;
        }catch (Exception e){
            e.printStackTrace();
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy(){
        LogTools.printInfo(TAG, "stop Service isStopSelf=" + isStopSelf);
        stopServiceSelf(isStopSelf);
        super.onDestroy();

        try{
            //销毁回调资源 否则要内存泄露
            if(mRemoteClientListenerList != null){
                mRemoteClientListenerList.kill();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void reStartService(Context context) {
        startServiceSelf(context);
    }

    /**
     * 启动服务
     *
     * */
    public static void startServiceSelf(Context context){
        if(context != null) {
            LogTools.printInfo(TAG, "startServiceSelf");
            Intent intent = new Intent(context, CommonAidlService.class);
            context.startService(intent);
        }else{
            LogTools.printInfo(TAG, "startServiceSelf fail because context is null");
        }
    }

    /**停止服务*/
    public static void stopServiceSelf(Context context){
        isStopSelf = true;
        if(context != null) {
            context.stopService(new Intent(context, CommonAidlService.class));
        }
    }
}

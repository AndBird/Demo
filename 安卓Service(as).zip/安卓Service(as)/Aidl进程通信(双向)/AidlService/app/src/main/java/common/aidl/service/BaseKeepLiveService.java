package common.aidl.service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.CallSuper;
import android.widget.RemoteViews;

import aidl.service.R;
import common.aidl.tools.LogTools;

public abstract class BaseKeepLiveService extends Service {
    private static final String TAG = BaseKeepLiveService.class.getSimpleName();
    
    private final static int NOTIFICATION_ID = 1018;

    /**Service 是否自销毁*/
    private boolean isStopSelf = false;
    /**是否是第一次onStartCommand*/
    private boolean isFirstOnStartCommand = true;
    /**是否需要进程保活*/
    private final boolean needKeepAlive = false;

  

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LogTools.printInfo(TAG, "onCreate");
        isFirstOnStartCommand = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        LogTools.printInfo(TAG, "onStartCommand");
        //新增进程保活
        //系统将会重新创建服务并依次调用onCreate和onStartCommand（Android2.3.3以下版本只会调用onCreate根本不会调用onStartCommand，Android4.0可以办到）
        //flags =  START_STICKY;
        if(isFirstOnStartCommand) {
            isFirstOnStartCommand = false;
            if(needKeepAlive) {
                startForegroundCompat();
            }
        }
        isFirstOnStartCommand = false;

        if(needKeepAlive) {
            return START_REDELIVER_INTENT;
        }
        return super.onStartCommand(intent, flags, startId);
    }


    @Override
    public void onDestroy(){
        LogTools.printInfo(TAG, "stop Service");
        super.onDestroy();
        LogTools.printInfo(TAG, "isStopSelf=" + isStopSelf);
        if(!isStopSelf){
            //非自销毁，重启， delete 2019.7.16,进程不做保活处理
            if(needKeepAlive) {
                LogTools.printInfo(TAG, "重启服务");
                LogTools.printInfo(TAG, "reStartService");
                reStartService(getApplicationContext());
            }
        }
        isStopSelf = false;
    }



    /**
     * 重启启动服务
     * */
    public abstract void reStartService(Context context);

    /**
     * 设置是否自停止服务
     *
     * 需在super.onDestroy();之前调用stopServiceSelf(isStopSelf);
     * */
    @CallSuper
    public void stopServiceSelf(boolean isStopSelf){
        this.isStopSelf = isStopSelf;
    }


    /**进程保活模块*/
    private void startForegroundCompat() {
        if (Build.VERSION.SDK_INT < 18) {
            // api 18（4.3）以下，随便玩
            startForeground(NOTIFICATION_ID, new Notification());
        } else {
            // api 18的时候，google管严了，得绕着玩
            // 先把自己做成一个前台服务，提供合法的参数
            startForeground(NOTIFICATION_ID, fadeNotification(this));
            // 再起一个服务，也是前台的
            startService(new Intent(this, BaseKeepLiveService.InnerService.class));
        }
    }

    public static class InnerService extends Service {
        @Override
        public void onCreate() {
            super.onCreate();
            LogTools.printInfo(TAG, "$InnerService onCreate");
            // 先把自己也搞成前台的，提供合法参数
            startForeground(NOTIFICATION_ID, fadeNotification(this));

            // 关键步骤来了：自行推掉
            stopSelf();
        }

        @Override
        public void onDestroy() {
            LogTools.printInfo(TAG, "$InnerService onDestroy");
            stopForeground(true);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if(manager != null) {
                manager.cancel(NOTIFICATION_ID);
            }
            super.onDestroy();
        }

        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }
    }

    private static Notification fadeNotification(Context context) {
        Notification notification = new Notification();
        // 随便给一个icon，反正不会显示，只是假装自己是合法的Notification而已
        notification.icon = R.drawable.ic_launcher;
        notification.contentView = new RemoteViews(context.getPackageName(), R.layout.live_service_notification_view);
        return notification;
    }
    /**end 进程保活模块*/
}

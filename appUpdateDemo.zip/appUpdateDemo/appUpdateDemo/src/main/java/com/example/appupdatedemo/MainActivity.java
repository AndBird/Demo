package com.example.appupdatedemo;

import java.io.File;

import com.app.selfupdate.lib.AppUpdateManager;
import com.app.selfupdate.lib.AppUpdateManager.UpdateDataReceiveListener;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import org.json.JSONObject;


public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.e("MainActivity", "onCreate");
		setContentView(R.layout.activity_main);

		AppUpdateManager.getInstance().startCheckUpdate(MainActivity.this, false, UpdateConfig.APP_VERSION_CHECK_URL, new UpdateDataReceiveListener(){
			@Override
			public void analyzeVersionInfo(String data) {
				try {
                    //解析数据这里就不写了

                    //测试数据
                   /* String serverVersion = "2.1";
                    String low_version = "2.0";
                    String downloadUrl = UpdateConfig.downloadUrl;
                    String updateLog = "";
                    //AppUpdateManager.getInstance().setAnalyzeVersionInfo(serverVersion, low_version, UpdateConfig.APP_CUR_VERSION, downloadUrl, updateLog, UpdateConfig.filePath);

                    ArrayList<String> list = new ArrayList<String>();
                    list.add("更新内容1");
                    list.add("更新内容2更新内容更新内容\n更新内容更新内容\n更新内容\n更新内容更新内容更新内容更新内容更新内容");
                    list.add("更新内容3更新内容更新内容\n更新内容更新内容\n更新内容\n更新内容更新内容更新内容\n更新内容更新内容更新内容更新内容更新内容更新内容");
                    AppUpdateManager.getInstance().setAnalyzeVersionInfo2(serverVersion, low_version, UpdateConfig.APP_CUR_VERSION, downloadUrl, list, UpdateConfig.filePath);
                    */

				    if(data != null){
				        JSONObject json = new JSONObject(data);
                        String serverVersion = json.getString("sver");
                        String lowVersion = json.getString("lver");
                        String downloadUrl = json.getString("url");
                        String updateLog = json.getString("des");

                        String curVersion = AppUpdateManager.getVersionName(getApplicationContext());
                        String savePath = Environment.getExternalStorageDirectory().getAbsolutePath()  + File.separator + "Android/data/" + getPackageName() + File.separator;
                        AppUpdateManager.getInstance().setAnalyzeVersionInfo(serverVersion, lowVersion, curVersion, downloadUrl, updateLog, savePath);

                       /* ArrayList<String> list = new ArrayList<String>();
                        list.add("更新内容1");
                        list.add("更新内容2更新内容更新内容\n更新内容更新内容\n更新内容\n更新内容更新内容更新内容更新内容更新内容");
                        list.add("更新内容3更新内容更新内容\n更新内容更新内容\n更新内容\n更新内容更新内容更新内容\n更新内容更新内容更新内容更新内容更新内容更新内容");
                        AppUpdateManager.getInstance().setAnalyzeVersionInfo2(serverVersion, low_version, UpdateConfig.APP_CUR_VERSION, downloadUrl, list, UpdateConfig.filePath);*/
                    }


				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		//直接下载
		//AppUpdateManager.getInstance().startDownload(MainActivity.this, UpdateConfig.downloadUrl, UpdateConfig.filePath, "test.apk");
	}
}

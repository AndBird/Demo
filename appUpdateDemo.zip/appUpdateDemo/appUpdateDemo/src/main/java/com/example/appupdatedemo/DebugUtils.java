package com.example.appupdatedemo;

import android.os.Environment;
import android.util.Log;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.example.appupdatedemo.UpdateConfig;

public class DebugUtils {
	private static String filePath;
	private static boolean LogFlag = false; //日志开关(是否写日志文件)
	private static String LogDir = UpdateConfig.ROOT; //日志文件夹
	private static boolean createLogFlag = false; //是否创建了日志文件
	private static BufferedWriter bw;
	private static FileWriter fw;
	
	public static void setLogPath(String logPath){
		filePath = logPath;
	}
	
	private static void createLog(){
		try {			
			if(filePath == null)
			{
				filePath = Environment.getExternalStorageDirectory().toString() + File.separator + LogDir + File.separator + "log" + File.separator;
			}		
			File logPathFile = new File(filePath);
			if(!logPathFile.exists())
			{
				logPathFile.mkdirs();
			}
			//创建本地日志文件
			Date date = new Date();
			SimpleDateFormat sd1 = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
			String str1 = sd1.format(date);
			final String savePath = filePath + str1 +  "_log.txt";

			File file = new File(savePath);
			if(!file.exists()){
				try {
					file.createNewFile();
				} catch (IOException e) {
					System.out.println("createLog 1111:" + e.toString());
				}
			}
			try {
				fw = new FileWriter(savePath);
				bw = new BufferedWriter(fw);
			} catch (IOException e) {
				System.out.println("createLog 2222:" + e.toString());
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public static void closeFile(){
		try {
			if(LogFlag){
				createLogFlag = false;
				if(bw != null){
					bw.flush();
					bw.close();
				}
				if(fw != null){
					fw.close();
				}
			}
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	public static void debug(String TAG, String msg){
		if(UpdateConfig.isDebug){
			Log.e(TAG, msg);
			if(LogFlag){
				if(!createLogFlag){
					createLog();
					createLogFlag = true;
				}
				Date date = new Date();
				SimpleDateFormat sd1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				String str1 = sd1.format(date);
				try {
					bw.write("【" + str1 + "】 " + TAG + "  msg=" + msg);
					bw.newLine();
					bw.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}catch(Exception e){
					
				}
			}
		}
	}
	
	
	public static void printInfo(String Tag, String msg){
		if(UpdateConfig.isDebug){
			Log.e(Tag, msg);
			if(LogFlag){
				debug(Tag,  msg);
			}
		}
	}
}

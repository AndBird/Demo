package com.app.selfupdate.lib;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;


/*下载apk*/
public class AppUpdateManager{
	private static final String TAG = AppUpdateManager.class.getSimpleName();
	/**取消更新退出app*/
	public static final String UPDATE_CANCEL_EXIT_APP = "exit_app";

	/**检测失败*/
	private final int CHECK_UPDATE_FAIL = 201;
	/**最新版本，无需更新*/
	private final int CHECK_UPDATE_LATEST = 202;
	/**更新失败，没有网络*/
	private final int NO_NETWORK = 203;
	
	/**下载失败*/
	public static final int Download_STATUS_FAILED = 1;
	/**下载成功*/
	public static final int Download_STATUS_SUCCESSFUL = 2;
	/**正在下载中*/
	public static final int Download_TATUS_RUNNING = 3;
	
	private static volatile AppUpdateManager instance = null;
	private Context mContext;
	
	//更新相关

	/**更新检测地址*/
	private String updateCheckUrl;
	/**下载保存目录*/
	private String saveDir;
	/**下载完整路径*/
    private String saveFilePath;
	/**下载文件名*/
    private String saveFileName;
    
    /**下载线程*/
    private Thread downLoadThread;
	/**停止下载*/
    private boolean stopDownload = false;

	/**更新下载地址*/
    private String downloadUrl = "";
	/**服务器最新版本号*/
    private String serverVersionName;
	/**要求最低版本号，用于强制更新*/
    private String lowVersionName;
	/**当前版本号*/
    private String curVersionName;
	/**强制更新*/
    private boolean force_update;
	/**更新内容*/
    private String updateLog;
	/**更新内容*/
    private ArrayList<String> updateLogList;
	/**app更新包的大小*/
    private int appTotalSize = -1;
    
    private ProgressDialog downloadDialog;
	/**正在检测更新*/
    private boolean checkUpdating = false;
	/**是否显示下载对话框(用于手动检测更新)*/
    private boolean canShowDialog = false;
	/**是否允许断点下载*/
    private boolean allowBreakPointDownload = false;
	/**是否显示检测结果Toast*/
    private boolean showCheckToast = false;
	/**正在下载中*/
    private boolean downloading = false;


    //本地保存key
	/**服务器当前的版本号key*/
    public final static String VERSION_SERVER = "server_version";
	/**保存的服务器版本号是否是最新获取的 key*/
    public final static String VERSION_IS_NOW = "verson_is_now";
	/**下载地址*/
    public final static String DOWNLOAD_URL = "download_url";

	/**下载进度更新，其他页面*/
    private Handler mUpdateHandler = null;
    
    private UpdateDataReceiveListener mUpdateDataReceiveListener = null;
    public interface UpdateDataReceiveListener{
		/**更新信息解析，用于不同的网络地址不同的数据结构*/
    	public void analyzeVersionInfo(String data);
    }

	private final MyHandler mHandler = new MyHandler(this);
	private static class MyHandler extends Handler {
		private final WeakReference<Object> mActivity;

		public MyHandler(Object activity) {
            super(Looper.getMainLooper());
			mActivity = new WeakReference<Object>(activity);
		}

		@Override
		public void handleMessage(Message msg) {
			if(mActivity.get() instanceof AppUpdateManager){
				AppUpdateManager activity = (AppUpdateManager) mActivity.get();
				if (activity != null) {
					activity.handleMessage(msg);
				}
			}
		}
	}
    
    public static AppUpdateManager getInstance(){
    	if (instance == null) {
			synchronized (AppUpdateManager.class) {
				if (instance == null) {
					instance = new AppUpdateManager();
				}
			}
		}
		return instance;
    }
    
    private AppUpdateManager(){
    	init();
    }
    
    /**
     * 供直接下载用(比如手动更新)
     * @param downloadUrl : 下载地址
     * @param saveDir: 下载保存目录(详细路径)
     * @param fileName: 保存文件名
     * */
	public void startDownload(Context context, String downloadUrl, String saveDir, String fileName){
		this.mContext = context;
		this.downloadUrl = downloadUrl;
		this.saveDir = saveDir;
		this.saveFileName = fileName;
		if(saveDir.endsWith("/")){
			saveFilePath =  saveDir + saveFileName;
		}else{
			saveFilePath =  saveDir + File.separator + saveFileName;
		}
		LogUtil.printLogE(TAG, "this.downloadUrl = " + this.downloadUrl);
		LogUtil.printLogE(TAG, "saveFilePath = " + saveFilePath);

		if(context != null && context instanceof Activity) {
			this.canShowDialog = true;
		}else{
			this.canShowDialog = false;
		}
		startDownload();
	}
	
	private void init(){
		this.checkUpdating = false;
		this.canShowDialog = false;
		this.downloading = false;
		this.allowBreakPointDownload = false;
	}
	
	private void initParams(Context context, boolean showCheckToast, String updateCheckUrl, UpdateDataReceiveListener updateDataReceiveListener){
		this.mContext = context;
		this.showCheckToast = showCheckToast;
		this.updateCheckUrl = updateCheckUrl;
		this.mUpdateDataReceiveListener = updateDataReceiveListener;
	}


	
    private void handleMessage(Message msg){
        switch (msg.what) {
            case Download_TATUS_RUNNING://下载进度更新
                int progress =(byte)(((float)msg.arg1 / appTotalSize) * 100);
                if(downloadDialog != null){
                    downloadDialog.setProgress(progress);
                }
                break;
            case Download_STATUS_SUCCESSFUL:
                if(downloadDialog != null){
                    downloadDialog.dismiss();
                    downloadDialog = null;
                }
                if(canShowDialog){
                    showInstallDialog();
                }else{
                	//直接安装
					AppUpdateManager.getInstance().installApk();
				}
                break;
            case Download_STATUS_FAILED:
                if(downloadDialog != null){
                    downloadDialog.dismiss();
                    downloadDialog = null;
                }
                Toast.makeText(mContext, R.string.download_fail, Toast.LENGTH_SHORT).show();
                break;
            case CHECK_UPDATE_FAIL:
                if(showCheckToast){
                    Toast.makeText(mContext, R.string.update_fail, Toast.LENGTH_SHORT).show();
                }
                break;
            case CHECK_UPDATE_LATEST:
                if(showCheckToast){
                    Toast.makeText(mContext, R.string.current_version_is_newest, Toast.LENGTH_SHORT).show();
                }
                break;
            case NO_NETWORK:
                Toast.makeText(mContext, R.string.no_network, Toast.LENGTH_SHORT).show();
                break;
			default:
				break;
        }
	}
	
    /**
     * 
     * 开始版本检测
     * @param showCheckToast : 是否显示检测提示
     * @param updateCheckUrl : 检测更新地址
     * @param updateDataReceiveListener: 检测更新数据分析回调
     * 
     * */
    public void startCheckUpdate(Activity context, boolean showCheckToast, String updateCheckUrl, UpdateDataReceiveListener updateDataReceiveListener){
    	try {
    		LogUtil.printLogE(TAG, "startCheckUpdate");
    		initParams(context, showCheckToast, updateCheckUrl, updateDataReceiveListener);
    		 //检测更新
            SharePreferenceTool.setPrefBoolean(context, VERSION_IS_NOW, false);//先重置保存的版本号是否是最新标记
            if(NetTool.isNetworkConnected(context)){
            	if(checkUpdating){
    				LogUtil.printLogE(TAG, "startCheckUpdate: has another Thread checkUpdating");
    				return;
    			}
            	new Thread(new Runnable() {
        			@Override
        			public void run() {
        				checkUpdate();
        			}
        		}).start();
            }else{
            	Toast.makeText(context, R.string.no_network, Toast.LENGTH_SHORT).show();
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
	private void checkUpdate(){
		try{
			LogUtil.printLogE(TAG,"checkUpdate");
			checkUpdating = true;
			String versionInfo = getVersionInfoFromServer();
			LogUtil.printLogE(TAG, "ServerVersionInfo:" + versionInfo);
			if(versionInfo != null){
				LogUtil.printLogE(TAG, "getupdateinfo = " + versionInfo);
				if(mUpdateDataReceiveListener != null){
					mUpdateDataReceiveListener.analyzeVersionInfo(versionInfo);
				}
				LogUtil.printLogE(TAG, "serverVersionName = " + serverVersionName + " lowVersionName=" + lowVersionName);
					
				if(serverVersionName == null || lowVersionName == null || downloadUrl == null || curVersionName == null){
					checkUpdating = false;
					return;
				}

				//保存最新版本号
				SharePreferenceTool.setPrefString(mContext, VERSION_SERVER, serverVersionName);
				SharePreferenceTool.setPrefBoolean(mContext, VERSION_IS_NOW, true);//先重置保存的版本号是否是最新标记
				SharePreferenceTool.setPrefString(mContext, DOWNLOAD_URL, downloadUrl);//保存下载地址
					
				if(compareVersion(curVersionName, serverVersionName) != -1){
					LogUtil.printLogE(TAG, "checkUpdate() 不需要更新");
					mHandler.sendEmptyMessage(CHECK_UPDATE_LATEST);
				}else{
					LogUtil.printLogE(TAG, "checkUpdate() 需要更新");
					//判断是不是必须更新
					int result = compareVersion(lowVersionName, curVersionName);
					if(1 == result){
						force_update = true;
					}else{
						force_update = false;
					}
					if(force_update){
						LogUtil.printLogE(TAG, "checkUpdate() 强制更新");
					}else{
						LogUtil.printLogE(TAG, "checkUpdate() 非强制更新");
					}
					if(TextUtils.isEmpty(saveFilePath) || TextUtils.isEmpty(saveFileName)){
						this.saveFileName = mContext.getPackageName() + "_" + serverVersionName + ".apk";
						if(saveDir.endsWith("/")){
							saveFilePath =  saveDir + saveFileName;
						}else{
							saveFilePath =  saveDir + File.separator + saveFileName;
						}
					}
					LogUtil.printLogE(TAG, "checkUpdate() saveFilePath=" + saveFilePath);
					showUpdateLogWindow();//显示更新日志
				}
			}else{	//检测更新失败  提示
				LogUtil.printLogE(TAG, "check fail info is null");
				checkUpdating = false;
				if(showCheckToast){
					mHandler.sendEmptyMessage(CHECK_UPDATE_FAIL);
				}
			}
			versionInfo = null;
		}catch(Exception e){
			checkUpdating = false;
			e.printStackTrace();
			LogUtil.printLogE(TAG, "Exception err = " + e.toString());
		}finally{
			checkUpdating = false;
		}
	}
	
	/**获取服务器版本信息*/
	private String getVersionInfoFromServer(){
		try{
			String url = updateCheckUrl;
			InputStream in = NetTool.getInputStreamByGet(url);
			return  NetTool.InputStreamToString(in);
		}catch(Exception e){
			LogUtil.printLogE(TAG, "getVersionInfoFromServer err:" + e.toString());
			return null;
		}
	}
	
	/**
	 * 
	 * 设置更新版本信息
	 * @param serverVersionName : 服务器最新版本号
	 * @param lowVersionName : 最低使用版本号(用于强更)
	 * @param curVersionName : 当前版本号(不一定与AndroidManifest.xml中的versionName一致)
	 * @param downloadUrl: 更新下载地址
	 * @param updateLog: 更新日志
	 * @param saveDir : 下载保存目录(完整)
	 * 
	 * */
	public void setAnalyzeVersionInfo(String serverVersionName, String lowVersionName, String curVersionName, String downloadUrl, String updateLog, String saveDir){
		this.serverVersionName = serverVersionName;
		this.lowVersionName = lowVersionName;
		this.curVersionName = curVersionName;
		this.downloadUrl = downloadUrl;
		this.updateLog = updateLog;
		this.saveDir = saveDir;
	}
	
	/**
	 * 
	 * 设置更新版本信息
	 * @param serverVersionName : 服务器最新版本号
	 * @param lowVersionName : 最低使用版本号(用于强更)
	 * @param curVersionName : 当前版本号(不一定与AndroidManifest.xml中的versionName一致)
	 * @param downloadUrl: 更新下载地址
	 * @param updateLogList: 更新日志
	 * @param saveDir : 下载保存目录(完整)
	 * 
	 * */
	public void setAnalyzeVersionInfo2(String serverVersionName, String lowVersionName, String curVersionName, String downloadUrl, ArrayList<String> updateLogList, String saveDir){
		this.serverVersionName = serverVersionName;
		this.lowVersionName = lowVersionName;
		this.curVersionName = curVersionName;
		this.downloadUrl = downloadUrl;
		this.updateLogList = updateLogList;
		this.saveDir = saveDir;
	}
	

	/**显示更新日志界面*/
	private void showUpdateLogWindow(){
		if(updateLogList != null && updateLogList.size() > 0){
			UpdateLogDialogActivity.startActivitySelf(mContext, updateLogList, force_update);
		}else if(!TextUtils.isEmpty(updateLog)){
			UpdateLogDialogActivity.startActivitySelf(mContext, updateLog, "", force_update);
		}else{
			UpdateLogDialogActivity.startActivitySelf(mContext, "", "", force_update);
		}
	}
	
	/**显示下载界面*/
	public void showDownloadWindow(){
		UpdateDownLoadActivity.startActivitySelf(mContext, force_update);
	}
	
	/**
	 * 开始更新下载
	 * */
	public void startDownload(){
		if(canShowDialog){
			if(checkApkFileIsAll()){//安装文件存在，则直接安装
				showInstallDialog();
			}else{
				showDownloadProgressDialog();
				downloadApk();
			}
		}else{
			downloadApk();
		}
	}

	private void showDownloadProgressDialog(){	
		downloadDialog = new ProgressDialog(mContext);
		downloadDialog.setTitle(mContext.getString(R.string.current_version_is_old));
		downloadDialog.setMax(100);
		downloadDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		downloadDialog.setCancelable(true);
		downloadDialog.setButton(DialogInterface.BUTTON_POSITIVE, mContext.getString(R.string.dlg_button_cancel), new OnClickListener(){
			public void onClick(DialogInterface arg0, int arg1) {
				downloadDialog.dismiss();
				downloadDialog = null;
				stopDownload();
				if(force_update){
					exitApp(mContext); //如果是强制更新，取消下载时强制退出
				}
			}
			
		});
		downloadDialog.setCanceledOnTouchOutside(false);
		downloadDialog.show();
	}
	
	private Runnable mDownloadRunnable = new Runnable(){			 
		public void run() {
			InputStream in = null;
			RandomAccessFile fos = null;
			try {
				downloading = true;
				File file = new File(saveDir);
				if(!file.exists()){
					file.mkdirs();
				}
				File downloadFile = new File(saveFilePath);
				int saveFileLength = 0;
				if (downloadFile != null && downloadFile.exists()) {
					if(allowBreakPointDownload){
						 saveFileLength = (int) downloadFile.length();
					}else{
						downloadFile.delete();
						downloadFile.createNewFile();
					}
				}
				LogUtil.printLogE(TAG + "/Runnable", "saveFileLength = " + saveFileLength);
				
				//int len = getApkFileSize();
				//DebugUtils.printInfo(TAG, "get size from url=" + len);
				
				URL url = new URL(downloadUrl);			
				LogUtil.printLogE(TAG, "下载url=" + downloadUrl);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				conn.setDoInput(true);
				//conn.setDoOutput(true); //开启后下载异常,默认值为false
				conn.setUseCaches(false);
				conn.setRequestProperty("Accept-Encoding", "identity");
				conn.setRequestProperty("Range", "bytes=" + saveFileLength + "-");
				conn.setConnectTimeout(6000);
				conn.setReadTimeout(6000);
				conn.connect();
				
				int length = conn.getContentLength();
				LogUtil.printLogE(TAG + "/Runnable", "download file size = " + length);
				if(-1 != length){
					in = conn.getInputStream();
					fos = new RandomAccessFile(downloadFile, "rwd");
					fos.seek(saveFileLength);
					
					appTotalSize = saveFileLength + length;
					int count = saveFileLength;
					byte buf[] = new byte[1024];
					
					stopDownload = false;
					do{   		   		
			    		int numread = in.read(buf);
			    		if(numread < 0){
			    			break;
			    		}
			    		count += numread;
			    	    //更新进度
			    	    Message msg = new Message();
			    	    msg.what = Download_TATUS_RUNNING;
			    	    msg.arg1 = count;
			    	    msg.arg2 = appTotalSize;
			    	    if(mUpdateHandler != null){
			    	    	mUpdateHandler.sendMessage(msg);
			    	    }else{
			    	    	mHandler.sendMessage(msg);
			    	    }
			    		fos.write(buf, 0, numread);
			    	}while(!stopDownload);//点击取消就停止下载
					
					if(fos != null){
						fos.close();
					}
					fos = null;
					
					if(in != null){
						in.close();
					}
					in = null;
					
					if(!stopDownload){
			    		//下载完成通知安装
						Message msg = new Message();
		    	    	msg.what = Download_STATUS_SUCCESSFUL;
		    	    	msg.arg1 = appTotalSize;
		    	    	msg.arg2 = appTotalSize;
						if(mUpdateHandler != null){
			    	    	mUpdateHandler.sendMessage(msg);
						}else{
							mHandler.sendMessage(msg);
						}
			    		return ;
			    	}
				}else{
					if(checkApkFileIsAll()){
						stopDownload = false;//下载的包是完整的，就是下载完成
					}else{
						stopDownload = true;
						if(mUpdateHandler != null){
			    	    	mUpdateHandler.sendEmptyMessage(Download_STATUS_FAILED);
						}else{
							mHandler.sendEmptyMessage(Download_STATUS_FAILED);
						}
					}
					return ;
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
				stopDownload = true;
				if(mUpdateHandler != null){
					mUpdateHandler.sendEmptyMessage(Download_STATUS_FAILED);
				}else{
					mHandler.sendEmptyMessage(Download_STATUS_FAILED);
				}
			} catch(IOException e){
				e.printStackTrace();
				stopDownload = true;
				if(mUpdateHandler != null){
					mUpdateHandler.sendEmptyMessage(Download_STATUS_FAILED);
				}else{
					mHandler.sendEmptyMessage(Download_STATUS_FAILED);
				}
			}finally{
				downloading = false;
				try {
					if(fos != null){
						fos.close();
					}
					fos = null;
					
					if(in != null){
						in.close();
					}
					in = null;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	};
	
	/**
     * 下载apk
     */
	private void downloadApk(){
		if(downloading){
			LogUtil.printLogE(TAG, "downloadApk: has another Thread downloading");
			return ;
		}
		
		downLoadThread = new Thread(mDownloadRunnable);
		downLoadThread.start();
	}
	
	/**
     * 安装apk
     */
	public void installApk(){
		File apkfile = new File(saveFilePath);
        if (!apkfile.exists()) {
            return;
        }    
        Intent i = new Intent(Intent.ACTION_VIEW);
        LogUtil.printLogE(TAG + "/installApk", "filename = " + "file://" + apkfile.toString());
        i.setDataAndType(Uri.parse("file://" + apkfile.toString()), "application/vnd.android.package-archive"); 
        mContext.startActivity(i);
	}
	
	/**
	 * 
	 * 设置进度更新handler：
	 * 用于在其他页面时页面获取到进度
	 * */
	public void setDownloadUpdateHandler(Handler handler){
		this.mUpdateHandler = handler;
	}
	
	
	 /**
	  * 检测下载完成的apk文件是否完整
	  * */
	public boolean checkApkFileIsAll(){
		boolean flag = false;
		try {
			if(TextUtils.isEmpty(saveFilePath)){
				flag = false;
				return flag;
			}
			File file = new File(saveFilePath); 
			if(!file.exists()){
				flag = false;
				return flag;
			}
			PackageManager pm = mContext.getPackageManager();     
	        PackageInfo packInfo = pm.getPackageArchiveInfo(saveFilePath, PackageManager.GET_ACTIVITIES);     
	        if(packInfo != null){
	        	flag = true;
		   }else{
			   flag = false;
		   }
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
		}finally{
			if(flag == false){
				 LogUtil.printLogE(TAG, "checkApkFileIsAll 解析apk失败");
			}
		}
		return flag;
  }
	
	/**
	 * 停止下载
	 * */
	public void stopDownload(){
		stopDownload = true;
	}
	
	/**获取apk的大小*/
	private int getApkFileSize(){
		HttpURLConnection conn = null;
		try{
			conn = (HttpURLConnection)(new URL(downloadUrl)).openConnection();
			conn.setConnectTimeout(3000);
			conn .setRequestProperty("Accept-Encoding", "identity"); 	//设置不做gzip压缩  免得获取的大小为-1
			conn.setRequestMethod("GET");
			int size = 0;
			if(HttpURLConnection.HTTP_OK == conn.getResponseCode()){
				size = conn.getContentLength();
			}
			conn.disconnect();
			conn = null;
			return size;
		}catch(Exception e){
			return 0;
		}finally{
			if(conn != null){
				conn.disconnect();
				conn = null;
			}
		}
	}
	
	/**终止程序*/
	public void exitApp(){
		System.exit(0);
		//android.os.Process.killProcess(android.os.Process.myPid());
		instance = null;
	}

	/**
	 *
	 * 退出程序
	 * 通过跳转到更新首界面(程序主界面，不一定是入口Activity)终止程序
	 * */
	public static void exitApp(Context activity){
		LogUtil.printLogE(TAG, "exitApp");
		try {
			//需先finish,否则在日志界面会导致强更退出应用失效
			if(activity instanceof Activity){
				((Activity)activity).finish();
			}

			Intent intent = new Intent();
			intent.setClass(activity, UpdateEmptyActivity.class);
			//Intent intent = activity.getPackageManager().getLaunchIntentForPackage(activity.getPackageName());
			intent.putExtra(UPDATE_CANCEL_EXIT_APP, true);
			//intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); //注意本行的FLAG设置
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);//需和Intent.FLAG_ACTIVITY_NEW_TASK一起使用
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			activity.startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	/**下载完成弹出对话框是否安装*/
	private void showInstallDialog() {
		LogUtil.printLogE(TAG + "/showInstallConfirmDialog", "showInstallConfirmDialog");
		AlertDialog dialog = CustomDialogUtils.showCustomDialog(mContext, R.string.dlg_msg_notice, R.string.update_download_finish,
				R.string.dlg_button_confirm, R.string.dlg_button_cancel, new CustomDialogUtils.CustomDialogClickListener() {

					@Override
					public void onOkClick(View v, DialogInterface dialog) {
						CustomDialogUtils.hideDialog(dialog);
						AppUpdateManager.getInstance().installApk();
					}

					@Override
					public void onCancelClick(View v, DialogInterface dialog) {
						CustomDialogUtils.hideDialog(dialog);
						if(force_update){
							exitApp(mContext);
						}
					}
				});
		dialog.setCanceledOnTouchOutside(false);
		dialog.setCancelable(false);
	}
		
	/**获取下载文件的详细路径*/
	public String getDownloadFilePath(){
		return saveFilePath;
	}

    /**
     * 版本号比较
     *
     * @param version1
     * @param version2
     * @return 0代表相等，1代表version1大于version2，-1代表version1小于version2
     */
    public static int compareVersion(String version1, String version2) {
        if (version1.equals(version2)) {
            return 0;
        }
        String[] version1Array = version1.split("\\.");
        String[] version2Array = version2.split("\\.");
        //DebugUtils.printInfo(TAG, "version1Array=="+version1Array.length);
        // DebugUtils.printInfo(TAG, "version2Array=="+version2Array.length);
        int index = 0;
        // 获取最小长度值
        int minLen = Math.min(version1Array.length, version2Array.length);
        int diff = 0;
        // 循环判断每位的大小
        //DebugUtils.printInfo(TAG, "verTag2=2222="+version1Array[index]);
        while (index < minLen
                && (diff = Integer.parseInt(version1Array[index])
                - Integer.parseInt(version2Array[index])) == 0) {
            index++;
        }
        if (diff == 0) {
            // 如果位数不一致，比较多余位数
            for (int i = index; i < version1Array.length; i++) {
                if (Integer.parseInt(version1Array[i]) > 0) {
                    return 1;
                }
            }

            for (int i = index; i < version2Array.length; i++) {
                if (Integer.parseInt(version2Array[i]) > 0) {
                    return -1;
                }
            }
            return 0;
        } else {
            return diff > 0 ? 1 : -1;
        }
    }

    /**获取当前应用的版本号*/
	public static String getVersionName(Context context) {
		String versionName = "";
		try {
			PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			versionName = packageInfo.versionName;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return versionName;
	}

}

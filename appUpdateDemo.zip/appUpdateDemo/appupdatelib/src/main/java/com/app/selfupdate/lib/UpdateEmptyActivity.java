package com.app.selfupdate.lib;

import android.app.Activity;
import android.os.Bundle;

//强制更新时退出程序用
public class UpdateEmptyActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LogUtil.printLogE("UpdateEmptyActivity", "onCreate");
		finish();
		AppUpdateManager.getInstance().exitApp();
	}
}

package com.app.selfupdate.lib;

import android.util.Log;

public class LogUtil {
    private static boolean isDebug = true;

    public static void setDebug(boolean isDebug){
        LogUtil.isDebug = isDebug;
    }

    public static void printLogE(final String TAG, final Exception e){
        printLogE(TAG, e.getMessage());
    }


    public static void printLogE(final String TAG, final String msg){
        if(isDebug){
            Log.e(TAG, msg);
        }
    }

}

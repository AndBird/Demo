package com.example.sqlitedbupgrade;

import java.util.ArrayList;
import java.util.List;

import com.example.sqlitedbupgrade.db.MyDBHelper;

import android.app.Activity;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity{
	private Button upgrade;
	private TextView content;
	
	private final String DB_NAME = "upgrade.db";//���ݿ���
	private int DB_VERSION = 2;//���ݿ�汾
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		upgrade = (Button) findViewById(R.id.upgrade);
		content = (TextView) findViewById(R.id.content);
		
		SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this); 
		boolean upgraded = sp.getBoolean("upgrade", false); 
		if(upgraded){//�Ѿ�������
			DB_VERSION = 3;
		}
		
		upgrade.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()); 
				boolean upgraded = sp.getBoolean("upgrade", false); 
				if(upgraded){//�Ѿ�������
					Toast.makeText(getApplicationContext(), "��������!", Toast.LENGTH_SHORT).show();
					return ;
				}
				DB_VERSION = 3;
				queryData();
				queryData2();//��ѯ��ʱ��
			
				Editor editor = sp.edit(); 
				editor.putBoolean("upgrade", true); 
				editor.commit();
			}
		});
		
		insert();
		queryData();
	}
	
	private void insert(){
	    	SQLiteDatabase db = null;
	    	try { 
	    		MyDBHelper dbHelper = new MyDBHelper(getApplicationContext(), DB_NAME, null, DB_VERSION);
	    		db = dbHelper.getReadableDatabase();
	    		for(int i = 0; i < 4; i++){
		    		ContentValues values = new ContentValues();
		    		values.put(MyDBHelper.COLUMN_NAME, "name" + i);
		    		values.put(MyDBHelper.COLUMN_DES, "��������");
		    		long rowid = db.insert(MyDBHelper.DB_TABLE, null, values);//�����к�,ʧ�ܷ���-1
	    			//��2:�˷�������ҪΪ���е��ֶγ�ʼ������
//		    		String sql = "insert into " + MyDBHelper.DB_TABLE + " values (null, ?, ?, ?)";//��null����Ϊ���е�һ��������INTEGER����
//	    			db.execSQL(sql, new String[]{"name" + i, "��������", ""});
	    		}
	    	
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(db != null){
					db.close();
				}
			}
	}
	
	
	private void queryData(){
		try {
		    	SQLiteDatabase db = null;
		    	Cursor cur = null;
		    	try {
		    			MyDBHelper dbHelper = new MyDBHelper(getApplicationContext(), DB_NAME, null, DB_VERSION);
		    		    db = dbHelper.getReadableDatabase();
					    cur = db.rawQuery("select * from " + MyDBHelper.DB_TABLE, null);
					    String data = "";
					    if(cur != null){
		    				System.out.println("��ѯ����Ŀ:" + cur.getCount());
		    				for(cur.moveToFirst(); !cur.isAfterLast(); cur.moveToNext()){
		    					data += cur.getString(cur.getColumnIndex(MyDBHelper.COLUMN_NAME));
		    					data += "\t" + cur.getString(cur.getColumnIndex(MyDBHelper.COLUMN_DES));
		                        data += "\n";
		    				}
		    			}
		    			content.setText(data);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(cur != null){
						cur.close();
					}
					if(db != null){
						db.close();
					}
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private void queryData2(){
		try {
		    	SQLiteDatabase db = null;
		    	Cursor cur = null;
		    	try {
		    			MyDBHelper dbHelper = new MyDBHelper(getApplicationContext(), DB_NAME, null, DB_VERSION);
		    		    db = dbHelper.getReadableDatabase();
					    cur = db.rawQuery("select * from temp", null);
					    String data = "temp ��ʱ��:\n";
					    if(cur != null){
		    				System.out.println("��ѯ����Ŀ:" + cur.getCount());
		    				for(cur.moveToFirst(); !cur.isAfterLast(); cur.moveToNext()){
		    					data += cur.getString(cur.getColumnIndex(MyDBHelper.COLUMN_NAME));
		    					data += "\t" + cur.getString(cur.getColumnIndex(MyDBHelper.COLUMN_DES));
		                        data += "\n";
		    				}
		    			}
		    			content.append(data);
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(cur != null){
						cur.close();
					}
					if(db != null){
						db.close();
					}
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

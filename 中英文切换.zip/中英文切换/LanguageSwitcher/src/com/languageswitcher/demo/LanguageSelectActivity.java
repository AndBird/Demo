package com.languageswitcher.demo;

import com.languageswitcher.lib.LanguageHelper;
import com.languageswitcher.lib.LanguageHelper.LanguageType;
import com.languageswitcher.lib.LanguageSwitcherBaseActivity;
import com.languageswitcher.lib.R;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;


public class LanguageSelectActivity extends LanguageSwitcherBaseActivity implements OnClickListener{
	private final String TAG = LanguageSelectActivity.class.getSimpleName();
	
	private View backView, saveView;
	
	private RelativeLayout[] languageItem;
	private ImageView[] languageSelectView;
	
	private LanguageType defaultSelect = null;//Ĭ��ѡ�������
	private LanguageType curSelect = null;//��ǰѡ�������
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_language_select);
		try {
			initView();
			updateView();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void initView(){
		try {
			backView = findViewById(R.id.headBack);
			saveView = findViewById(R.id.save);
			
			languageItem = new RelativeLayout[3];
			languageSelectView = new ImageView[3];
			languageItem[0] = (RelativeLayout) findViewById(R.id.language_setting_item1);
			languageItem[1] = (RelativeLayout) findViewById(R.id.language_setting_item2);
			languageItem[2] = (RelativeLayout) findViewById(R.id.language_setting_item3);
			languageSelectView[0] = (ImageView) findViewById(R.id.language_setting_select1);
			languageSelectView[0].setTag(LanguageType.LANGUAGE_CHINA);
			languageSelectView[1] = (ImageView) findViewById(R.id.language_setting_select2);
			languageSelectView[1].setTag(LanguageType.LANGUAGE_ENGLISH);
			languageSelectView[2] = (ImageView) findViewById(R.id.language_setting_select3);
			languageSelectView[2].setTag(LanguageType.LANGUAGE_DEFAULT);
			
			
			backView.setOnClickListener(this);
			saveView.setOnClickListener(this);
			languageItem[0].setOnClickListener(this);
			languageItem[1].setOnClickListener(this);
			languageItem[2].setOnClickListener(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onClick(View v) {
		try {
			switch (v.getId()) {
			case R.id.headBack:
				LanguageSelectActivity.this.finish();
				break;
			case R.id.save:
				saveLanguageSetting();
				break;
			case R.id.language_setting_item1:
				updateSelectView(LanguageType.LANGUAGE_CHINA);
				break;
			case R.id.language_setting_item2:
				updateSelectView(LanguageType.LANGUAGE_ENGLISH);
				break;
			case R.id.language_setting_item3:
				updateSelectView(LanguageType.LANGUAGE_DEFAULT);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void updateView(){
		try {
			defaultSelect = LanguageHelper.getSavedSelectedLanguage(getApplicationContext());
			updateSelectView(defaultSelect);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void updateSelectView(LanguageType languageType){
		try {
			if(languageSelectView != null && languageSelectView.length > 0){
				for(int i = 0; i < languageSelectView.length; i++){
					ImageView imageView = languageSelectView[i];
					if(imageView.getTag() == languageType){
						imageView.setSelected(true);
						curSelect = languageType;
					}else{
						imageView.setSelected(false);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**������������*/
	private void saveLanguageSetting(){
		try {
			if(curSelect != defaultSelect){
				if(LanguageHelper.saveSelectedLanguage(getApplicationContext(), curSelect)){
					//����ɹ���Ӧ����������
					LanguageHelper.changeToLanguage(getApplicationContext(), curSelect);
	                
					//����Ӧ��(�������������ô���е�activity����̳�LanguageSwitcherBaseActivity)
					LanguageHelper.restartApp(LanguageSelectActivity.this);
				}else{
					Toast.makeText(getApplicationContext(), R.string.save_fail, Toast.LENGTH_SHORT).show();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

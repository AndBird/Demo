package com.languageswitcher.lib;

public class EventBusLanguageChanged {

	protected EventBusLanguageChanged() {
		// TODO Auto-generated constructor stub
	}
}

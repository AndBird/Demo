package com.languageswitcher.lib;

import de.greenrobot.event.EventBus;
import de.greenrobot.event.Subscribe;
import de.greenrobot.event.ThreadMode;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

public class LanguageSwitcherBaseActivity extends Activity{
	private final String TAG = LanguageSwitcherBaseActivity.class.getSimpleName();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//Log.e(TAG, "onCreate");
		if(!EventBus.getDefault().isRegistered(this)){
			EventBus.getDefault().register(this);
		}
		
	}
	
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
	}
	
	//����public
    @Subscribe(threadMode = ThreadMode.MainThread)
    public void appLanguageChanged(EventBusLanguageChanged msg){
    	if(msg != null){
    		Log.e(TAG, "app language changed event");
    		LanguageSwitcherBaseActivity.this.recreate();
    	}
    }

	
	/** ����7.0����ϵͳ��������������Ҫ����Context�����������õģ����Ǳ���Ҫ�����ǵ�Activity��
	 * attachBaseContext������attach�޸ĺ��context*/
	@Override
	protected void attachBaseContext(Context newBase) {
		//Log.e(TAG, "attachBaseContext");
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            super.attachBaseContext(LanguageHelper.wrapContext(newBase));
        }else {
            super.attachBaseContext(newBase);
        }
	}
}

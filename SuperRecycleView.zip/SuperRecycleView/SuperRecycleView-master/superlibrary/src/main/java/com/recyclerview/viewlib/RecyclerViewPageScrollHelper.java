package com.recyclerview.viewlib;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * 实现RecycleView分页滚动的工具类(ViewPager)
 *
 *
 */

public class RecyclerViewPageScrollHelper {
    private final String TAG = "RecyclerViewPageScrollHelper";

    private RecyclerView mRecyclerView = null;

    private MyOnScrollListener mOnScrollListener = new MyOnScrollListener();

    private PageOnFlingListener mOnFlingListener = new PageOnFlingListener();
    private int offsetY = 0;
    private int offsetX = 0;

    int startY = 0;
    int startX = 0;



    /**上一页index*/
    private int mLastPageIndex = 0;

    /**手指按下的位置*/
    private int touchDownX, touchDownY;
    /**手指收起的位置*/
    private int touchUpX, touchUpY;
    /**手指滑动最小距离*/
    private int minDistance;



    enum ORIENTATION {
        HORIZONTAL, VERTICAL, NULL
    }

    private ORIENTATION mOrientation = ORIENTATION.HORIZONTAL;

    public void setUpRecycleView(RecyclerView recycleView) {
        if (recycleView == null) {
            throw new IllegalArgumentException("recycleView must be not null");
        }
        mRecyclerView = recycleView;
        //处理滑动
        recycleView.setOnFlingListener(mOnFlingListener);
        //设置滚动监听，记录滚动的状态，和总的偏移量
        recycleView.addOnScrollListener(mOnScrollListener);
        //记录滚动开始的位置
        recycleView.setOnTouchListener(mOnTouchListener);
        //获取滚动的方向
        updateLayoutManger();


    }

    public void updateLayoutManger() {
        RecyclerView.LayoutManager layoutManager = mRecyclerView.getLayoutManager();
        if (layoutManager != null) {
            if (layoutManager.canScrollVertically()) {
                mOrientation = ORIENTATION.VERTICAL;
            } else if (layoutManager.canScrollHorizontally()) {
                mOrientation = ORIENTATION.HORIZONTAL;
            } else {
                mOrientation = ORIENTATION.NULL;
            }
            if (mAnimator != null) {
                mAnimator.cancel();
            }
            startX = 0;
            startY = 0;
            offsetX = 0;
            offsetY = 0;

            mLastPageIndex = getPageIndex();
            int touchSlop = ViewConfiguration.get(mRecyclerView.getContext()).getScaledTouchSlop();
            minDistance = touchSlop * 2;
            Log.e(TAG, "touchSlop=" + touchSlop);

        }

    }

    /**
     * 获取总共的页数
     */
    public int getPageCount() {
        if (mRecyclerView != null) {
            if (mOrientation == ORIENTATION.NULL) {
                return 0;
            }
            if (mOrientation == ORIENTATION.VERTICAL && mRecyclerView.computeVerticalScrollExtent() != 0) {
                return mRecyclerView.computeVerticalScrollRange() / mRecyclerView.computeVerticalScrollExtent();
            } else if (mRecyclerView.computeHorizontalScrollExtent() != 0) {
                Log.i("zzz","rang="+mRecyclerView.computeHorizontalScrollRange()+" extent="+mRecyclerView.computeHorizontalScrollExtent());
                return mRecyclerView.computeHorizontalScrollRange() / mRecyclerView.computeHorizontalScrollExtent();
            }
        }
        return 0;
    }



    ValueAnimator mAnimator = null;

    public void scrollToPosition(int position) {
        if (mAnimator == null) {
            //mOnFlingListener.onFling(0, 0);
            initAnimator(0, 0);
        }
        if (mAnimator != null) {
            int startPoint = mOrientation == ORIENTATION.VERTICAL ? offsetY : offsetX, endPoint = 0;
            if (mOrientation == ORIENTATION.VERTICAL) {
                endPoint = getPageHeight() * position;
            } else {
                endPoint = getPageWidth() * position;
            }
            if (startPoint != endPoint) {
                mAnimator.setIntValues(startPoint, endPoint);
                //mAnimator.setDuration(300);
                //静默滚动
                mAnimator.setDuration(0);
                mAnimator.start();
            }
        }
    }

    public class PageOnFlingListener extends RecyclerView.OnFlingListener {

        @Override
        public boolean onFling(int velocityX, int velocityY) {
            if (mOrientation == ORIENTATION.NULL) {
                return false;
            }

            Log.e(TAG, "onFling:" + velocityX + "," + velocityY);
            boolean canChanged = false;
            if(0 == velocityX && 0 == velocityY || 1000 == Math.abs(velocityX) && 1000 == Math.abs(velocityY)){
                //由scorll处调用
                canChanged = true;
            }else{
                //有RecyclerView内部调用
                canChanged = false;
            }


            //获取开始滚动时所在页面的index
            int p = getStartPageIndex();

            //记录滚动开始和结束的位置
            int endPoint = 0;
            int startPoint = 0;

            //如果是垂直方向
            if (mOrientation == ORIENTATION.VERTICAL) {
                startPoint = offsetY;

                final int absX = Math.abs(touchDownX - touchUpX);
                final int absY = Math.abs(touchDownY - touchUpY);
                if(absY >= minDistance && absY > absX) {
                    //y方向有一定偏移才允许切换页面，解决水平向滑动时也切换页面的问题
                    if (velocityY < 0) {
                        p--;
                    } else if (velocityY > 0) {
                        p++;
                    }
                }

                //更具不同的速度判断需要滚动的方向
                //注意，此处有一个技巧，就是当速度为0的时候就滚动会开始的页面，即实现页面复位
                endPoint = p * getPageHeight();

            } else {
                startPoint = offsetX;

                final int absX = Math.abs(touchDownX - touchUpX);
                final int absY = Math.abs(touchDownY - touchUpY);
                if(absX >= minDistance && absY < absX) {
                    //x方向有一定偏移才允许切换页面，解决纵向滑动时也切换页面的问题
                    if (velocityX < 0) {
                        p--;
                    } else if (velocityX > 0) {
                        p++;
                    }
                }

                //更具不同的速度判断需要滚动的方向
                //注意，此处有一个技巧，就是当速度为0的时候就滚动会开始的页面，即实现页面复位
                endPoint = p * getPageWidth();

            }
            if (endPoint < 0) {
                endPoint = 0;
            }


            if(startPoint != endPoint){
                //位置不变化时不需要动画
                //使用动画处理滚动
                if (mAnimator == null) {
                    initAnimator(startPoint, endPoint);
                } else {
                    mAnimator.cancel();
                    mAnimator.setIntValues(startPoint, endPoint);
                    mAnimator.setDuration(300);
                }

                mAnimator.start();
            }

            //true的时候系统就不处理滑动了，而是将滑动交给我们自己处理
            return true;
        }
    }

    private void initAnimator(int startPoint, int endPoint) {
        if (mAnimator == null) {
            mAnimator = new ValueAnimator().ofInt(startPoint, endPoint);

            mAnimator.setDuration(300);
            mAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    int nowPoint = (int) animation.getAnimatedValue();

                    if (mOrientation == ORIENTATION.VERTICAL) {
                        int dy = nowPoint - offsetY;
                        //这里通过RecyclerView的scrollBy方法实现滚动。
                        mRecyclerView.scrollBy(0, dy);
                    } else {
                        int dx = nowPoint - offsetX;
                        mRecyclerView.scrollBy(dx, 0);
                    }
                }
            });
            mAnimator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    //回调监听
                    final int pageIndex = getPageIndex();
                    //if (null != mOnPageChangeListener) {
                    if (null != mOnPageChangeListener && mLastPageIndex != pageIndex) {
                        mLastPageIndex = pageIndex;
                        mOnPageChangeListener.onPageChangeEnd(pageIndex);
                    }
                    //修复双击item bug
                    mRecyclerView.stopScroll();
                    startY = offsetY;
                    startX = offsetX;
                }
            });
        }
    }

    public class MyOnScrollListener extends RecyclerView.OnScrollListener {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            //newState==0表示滚动停止，此时需要处理回滚
            Log.e(TAG, "onScrollStateChanged:" + newState);
            if (newState == 0 && mOrientation != ORIENTATION.NULL) {
                boolean move;
                int vX = 0, vY = 0;
                if (mOrientation == ORIENTATION.VERTICAL) {
                    int absY = Math.abs(offsetY - startY);
                    //如果滑动的距离超过屏幕的一半表示需要滑动到下一页
                    move = absY > recyclerView.getHeight() / 2;
                    Log.e(TAG, "absY=" + absY);
                    vY = 0;

                    if (move) {
                        vY = offsetY - startY < 0 ? -1000 : 1000;

                        //加入特定值，便于区分
                        vX = 1000;
                    }

                } else {
                    int absX = Math.abs(offsetX - startX);
                    Log.e(TAG, "absX=" + absX);
                    move = absX > recyclerView.getWidth() / 2;
                    if (move) {
                        vX = offsetX - startX < 0 ? -1000 : 1000;

                        //加入特定值,便于区分
                        vY = 1000;
                    }

                }


                //(0,0)不切换页面，并还原页面
                //(-1000, 1000) ,(1000, 1000)左右切换
                //(1000, -1000), (1000, -1000)上下切换
                mOnFlingListener.onFling(vX, vY);


            }

        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            //滚动结束记录滚动的偏移量
            offsetY += dy;
            offsetX += dx;
            Log.e(TAG, "onScrolled");
        }
    }

    private MyOnTouchListener mOnTouchListener = new MyOnTouchListener();

    private boolean firstTouch = true;

    public class MyOnTouchListener implements View.OnTouchListener {

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            //手指按下的时候记录开始滚动的坐标
            if (firstTouch) {
                //第一次touch可能是ACTION_MOVE或ACTION_DOWN,所以使用这种方式判断
                firstTouch = false;
                startY = offsetY;
                startX = offsetX;

                touchDownX = (int) event.getX();
                touchDownY = (int) event.getY();
            }
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                Log.e(TAG, "up");
                firstTouch = true;

                touchUpX = (int) event.getX();
                touchUpY = (int) event.getY();
            }

            return false;
        }

    }

    private int getPageIndex() {
        int p = 0;
        if (mRecyclerView.getHeight() == 0 || mRecyclerView.getWidth() == 0) {
            return p;
        }
        if (mOrientation == ORIENTATION.VERTICAL) {
            p = offsetY / getPageHeight();
        } else {
            p = offsetX / getPageWidth();
        }
        return p;
    }

    private int getStartPageIndex() {
        int p = 0;
        if (mRecyclerView.getHeight() == 0 || mRecyclerView.getWidth() == 0) {
            //没有宽高无法处理
            return p;
        }
        if (mOrientation == ORIENTATION.VERTICAL) {
            p = startY / getPageHeight();
        } else {
            p = startX / getPageWidth();
        }
        return p;
    }

    private onPageChangeListener mOnPageChangeListener;

    public void setOnPageChangeListener(onPageChangeListener listener) {
        mOnPageChangeListener = listener;
    }

    public interface onPageChangeListener {
        /**页面将开始切换*/
        //void onPageChanagWillStart(int index);
        /**页面切换完成*/
        void onPageChangeEnd(int index);
    }


    private int getPageWidth(){
        //满屏宽
        //return mRecyclerView.getWidth();

        //一页的宽度
        View v = mRecyclerView.getChildAt(0);
        if(v != null) {
            return v.getWidth();
        }else{
            return mRecyclerView.getWidth();
        }
    }

    private int getPageHeight(){
        //满屏高
        //return mRecyclerView.getHeight();

        //一页的高度度
        View v = mRecyclerView.getChildAt(0);
        if(v != null) {
            return v.getHeight();
        }else{
            return mRecyclerView.getHeight();
        }
    }
}

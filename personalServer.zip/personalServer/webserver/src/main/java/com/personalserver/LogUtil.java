package com.personalserver;

import android.util.Log;

public class LogUtil {

    private static final boolean isDebug = true;


    public static void printLogE(final String TAG, final Exception e){
        printLogE(TAG, e.getMessage());
    }


    public static void printLogE(final String TAG, final String msg){
        if(isDebug){
            Log.e(TAG, msg);
        }
    }
}

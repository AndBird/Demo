/*   
 *   Copyright (C) 2012  Alvin Aditya H,
 *   					 Shanti F,
 *   					 Selviana 
 *   
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *       
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *       
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *    MA 02110-1301, USA.
 */

package com.personalserver;

import java.io.IOException;
import java.net.Socket;

import org.apache.http.HttpException;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.impl.DefaultHttpServerConnection;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.BasicHttpProcessor;
import org.apache.http.protocol.HttpRequestHandlerRegistry;
import org.apache.http.protocol.HttpService;
import org.apache.http.protocol.ResponseConnControl;
import org.apache.http.protocol.ResponseContent;
import org.apache.http.protocol.ResponseDate;
import org.apache.http.protocol.ResponseServer;

import android.content.Context;

public class HttpThread extends Thread {
	private final String TAG = HttpThread.class.getSimpleName();

	private static final String ALL_PATTERN = "*";
	//private static final String DIR_PATTERN = "/dir*";
	//http://ip:8080/player
	//public static final String DIR_PATTERN = "/player*";
	//http://ip:8080/player
	//public static final String DIR_PATTERN = "/player";
	//访问路径http://ip:8080
	public static final String DIR_PATTERN = "*";

	private Context context = null;
	
	public BasicHttpProcessor httproc;
	public HttpService httpserv = null;
	private BasicHttpContext httpContext = null;
	private HttpRequestHandlerRegistry reg = null;
	
	private Socket soket = null;
	
	public HttpThread(Context ctx, Socket soket, String threadName) {
		
		this.setContext(ctx);
		this.soket = soket;
		this.setName(threadName);
		httproc = new BasicHttpProcessor();
		httpContext = new BasicHttpContext();
		
		httproc.addInterceptor(new ResponseDate());
	    httproc.addInterceptor(new ResponseServer());
	    httproc.addInterceptor(new ResponseContent());
	    httproc.addInterceptor(new ResponseConnControl());
	    
	    httpserv = new HttpService(httproc, new DefaultConnectionReuseStrategy(), new DefaultHttpResponseFactory());
	    
	    reg = new HttpRequestHandlerRegistry();

	    //http://ip:8080
		//reg.register(ALL_PATTERN, new HomeCommandHandler(ctx));
		//http://ip:8080/DIR_PATTERN
		reg.register(DIR_PATTERN, new DirCommandHandler(ctx));
		httpserv.setHandlerResolver(reg);
		
	}

	public void run(){
		DefaultHttpServerConnection httpserver = new DefaultHttpServerConnection();
		try {
			httpserver.bind(this.soket, new BasicHttpParams());
			httpserv.handleRequest(httpserver, httpContext);
		} catch (IOException e) {
			LogUtil.printLogE(TAG, "Exception in HttpThread.java:can't bind");
			e.printStackTrace();
		} catch (HttpException e) {
			LogUtil.printLogE(TAG, "Exception in HttpThread.java:handle request");
			e.printStackTrace();
		} catch (Exception exce){
			LogUtil.printLogE(TAG, "debug : error again !");
			LogUtil.printLogE(TAG, exce.getMessage());
			exce.printStackTrace();
		}
		finally {
		
			try {
				httpserver.close();
			} catch (IOException e) {
				LogUtil.printLogE(TAG, "Excetion in HttpThread.java:can't shutdown");
				e.printStackTrace();
			}
			 
		}
	}
	
	public void setContext(Context context) {
		this.context = context;
	}
	
	public Context getContext() {
		return context;
	}
	
}

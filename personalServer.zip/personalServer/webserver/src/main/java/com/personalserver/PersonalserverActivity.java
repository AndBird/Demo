/*   
 *   Copyright (C) 2012  Alvin Aditya H,
 *   					 Shanti F,
 *   					 Selviana 
 *   
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *       
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *       
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *    MA 02110-1301, USA.
 */

package com.personalserver;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

public class PersonalserverActivity extends Activity {
	private final String TAG = PersonalserverActivity.class.getSimpleName();

	/**访问目录*/
	private EditText edit;
	/**state View*/
	private TextView infoBox;
	/**ip View*/
	private TextView ipbox;

	/**分享路径*/
	public static String share_path = null;
	/**运行状态*/
	private boolean server_running = false;
	private WebServer serv;
	private Intent intent = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);


		infoBox = (TextView) findViewById(R.id.infoBox);
		ipbox = (TextView) findViewById(R.id.ipbox);
		edit = (EditText) findViewById(R.id.editText);

		SharedPreferences preferences = getPreferences(MODE_PRIVATE);
		// Get the between instance stored values
        String infobox_txt = preferences.getString("infobox_txt",null);
		share_path = preferences.getString("share_path","/sdcard");
		Boolean edit_state = preferences.getBoolean("edit_state",true);
		server_running = preferences.getBoolean("run",false);

		//获取安装包的目录
		share_path = getPackageResourcePath();
		//restore value
		infoBox.setText(infobox_txt);
		if(share_path.length() <= 0){
			edit.setText("/sdcard");
		} else {
			edit.setText(share_path);
		}
		edit.setEnabled(edit_state);
		
    }

    ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };
    
    @Override
    protected void onPause() 
    {
        super.onPause();
        // Store values between instances here
        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        
        editor.putString("infobox_txt", (String) infoBox.getText());
        editor.putString("share_path", share_path);
        editor.putBoolean("edit_state", edit.isEnabled());
        editor.putBoolean("run", server_running);
        
        // Commit to storage
        editor.commit();
    }
    
    public void toggleServer(View view){
    	intent = new Intent(this,PersonalService.class);
    	if(server_running == false){
    		server_running = true;
    		share_path = edit.getText().toString();
    		edit.setEnabled(false);
    		infoBox.setText("server is running");
    		setServerStatus(true);
    		//startService(intent);
    		bindService(intent, connection, Service.BIND_AUTO_CREATE);
    		refreshIP(null);
    	} else {
    		server_running = false;
    		edit.setEnabled(true);
    		infoBox.setText("server is stopped");
    		setServerStatus(false);
    		//stopService(intent);
            unbindService(connection);
    		ipbox.setText("");
    		
    	}
    }
    
    private void setServerStatus(boolean setStatus){
    	// Store values between instances here
        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        
        editor.putBoolean("run", setStatus);
        
        // Commit to storage
        editor.commit();
    }

	/**
	 * 获取网络地址（包括有线网络,有线盒子返回NetWorkType 为9）
	 * return ip or null
	 * */
	public String getLocalIPAddress(){
		String ip = null;
		try {
			for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ){
				NetworkInterface intf = en.nextElement();
				if (intf.getName().toLowerCase().equals("eth0") || intf.getName().toLowerCase().equals("wlan0")){
					for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
						InetAddress inetAddress = enumIpAddr.nextElement();
						if (!inetAddress.isLoopbackAddress()) {
							String ipaddress = inetAddress.getHostAddress().toString();
							if(!ipaddress.contains("::")){//ipV6的地址
								Log.e("TAG", "local ip=" + ip);
								ip = ipaddress;
								return ip;
							}
						}
					}
				} else {
					continue;
				}
			}
		} catch (Exception e) {
			Log.e("TAG", "getlocalIP 异常:" + e.toString());
			e.printStackTrace();
		}
		return ip;
	}
    
    public void refreshIP(View view){
    	String ip = getLocalIPAddress();
    	if(server_running == false){
    		ipbox.setText("Web WebServer is not running," +
    				" please turn on the web server first");
    		return;
    	}
    	if(ip == null || ip.trim().length() <= 0){
    		ipbox.setText("Web WebServer is not accessible from external network" +
    				"please connect your device to wifi");
    	} else {
    		ipbox.setText("you can access web server from :\n" +
    				"http://" + ip + ":" + WebServer.port);
    	}
    	
    }

    public void exitApp(View view){
    	SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        
        editor.putString("infobox_txt", "");
        editor.putString("share_path", "");
        editor.putBoolean("edit_state", true);
        editor.putBoolean("run", false);
        if(intent != null) stopService(intent);
        // Commit to storage
        editor.commit();
    	finish();
    	System.exit(0);
    }

    public static void startActivitySelf(Activity activity){
		if(activity != null){
			Intent intent = new Intent(activity, PersonalserverActivity.class);
			activity.startActivity(intent);
		}
	}
}
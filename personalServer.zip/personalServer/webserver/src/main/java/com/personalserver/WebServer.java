/*   
 *   Copyright (C) 2012  Alvin Aditya H,
 *   					 Shanti F,
 *   					 Selviana 
 *   
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *       
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *       
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *    MA 02110-1301, USA.
 */

package com.personalserver;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ServerSocket;
import java.net.Socket;

import android.content.Context;

public class WebServer extends Thread{
	private final String TAG = WebServer.class.getSimpleName();

	public final static int port = 8080;
	public Context context;
	public boolean isRunning = false;

	private ServerSocket serverSocket = null;

	public WebServer(Context context, String threadName){
		this.context = context.getApplicationContext();
		this.setName(threadName);
	}
	
	@Override
	public void run(){
		if(isRunning){
			LogUtil.printLogE(TAG, "webserver is running");
			return;
		}
		isRunning = true;
		Socket soket = null;
		try {
			serverSocket = new ServerSocket(port);
			serverSocket.setReuseAddress(true);
			serverSocket.setSoTimeout(5000);
			while(isRunning){
				try{
					soket = serverSocket.accept();
					LogUtil.printLogE(TAG, "client connected!");
					Thread httpthread = new HttpThread(context, soket, "httpthread");
					httpthread.start();
				} catch (InterruptedIOException eiox){					
				} catch (Exception exc){
					System.err.println(exc.getMessage());
					exc.printStackTrace();
				}
				LogUtil.printLogE(TAG, "while!");
			}
			if(serverSocket != null) {
				serverSocket.close();
			}
			serverSocket = null;
	    } catch (IOException e) {
			LogUtil.printLogE(TAG, "Exception in WebServer.java:socket");
	    	e.printStackTrace();
	    	try{
		    	if(soket != null) {
					soket.close();
				}

				if(serverSocket != null) {
					serverSocket.close();
				}
	    	} catch(Exception ex){
				LogUtil.printLogE(TAG, "Exception in WebServer.java:cannot close socket");
	    		ex.printStackTrace();
	    	}
		}
		isRunning = false;
	}

	public void stopServer() {
		isRunning = false;

		if(serverSocket != null){
			try {
				serverSocket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		serverSocket = null;
	}

}
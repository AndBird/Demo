package com.example.launcher;

import java.util.List;
import com.example.launcher.SortGridView.DragGridBaseAdapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class AppListAdapter extends DragGridBaseAdapter<AppInfo>{
	private static final String TAG = AppListAdapter.class.getSimpleName();
	private Context context;
	private List<AppInfo> list;
	private boolean isDeleteMode = false;
	/**空child的数量*/
	private int emptyChildNum = 0;
	private LayoutInflater mInflater = null;
	
	
	public interface ActivityCallBackListener{
		
		public void test();
	}
	
	
	public AppListAdapter(Context context, List<AppInfo> list){
		super(context, list);
		this.context = context;
		this.list = list;
		this.isDeleteMode = false;
		this.mInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return list == null ? 0 : list.size();
	}

	public Object getItem(int position) {
		 if(list != null){
	         return  list.get(position);
	     }
	     return null;
	}

	public long getItemId(int position) {
		return position;
	}
	
	@Override
	public View getItemView(final int pos, View convertView, ViewGroup parent) {
		try{	
			if(mInflater == null){
				mInflater = LayoutInflater.from(context);
			}
			ViewHolder holder = null;
			if (convertView == null || convertView.getTag() == null) {
				convertView = mInflater.inflate(R.layout.layout_app_item, parent, false);
				holder = new ViewHolder();
				holder.iconView = (ImageView) convertView.findViewById(R.id.iconView);
				holder.deleteView = (ImageView) convertView.findViewById(R.id.deleteView);
				holder.nameView = (TextView) convertView.findViewById(R.id.nameView);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			
			if (holder != null) {
				 final AppInfo info = list.get(pos);
				 holder.iconView.setImageDrawable(new FastBitmapDrawable(info.iconBitmap));
				 holder.nameView.setText(info.name);
				 
				 if(isDeleteMode && !info.isSystemApp){
					 holder.deleteView.setVisibility(View.VISIBLE);
				 }else{
					 holder.deleteView.setVisibility(View.INVISIBLE);
				 }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return convertView;
	}

	static class ViewHolder {
		ImageView iconView;
		ImageView deleteView;
		TextView nameView;
	}

	@Override
	public void saveAfterOrder() {
		//DebugUtils.printInfo(TAG, "save app order");
		//DownloadGameSortTool.saveSortAppInfoToLocal(mContext, list);
	}
	
	public void notifyDataSetChanged(boolean isDeleteMode) {
		this.isDeleteMode = isDeleteMode;
		notifyDataSetChanged();
	}
}

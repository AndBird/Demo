package com.example.launcher;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;

/**
 * 可拖拽的GridView, 添加Item的交换效果(长按拖动)
 * 
 * @blog http://blog.csdn.net/xiaanming 
 * 
 * @author xiaanming
 *
 */
public class SortGridView extends GridView{
	private final String TAG = SortGridView.class.getSimpleName();
	
	/**
	 * DragGridView的item长按响应的时间， 默认是1000毫秒，也可以自行设置
	 */
	private long dragResponseMS = 1000;
	
	/**
	 * 是否可以拖拽，默认不可以
	 */
	private boolean isDrag = false;
	
	private int mDownX;
	private int mDownY;
	private int moveX;
	private int moveY;
	/**
	 * 正在拖拽的position
	 */
	private int mDragPosition;
	
	/**
	 * 刚开始拖拽的item对应的View
	 */
	private View mStartDragItemView = null;
	
	/**
	 * 震动器
	 */
	private Vibrator mVibrator;
	
	/**
	 * 我们拖拽的item对应的Bitmap
	 */
	private Bitmap mDragBitmap;
	
	/**
	 * 按下的点到所在item的上边缘的距离
	 */
	private int mPoint2ItemTop ; 
	
	/**
	 * 按下的点到所在item的左边缘的距离
	 */
	private int mPoint2ItemLeft;
	
	/**
	 * DragGridView距离屏幕顶部的偏移量
	 */
	private int mOffset2Top;
	
	/**
	 * DragGridView距离屏幕左边的偏移量
	 */
	private int mOffset2Left;
	
	/**
	 * 状态栏的高度
	 */
	private int mStatusHeight; 
	
	/**
	 * DragGridView自动向下滚动的边界值
	 */
	private int mDownScrollBorder;
	
	/**
	 * DragGridView自动向上滚动的边界值
	 */
	private int mUpScrollBorder;
	
	/**
	 * DragGridView自动滚动的速度
	 */
	private static final int speed = 20;
	/**
	 * item的移动动画是否结束
	 */
	private boolean mAnimationEnd = true;
	
	private DragGridBaseAdapter mDragAdapter;
	/**
	 * GridView的列数
	 */
	private int mNumColumns;
	/**
	 * 当GridView的numColumns设置为AUTO_FIT，我们需要计算GirdView具体的列数
	 */
	private int mColumnWidth;
	/**
	 * GridView是否设置了numColumns为具体的数字
	 */
	private boolean mNumColumnsSet;
	private int mHorizontalSpacing;
	private int mVerticalSpacing;
	
	public boolean isOnMeasure;
	
	/**顺序是否有变化*/
	private boolean hasChange = false;
	
	/**显示行数和行高*/
	private int lineNum = 0;
	private int lineHeight = 0;
	
	private DragListener mDragListener;
	public static final int DRAG_BITMAP_PADDING = 2;
	
	
	public void setDragListener(DragListener listener){
		this.mDragListener = listener;
	}
	
	public SortGridView(Context context) {
		this(context, null);
	}
	
	public SortGridView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public SortGridView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		mVibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
		mStatusHeight = getStatusHeight(context); //获取状态栏的高度
		
		if(!mNumColumnsSet){
			mNumColumns = AUTO_FIT;
		}
		
	}
	
	/**
	 * 删除item的动画效果
	 * @param position
	 */
	public void removeItemAnimation(final int position){
		mDragAdapter.removeItem(position);
		final ViewTreeObserver observer = getViewTreeObserver();
		observer.addOnPreDrawListener(new OnPreDrawListener() {
			
			@Override
			public boolean onPreDraw() {
				observer.removeOnPreDrawListener(this);
				animateReorder(position, getLastVisiblePosition() + 1 );
				return true;
			}
		} );
	}
	
	private Handler mHandler = new Handler();
	
	//用来处理是否为长按的Runnable
	private Runnable mLongClickRunnable = new Runnable() {
		
		@Override
		public void run() {
			// Make sure the drag was started by a long press as opposed to a long click.
	        if (!mStartDragItemView.isInTouchMode()) {
	            return;
	        }
			isDrag = true; //设置可以拖拽
			mVibrator.vibrate(50); //震动一下
			mStartDragItemView.setAlpha(0.2f);
			mStartDragItemView.setVisibility(View.INVISIBLE);//隐藏该item
			
			if(mDragListener != null){
				mDragListener.onLongClick();
			}
			beginDragShared(mStartDragItemView);
		}
	};
	
	

    public void beginDragShared(View child) {
        // The drag bitmap follows the touch point around on the screen
        final Bitmap b = mDragBitmap;

        final int bmpWidth = b.getWidth();
        final int bmpHeight = b.getHeight();

        int[] mTempXY = new int[2];
        float scale = mDragListener.getDragLayer().getLocationInDragLayer(child, mTempXY);
        int dragLayerX = Math.round(mTempXY[0] - (bmpWidth - scale * child.getWidth()) / 2);
        int dragLayerY = Math.round(mTempXY[1] - (bmpHeight - scale * bmpHeight) / 2 - DRAG_BITMAP_PADDING / 2);

        //int dragLayerX = downX - mPoint2ItemLeft + mOffset2Left;
        //int dragLayerY = downY - mPoint2ItemTop + mOffset2Top - mStatusHeight;
        
        mDragListener.startDrag(SortGridView.this, b, dragLayerX, dragLayerY, DragController.DRAG_ACTION_MOVE, scale);
        b.recycle();
    }
	
	
	@Override
	public void setAdapter(ListAdapter adapter) {
		super.setAdapter(adapter);
		
		if(adapter instanceof DragGridBaseAdapter){
			mDragAdapter = (DragGridBaseAdapter) adapter;
		}else{
			throw new IllegalStateException("the adapter must be implements DragGridAdapter");
		}
	}
	
	/**
	 * 获取列数
	 */
	@Override
	public void setNumColumns(int numColumns) {
		super.setNumColumns(numColumns);
		mNumColumnsSet = true;
		this.mNumColumns = numColumns;
	}
	
	/**
	 * 获取设置的列宽
	 */
	@Override
	public void setColumnWidth(int columnWidth) {
	    super.setColumnWidth(columnWidth);
	    mColumnWidth = columnWidth;
	}
	
	/**
	 * 获取水平方向的间隙
	 */
    @Override
	public void setHorizontalSpacing(int horizontalSpacing) {
		super.setHorizontalSpacing(horizontalSpacing);
		this.mHorizontalSpacing = horizontalSpacing;
	}
    
    
    /**
     * 获取竖直方向的间隙
     */
	@Override
	public void setVerticalSpacing(int verticalSpacing) {
		super.setVerticalSpacing(verticalSpacing);
		this.mVerticalSpacing = verticalSpacing;
	}

	/**
     * 若列数设置为AUTO_FIT，我们在这里面计算具体的列数
     */
	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		isOnMeasure = true;
        if (mNumColumns == AUTO_FIT) {
            int numFittedColumns;
            if (mColumnWidth > 0) {
                int gridWidth = Math.max(MeasureSpec.getSize(widthMeasureSpec) - getPaddingLeft()
                        - getPaddingRight(), 0);
                numFittedColumns = gridWidth / mColumnWidth;
                if (numFittedColumns > 0) {
                    while (numFittedColumns != 1) {
                        if (numFittedColumns * mColumnWidth + (numFittedColumns - 1)
                                * mHorizontalSpacing > gridWidth) {
                            numFittedColumns--;
                        } else {
                            break;
                        }
                    }
                } else {
                    numFittedColumns = 1;
                }
            } else {
                numFittedColumns = 2;
            }
            mNumColumns = numFittedColumns;
        } 

        
        
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }
	
	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		// TODO Auto-generated method stub
		isOnMeasure = false;
		super.onLayout(changed, l, t, r, b);
	}
	
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		// TODO Auto-generated method stub
		super.onSizeChanged(w, h, oldw, oldh);
		
		//设置行间距
		if(h > 0 && lineNum > 0){
			setVerticalSpacing((h - lineNum * lineHeight) / lineNum);
		}
	}
	
	
	/**设置行数和行高*/
	public void setLineParams(int lineNum, int lineHeight) {
		this.lineNum = lineNum;
		this.lineHeight = lineHeight;
	}


	/**
	 * 设置响应拖拽的毫秒数，默认是1000毫秒
	 * @param dragResponseMS
	 */
	public void setDragResponseMS(long dragResponseMS) {
		this.dragResponseMS = dragResponseMS;
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		switch(ev.getAction()){
		case MotionEvent.ACTION_DOWN:
			mDownX = (int) ev.getX();
			mDownY = (int) ev.getY();
			
			//根据按下的X,Y坐标获取所点击item的position
			mDragPosition = pointToPosition(mDownX, mDownY);
			
			
			if(mDragPosition == AdapterView.INVALID_POSITION){
				return super.dispatchTouchEvent(ev);
			}
			
			//使用Handler延迟dragResponseMS执行mLongClickRunnable
			mHandler.postDelayed(mLongClickRunnable, dragResponseMS);
			
			//根据position获取该item所对应的View
			mStartDragItemView = getChildAt(mDragPosition - getFirstVisiblePosition());
			
			//下面这几个距离大家可以参考我的博客上面的图来理解下
			mPoint2ItemTop = mDownY - mStartDragItemView.getTop();
			mPoint2ItemLeft = mDownX - mStartDragItemView.getLeft();
			
			mOffset2Top = (int) (ev.getRawY() - mDownY);
			mOffset2Left = (int) (ev.getRawX() - mDownX);
			
			//获取DragGridView自动向上滚动的偏移量，小于这个值，DragGridView向下滚动
			mDownScrollBorder = getHeight() / 5;
			//获取DragGridView自动向下滚动的偏移量，大于这个值，DragGridView向上滚动
			mUpScrollBorder = getHeight() * 4/5;
			
			
			//开启mDragItemView绘图缓存
			mStartDragItemView.setDrawingCacheEnabled(true);
			//获取mDragItemView在缓存中的Bitmap对象
			mDragBitmap = Bitmap.createBitmap(mStartDragItemView.getDrawingCache());
			//这一步很关键，释放绘图缓存，避免出现重复的镜像
			mStartDragItemView.destroyDrawingCache();
			
			break;
		case MotionEvent.ACTION_MOVE:
			int moveX = (int)ev.getX();
			int moveY = (int) ev.getY();
			
			//如果我们在按下的item上面移动，只要不超过item的边界我们就不移除mRunnable
			if(!isTouchInItem(mStartDragItemView, moveX, moveY)){
				mHandler.removeCallbacks(mLongClickRunnable);
			}
			break;
		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			mHandler.removeCallbacks(mLongClickRunnable);
			mHandler.removeCallbacks(mScrollRunnable);
			break;
		}
		return super.dispatchTouchEvent(ev);
	}

	
	/**
	 * 是否点击在GridView的item上面
	 * @param itemView
	 * @param x
	 * @param y
	 * @return
	 */
	private boolean isTouchInItem(View dragView, int x, int y){
		if(dragView == null){
			return false;
		}
		int leftOffset = dragView.getLeft();
		int topOffset = dragView.getTop();
		if(x < leftOffset || x > leftOffset + dragView.getWidth()){
			return false;
		}
		
		if(y < topOffset || y > topOffset + dragView.getHeight()){
			return false;
		}
		
		return true;
	}
	
	

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		//LauncherLogUtil.pringLogE(TAG, "onTouchEvent");
		if(isDrag){
			switch(ev.getAction()){
			case MotionEvent.ACTION_MOVE:
				moveX = (int) ev.getX();
				moveY = (int) ev.getY();
				
				//拖动item
				onDragItem(moveX, moveY);
				break;
			case MotionEvent.ACTION_UP:
				onStopDrag();
				isDrag = false;
				break;
			}
			return true;
		}
		return super.onTouchEvent(ev);
	}
	
	/**
	 * 拖动item，在里面实现了item镜像的位置更新，item的相互交换以及GridView的自行滚动
	 * @param x
	 * @param y
	 */
	private void onDragItem(int moveX, int moveY){
		//更新镜像的位置
		
		
		onSwapItem(moveX, moveY);
		
		//GridView自动滚动
		mHandler.post(mScrollRunnable);
	}
	
	
	/**
	 * 当moveY的值大于向上滚动的边界值，触发GridView自动向上滚动
	 * 当moveY的值小于向下滚动的边界值，触发GridView自动向下滚动
	 * 否则不进行滚动
	 */
	private Runnable mScrollRunnable = new Runnable() {
		
		@Override
		public void run() {
			int scrollY;
			if(getFirstVisiblePosition() == 0 || getLastVisiblePosition() == getCount() - 1){
				mHandler.removeCallbacks(mScrollRunnable);
			}
			
			if(moveY > mUpScrollBorder){
				 scrollY = speed;
				 mHandler.postDelayed(mScrollRunnable, 25);
			}else if(moveY < mDownScrollBorder){
				scrollY = -speed;
				 mHandler.postDelayed(mScrollRunnable, 25);
			}else{
				scrollY = 0;
				mHandler.removeCallbacks(mScrollRunnable);
			}
			
			smoothScrollBy(scrollY, 100);//时间控制滚动速度
		}
	};
	
	
	/**
	 * 交换item,并且控制item之间的显示与隐藏效果
	 * @param moveX
	 * @param moveY
	 */
	private void onSwapItem(int moveX, int moveY){
		//获取我们手指移动到的那个item的position
		final int tempPosition = pointToPosition(moveX, moveY);
		
		//假如tempPosition 改变了并且tempPosition不等于-1,则进行交换
		if(tempPosition != mDragPosition && tempPosition != AdapterView.INVALID_POSITION && mAnimationEnd){
			/**
			 * 交换item
			 */
			mDragAdapter.reorderItems(mDragPosition, tempPosition);
			/**
			 * 设置新到的位置隐藏
			 */
			mDragAdapter.setHideItem(tempPosition);
			
			final ViewTreeObserver observer = getViewTreeObserver();
			observer.addOnPreDrawListener(new OnPreDrawListener() {
				
				@Override
				public boolean onPreDraw() {
					observer.removeOnPreDrawListener(this);
					animateReorder(mDragPosition, tempPosition);
					mDragPosition = tempPosition;
					return true;
				}
			} );
			
			hasChange = true;
		}
	}
	
	/**
	 * 创建移动动画
	 * @param view
	 * @param startX
	 * @param endX
	 * @param startY
	 * @param endY
	 * @return
	 */
	private AnimatorSet createTranslationAnimations(View view, float startX,
			float endX, float startY, float endY) {
		ObjectAnimator animX = ObjectAnimator.ofFloat(view, "translationX",
				startX, endX);
		ObjectAnimator animY = ObjectAnimator.ofFloat(view, "translationY",
				startY, endY);
		AnimatorSet animSetXY = new AnimatorSet();
		animSetXY.playTogether(animX, animY);
		return animSetXY;
	}
	
	
	/**
	 * item的交换动画效果
	 * @param oldPosition
	 * @param newPosition
	 */
	private void animateReorder(final int oldPosition, final int newPosition) {
		boolean isForward = newPosition > oldPosition;
		List<Animator> resultList = new LinkedList<Animator>();
		if (isForward) {
			for (int pos = oldPosition; pos < newPosition; pos++) {
				View view = getChildAt(pos - getFirstVisiblePosition());
				if ((pos + 1) % mNumColumns == 0) {
					resultList.add(createTranslationAnimations(view,
							- (view.getWidth() + mHorizontalSpacing) * (mNumColumns - 1), 0,
							view.getHeight() + mVerticalSpacing, 0));
				} else {
					resultList.add(createTranslationAnimations(view,
							view.getWidth() + mHorizontalSpacing, 0, 0, 0));
				}
			}
		} else {
			for (int pos = oldPosition; pos > newPosition; pos--) {
				View view = getChildAt(pos - getFirstVisiblePosition());
				if ((pos) % mNumColumns == 0) {
					resultList.add(createTranslationAnimations(view,
							(view.getWidth() + mHorizontalSpacing) * (mNumColumns - 1), 0,
							-view.getHeight() - mVerticalSpacing, 0));
				} else {
					resultList.add(createTranslationAnimations(view,
							-view.getWidth() - mHorizontalSpacing, 0, 0, 0));
				}
			}
		}

		AnimatorSet resultSet = new AnimatorSet();
		resultSet.playTogether(resultList);
		resultSet.setDuration(300);
		resultSet.setInterpolator(new AccelerateDecelerateInterpolator());
		resultSet.addListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationStart(Animator animation) {
				mAnimationEnd = false;
			}

			@Override
			public void onAnimationEnd(Animator animation) {
				mAnimationEnd = true;
			}
		});
		resultSet.start();
	}
	
	/**
	 * 停止拖拽我们将之前隐藏的item显示出来，并将镜像移除
	 */
	private void onStopDrag(){
		View view = getChildAt(mDragPosition - getFirstVisiblePosition());
		if(view != null){
			view.setVisibility(View.VISIBLE);
		}
		mDragAdapter.setHideItem(-1);
		if(hasChange){
			hasChange = false;
			//排序顺序变化后保存状态
			mDragAdapter.saveAfterOrder();
		}
	}
	
	
	/**
	 * 获取状态栏的高度
	 * @param context
	 * @return
	 */
	private static int getStatusHeight(Context context){
        /*int statusHeight = 0;
        Rect localRect = new Rect();
        ((Activity) context).getWindow().getDecorView().getWindowVisibleDisplayFrame(localRect);
        statusHeight = localRect.top;
        if (0 == statusHeight){
            Class<?> localClass;
            try {
                localClass = Class.forName("com.android.internal.R$dimen");
                Object localObject = localClass.newInstance();
                int i5 = Integer.parseInt(localClass.getField("status_bar_height").get(localObject).toString());
                statusHeight = context.getResources().getDimensionPixelSize(i5);
            } catch (Exception e) {
                e.printStackTrace();
            } 
        }
        return statusHeight;*/
        
        
        int result = 0;  
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");  
        if (resourceId > 0) {  
            result = context.getResources().getDimensionPixelSize(resourceId);  
        }  
        return result;  
    }
	
	
	public static abstract class DragGridBaseAdapter<T> extends BaseAdapter implements DragGridBaseAdapterListener{
	 	public Context mContext;
        public List<T> mDragDatas;
        
    	/**用于记录当前拖动item的下标*/
        private int mHidePosition = -1;

        public DragGridBaseAdapter(Context context, List<T> dataList){
            this.mContext = context;
            this.mDragDatas = dataList;
        }

        @Override
    	public final View getView(int position, View convertView, ViewGroup parent) {
    		// TODO Auto-generated method stub
    		View v = getItemView(position, convertView, parent);
    		
    		//适配器刷新调用比数据交换后设置item的可见还要慢，所以存在item交换后不显示的问题
    		//解决拖动过程中导致某些item无缘无故隐藏的问题，因为布局复用的原因
    		if(v != null){
    			if(itemNeedVisible(position)){
    				v.setAlpha(1);
    				v.setVisibility(View.VISIBLE);
    			}else{
    				v.setAlpha(0.2f);
    				v.setVisibility(View.INVISIBLE);
    			}
    		}
    		return v;
    	}
    	
    	public abstract View getItemView(int position, View convertView, ViewGroup parent);
	
		/**
		 * 重新排列数据
		 * @param oldPosition
		 * @param newPosition
		 */
	    @Override
		public final void reorderItems(int oldPosition, int newPosition){
			T temp = mDragDatas.get(oldPosition);
			if(oldPosition < newPosition){
				for(int i=oldPosition; i<newPosition; i++){
					Collections.swap(mDragDatas, i, i+1);
				}
			}else if(oldPosition > newPosition){
				for(int i=oldPosition; i>newPosition; i--){
					Collections.swap(mDragDatas, i, i-1);
				}
			}
			mDragDatas.set(newPosition, temp);
		}
		
		
		/**
		 * 设置某个item隐藏
		 * @param hidePosition
		 */
	    @Override
		public final void setHideItem(int hidePosition){
			this.mHidePosition = hidePosition; 
			notifyDataSetChanged();
		}
		
		/**
		 * 删除某个item
		 * @param removePosition
		 */
	    @Override
		public final void removeItem(int removePosition){
			mDragDatas.remove(removePosition);
			notifyDataSetChanged();
		}
		
	
		/**是否需要显示*/
		private boolean itemNeedVisible(int position){
			if(position != mHidePosition){
				return true;
			}
			return false;
		}
	}


	public interface DragGridBaseAdapterListener {
		/**
		 * 重新排列数据
		 * @param oldPosition
		 * @param newPosition
		 */
		public void reorderItems(int oldPosition, int newPosition);
		
		
		/**
		 * 设置某个item隐藏
		 * @param hidePosition
		 */
		public void setHideItem(int hidePosition);
		
		/**
		 * 删除某个item
		 * @param removePosition
		 */
		public void removeItem(int removePosition);
		
	    /**排序后保存回调,需自己实现保存方式*/
		public void saveAfterOrder();
	}
}

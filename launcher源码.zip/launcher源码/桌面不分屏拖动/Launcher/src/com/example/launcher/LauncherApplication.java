package com.example.launcher;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;

public class LauncherApplication extends Application {
    private static final String TAG = LauncherApplication.class.getSimpleName();
    
    private AppLoadMode appLoadMode;
    private IconCache mIconCache;

    @Override
    public void onCreate() {
        super.onCreate();
        mIconCache = new IconCache(this);
        appLoadMode = new AppLoadMode(this, mIconCache);
    }


    /**
     * There's no guarantee that this function is ever called.
     */
    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    IconCache getIconCache() {
        return mIconCache;
    }

    AppLoadMode getAppLoadModel() {
        return appLoadMode;
    }

   

    public static boolean isScreenLandscape(Context context) {
        return context.getResources().getConfiguration().orientation ==
            Configuration.ORIENTATION_LANDSCAPE;
    }
}

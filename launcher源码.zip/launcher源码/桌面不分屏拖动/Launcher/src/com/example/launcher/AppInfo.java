package com.example.launcher;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.UserHandle;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Represents an app in AllAppsView.
 */
class AppInfo extends BaseItemInfo {
    private static final String TAG = AppInfo.class.getSimpleName();

    /**应用名*/
	public String name;
	/**包名*/
	public String packname;
	/**字节大小*/
	public long size;
	/**版本号*/
	public String versionName;
	/**文件路径*/
	public String path;
	/**启动intent*/
	public Intent intent;
	/**图标*/
	public Bitmap iconBitmap;
	/**是否选中*/
	public boolean isSelected;
	/**是系统应用*/
	public boolean isSystemApp;

    AppInfo() {
    	isSelected = false;
    	isSystemApp = false;
    }
    
    public ComponentName getComponent(){
    	if(intent == null){
    		return null;
    	}
    	return intent.getComponent();
    }
}

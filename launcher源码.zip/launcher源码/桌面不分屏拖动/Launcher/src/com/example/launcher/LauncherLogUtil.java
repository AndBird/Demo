package com.example.launcher;

import android.util.Log;

public class LauncherLogUtil {
	private static final boolean debug = true;
	
	public static void pringLogE(String tag, String msg){
		if(debug){
			Log.e(tag, msg);
		}
	}
}

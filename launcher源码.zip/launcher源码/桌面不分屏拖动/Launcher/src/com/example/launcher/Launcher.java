package com.example.launcher;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import com.example.launcher.AppLoadMode.AppLoadingCallBack;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.UserHandle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Launcher extends Activity implements AppLoadingCallBack{
	private final String TAG = Launcher.class.getSimpleName();
	
	private DragLayer mDragLayer;
	private ViewPager viewPager;
	private LinearLayout viewDotLay;
	private ImageView[] dots;
	
	private View loadingView;
	private TextView loadingTextView;
	
	
	private AppLoadMode appLoadMode;
	private IconCache iconCache;
	
	private List<AppInfo> mAppInfos;
	private LauncherPagerAdapter pagerAdapter;
	private List<SortGridView> sortGridViews = new ArrayList<SortGridView>();
	private List<AppListAdapter> appListAdapters = new ArrayList<AppListAdapter>();
	
	/**总页数*/
	private int totalPageNum = 0;
	/**当前页面index*/
	private int curPageIndex = 0;
	
	/**每页列数*/
	private final int pageColumnNum = 4;
	/**每页行数*/
	private final int pageLineNum = 5;
	/**每页显示的总个数*/
	private final int pageCellNum = pageColumnNum * pageLineNum;
	
	//主屏
	private TextView timeView;
	private TextView dateView;
	/**第一页显示多少个*/
	private final int firstPageShowNum = 8;
	
	/**是否处于应用删除模式*/
	private boolean isDeleteMode = false;
	private DragController mDragController;
	
	private DragListener mDragListener = new DragListener() {
		
		@Override
		public void scrollRight() {
			// TODO Auto-generated method stub
			int i = viewPager.getCurrentItem() + 1;
			if(i < totalPageNum){
				viewPager.setCurrentItem(i);
				setMoveTarget();
			}
		}
		
		@Override
		public void scrollLeft() {
			int i = viewPager.getCurrentItem() - 1;
			if(i >= 0){
				viewPager.setCurrentItem(i);
				setMoveTarget();
			}
		}
		
		@Override
		public void onLongClick() {
			isDeleteMode = true;
			udpateAllAppList();
		}
		
		@Override
		public boolean onExitScrollArea() {
			// TODO Auto-generated method stub
			return true;
		}
		
		@Override
		public boolean onEnterScrollArea(int x, int y, int direction) {
			// TODO Auto-generated method stub
			return true;
		}
		
		@Override
		public void onDragStart() {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onDragEnd() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public DragLayer getDragLayer() {
			// TODO Auto-generated method stub
			return mDragLayer;
		}

		@Override
		public void startDrag(View dragSource, Bitmap b, int dragLayerX, int dragLayerY,
				int dragAction, float initialDragViewScale) {
			if(mDragController != null){
				setMoveTarget();
				mDragController.startDrag(b, dragLayerX, dragLayerY, dragAction, initialDragViewScale);
			}
		}
	};
	
	private void setMoveTarget(){
		if(mDragController != null){
			int item = viewPager.getCurrentItem();
			mDragController.setMoveTarget(sortGridViews.get(item));
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.launcher);
		initView();
		registerTimeReceiver();
		setupViews();
	}
	
	
	private void initView(){
		mDragLayer = (DragLayer) findViewById(R.id.dragLayer);
		viewPager = (ViewPager) findViewById(R.id.viewPager);
		viewDotLay = (LinearLayout) findViewById(R.id.viewPager_dot);
		loadingView = findViewById(R.id.loading);
		loadingTextView = (TextView) findViewById(R.id.loadingText);
	}
	
	
	private void setupViews() {
		mDragController = new DragController(this);
        final DragController dragController = mDragController;
        // Setup the drag layer
        mDragLayer.setup(this, dragController);
        dragController.setDragLayer(mDragLayer);
        dragController.setMoveTarget(viewPager);
        dragController.setDragListener(mDragListener);
        
    	LauncherApplication application = (LauncherApplication) getApplication();
		appLoadMode =  application.getAppLoadModel();
		iconCache = application.getIconCache();
		
		appLoadMode.setAppLoadingCallBack(this);
		appLoadMode.startLoadApp(false);
    }
	
	private void updateViewPager(){
    	try {
    		totalPageNum = (int) Math.ceil((float) (mAppInfos.size() - firstPageShowNum) / pageCellNum) + 1;
    		viewPager.setOffscreenPageLimit(totalPageNum);
    		List<View> views = initPageView(viewPager);
    		pagerAdapter = new LauncherPagerAdapter(views);
    		viewPager.setAdapter(pagerAdapter);
    		initDots(viewPager, viewDotLay, totalPageNum);
    		dots[curPageIndex].setSelected(true);
            viewPager.setCurrentItem(curPageIndex);
		} catch (Exception e) {
			e.printStackTrace();
		} 
    }
	    
    /**定义viewpager的指示器*/
    private void initDots(ViewPager viewPager, LinearLayout dotLay, final int size){
        if(dotLay != null && size > 0){
            dotLay.removeAllViews();
            int w = convertDpToPx(getApplicationContext(), 5);
            int h = convertDpToPx(getApplicationContext(), 5);
            dots = new ImageView[size];
            for(int i = 0; i < size; i++){
                ImageView imageview = new ImageView(Launcher.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                lp.width = w;
                lp.height = h;
                lp.setMargins(5, 0, 5, 0);//10px
                imageview.setLayoutParams(lp);
                imageview.setScaleType(ImageView.ScaleType.FIT_XY);
                imageview.setImageResource(R.drawable.viewpager_dot_bg);
                dotLay.addView(imageview);
                dots[i] = imageview;
            }

            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int i, float v, int i1) {

                }

                @Override
                public void onPageSelected(int page) {
                	curPageIndex = page;
                    int index = page % size;
                    for(int i = 0; i < size; i++) {
                        if(i == index) {
                            dots[i].setSelected(true);
                        }else{
                            dots[i].setSelected(false);
                        }
                    }
                    LauncherLogUtil.pringLogE(TAG, "onPageSelected page=" + page);
                }

                @Override
                public void onPageScrollStateChanged(int i) {
                	  //LauncherLogUtil.pringLogE(TAG, "onPageScrollStateChanged state=" + i);    
                }
            });
        }
    }
	    
    private List<View> initPageView(ViewPager viewPager){
    	if(sortGridViews == null){
    		sortGridViews = new ArrayList<SortGridView>();
    	}else{
    		sortGridViews.clear();
    	}
    	if(appListAdapters == null){
    		appListAdapters = new ArrayList<AppListAdapter>();
    	}else{
    		appListAdapters.clear();
    	}
	   List<View> views = new ArrayList<View>();
       try {
           final LayoutInflater inflater = LayoutInflater.from(Launcher.this);
           for(int i = 0; i < totalPageNum; i++){
        	   int startIndex = 0;
               int endIndex = 0;
               View lay = null;
        	   if(0 == i){
        		   lay = inflater.inflate(R.layout.layout_main_launcher_page, viewPager, false);
        		   timeView = (TextView) lay.findViewById(R.id.timeView);
        		   dateView = (TextView) lay.findViewById(R.id.dateView);
        		   udpateTimeView();
        		   
        		   startIndex = i * pageCellNum;
                   endIndex = Math.min(startIndex + firstPageShowNum, mAppInfos.size() - 1);
        	   }else{
        		   lay = inflater.inflate(R.layout.layout_launcher_page, viewPager, false);
        		   
        		   startIndex = (i - 1) * pageCellNum + firstPageShowNum;
                   endIndex = Math.min(startIndex + pageCellNum, mAppInfos.size() - 1);
        	   }
        	   SortGridView gridView = (SortGridView) lay.findViewById(R.id.gridView);
        	   
        	   if(startIndex >= mAppInfos.size()){
        		   continue;
        	   }
    		   final List<AppInfo> list = mAppInfos.subList(startIndex, endIndex);
    		   AppListAdapter adapter = new AppListAdapter(getApplicationContext(), list);
    		  
    		  /* int vspace = gridView.getMeasuredHeight() - pageLineNum * convertDpToPx(getApplicationContext(), (52 + 30));
    		   gridView.setVerticalSpacing(vspace / (pageLineNum - 1));*/
    		   gridView.setLineParams(pageLineNum, convertDpToPx(getApplicationContext(), (52 + 30)));
    		   gridView.setDragListener(mDragListener);
    		   gridView.setAdapter(adapter);
    		   
    		   gridView.setOnItemClickListener(new OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						LauncherLogUtil.pringLogE(TAG, "click position=" + position);
						final AppInfo info = list.get(position);
						if(info != null){
							if(isDeleteMode){
								/*AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
								builder.setTitle("卸载应用");
								builder.setMessage("要卸载" + info.name + "吗?");
								builder.setNegativeButton("取消", null);
								builder.setPositiveButton("确定",
									new AlertDialog.OnClickListener(){
										@Override
										public void onClick(DialogInterface dialog, int which){
											startApplicationUninstallActivity(info);
										}
									});
								builder.create().show();*/
								
								startApplicationUninstallActivity(info);
							}else{
								startActivitySafely(view, info.intent, info);
							}
						}
					}
    		   });
    		   
    		   sortGridViews.add(gridView);
    		   appListAdapters.add(adapter);
    		   views.add(lay);
           }
		} catch (Exception e) {
			e.printStackTrace();
		}
       return views;
    }
    
    /**安全启动应用*/
    boolean startActivitySafely(final View v, final Intent intent, final Object tag) {
        boolean success = false;
        try {
        	success = startActivity(v, intent, tag);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.activity_not_found, Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Unable to launch. tag=" + tag + " intent=" + intent, e);
        }
        return success;
    }
    
    boolean startActivity(View v, Intent intent, Object tag) {
    	intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
            return true;
        } catch (SecurityException e) {
            Toast.makeText(this, R.string.activity_not_found, Toast.LENGTH_SHORT).show();
        }
        return false;
    }
    
    /**卸载应用*/
    void startApplicationUninstallActivity(AppInfo info) {
        if(info.isSystemApp) {
            int messageId = R.string.uninstall_system_app_text;
            Toast.makeText(this, messageId, Toast.LENGTH_SHORT).show();
        } else {
            String className = info.getComponent().getClassName();
            Intent intent = new Intent(
                    Intent.ACTION_DELETE, Uri.fromParts("package", info.packname, className));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(intent);
        }
    }
	
	class LauncherPagerAdapter extends PagerAdapter{
		private List<View> pageViews;
		
    	public LauncherPagerAdapter(List<View> list) {
			pageViews = list;
		}
        public int getCount() {
        	return pageViews == null ? 0 : pageViews.size();
        }
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }
        public int getItemPosition(Object object) {
            return super.getItemPosition(object);
        }
        public void destroyItem(View arg0, int arg1, Object arg2) {
        	//Log.e(TAG, "destroyItem=" + arg1);
           int pos = arg1 % pageViews.size();
           ((ViewPager) arg0).removeView(pageViews.get(pos));
        }
        public Object instantiateItem(View arg0, int arg1) {
        	//Log.e(TAG, "instantiateItem=" + arg1);
        	 int pos = arg1 % pageViews.size();
        	 View view = pageViews.get(pos);
        	 /**如果View已经在之前添加到了一个父组件，则必须先remove，否则会抛出IllegalStateException,当view个数小于4个时出现*/
        	 ViewParent vp = view.getParent();
             if (vp != null){
                 ViewGroup parent = (ViewGroup)vp;
                 parent.removeView(view);
             }

            ((ViewPager) arg0).addView(view);
            return view;
        }
	}
	
	@Override
	public void startLoading(boolean isReload) {
		if(!isReload){
			if(loadingView != null){
				loadingView.setVisibility(View.VISIBLE);
			}
			if(viewPager != null){
				viewPager.setVisibility(View.INVISIBLE);
			}
		}
	}
	
	@Override
	public void loadFinish(List<AppInfo> list, boolean isReload) {
		if(loadingView != null){
			loadingView.setVisibility(View.INVISIBLE);
		}
		if(viewPager != null){
			viewPager.setVisibility(View.VISIBLE);
		}
		mAppInfos = list;
		updateViewPager();
	}
	
	 /**
     * dp转px
     * */
    public static int convertDpToPx(Context context, int dp) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics()));
    }
    
    
    /**更新时间*/
    private void udpateTimeView(){
    	if(timeView != null){
    		Date date = new Date();
			SimpleDateFormat sd1 = new SimpleDateFormat("HH : mm");
			String str1 = sd1.format(date);
			timeView.setText(str1);
    	}
    	
    	if(dateView != null){
    		Date date = new Date();
    		SimpleDateFormat sd1 = new SimpleDateFormat("yyyy年MM月dd日");
			String str1 = sd1.format(date);
			dateView.setText(str1);
			
			String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
	        Calendar cal = Calendar.getInstance(); // 获得一个日历
            cal.setTime(date);
	        int w = cal.get(Calendar.DAY_OF_WEEK) - 1; // 指示一个星期中的某天。
	        if (w < 0){
	            w = 0;
	        }
	        dateView.append("   " + weekDays[w]);
    	}
    }
    
    
    private BroadcastReceiver timeBroadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
                if(intent.ACTION_TIME_TICK.equals(intent.getAction())){
                	udpateTimeView();//每一分钟更新时间
                }else if(intent.ACTION_TIME_CHANGED.equals(intent.getAction())){

                }
        }
    };
    
    private void registerTimeReceiver(){
    	if(timeBroadcastReceiver != null){
	    	IntentFilter filter = new IntentFilter(); 
	        filter.addAction(Intent.ACTION_TIME_TICK);
	        filter.addAction(Intent.ACTION_TIME_CHANGED);
	        registerReceiver(timeBroadcastReceiver, filter);
    	}
    }
    
    private void unregisterTimeReceiver(){
    	if(timeBroadcastReceiver != null){
	    	unregisterReceiver(timeBroadcastReceiver);
    	}
    }
    
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	super.onDestroy();
    	unregisterTimeReceiver();
    }

	private void udpateAllAppList(){
		if(appListAdapters != null){
			for(int i = 0; i < appListAdapters.size(); i++){
				AppListAdapter adapter = appListAdapters.get(i);
				adapter.notifyDataSetChanged(isDeleteMode);
			}
		}
	}
	
	@Override
	public void onBackPressed() {
		if(isDeleteMode){
			isDeleteMode = false;
			udpateAllAppList();
			return;
		}
		super.onBackPressed();
	}
	
	public DragLayer getDragLayer(){
		return mDragLayer;
	}
	
	
	public class PackageChangedReceiver extends BroadcastReceiver {
	    @Override
	    public void onReceive(final Context context, Intent intent) {
	        final String packageName = intent.getData().getSchemeSpecificPart();
	        if (packageName == null || packageName.length() == 0) {
	            // they sent us a bad intent
	            return;
	        }
	        LauncherLogUtil.pringLogE(TAG, "packageName=" + packageName);
	        if(appLoadMode != null){
	        	appLoadMode.startLoadApp(true);
	        }
	        
	    }
	}
}

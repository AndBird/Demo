package com.example.launcher;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.os.UserHandle;
import java.util.HashMap;

/**
 * Cache of application icons.  Icons can be made from any thread.
 */
public class IconCache {
    @SuppressWarnings("unused")
    private static final String TAG = "Launcher.IconCache";

    private static final int INITIAL_ICON_CACHE_CAPACITY = 50;

    private static class CacheEntry {
        public Bitmap icon;
        public String title;
        public CharSequence contentDescription;
    }

    private static class CacheKey {
        public ComponentName componentName;
        public UserHandle user;

        CacheKey(ComponentName componentName, UserHandle user) {
            this.componentName = componentName;
            this.user = user;
        }

        @Override
        public int hashCode() {
            return componentName.hashCode() + user.hashCode();
        }

        @Override
        public boolean equals(Object o) {
            CacheKey other = (CacheKey) o;
            return other.componentName.equals(componentName) && other.user.equals(user);
        }
    }

    private final Bitmap mDefaultIcon;
    private final LauncherApplication mContext;
    private final PackageManager mPackageManager;
    private final HashMap<CacheKey, CacheEntry> mCache =
            new HashMap<CacheKey, CacheEntry>(INITIAL_ICON_CACHE_CAPACITY);
    private int mIconDpi;

    public IconCache(LauncherApplication context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);

        mContext = context;
        mPackageManager = context.getPackageManager();
        mIconDpi = activityManager.getLauncherLargeIconDensity();
        LauncherLogUtil.pringLogE(TAG, "mIconDpi=" + mIconDpi);
        // need to set mIconDpi before getting default icon
        mDefaultIcon = makeDefaultIcon();
    }


    private Bitmap makeDefaultIcon() {
        Drawable d = mContext.getResources().getDrawable(R.drawable.app_icon_default);
        Bitmap b = Bitmap.createBitmap(Math.max(d.getIntrinsicWidth(), 1),
                Math.max(d.getIntrinsicHeight(), 1),
                Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        d.setBounds(0, 0, b.getWidth(), b.getHeight());
        d.draw(c);
        c.setBitmap(null);
        return b;
    }

    /**
     * Remove any records for the supplied ComponentName.
     */
    public void remove(ComponentName componentName) {
        synchronized (mCache) {
            mCache.remove(componentName);
        }
    }

    /**
     * Empty out the cache.
     */
    public void flush() {
        synchronized (mCache) {
            mCache.clear();
        }
    }

    public Bitmap getIcon(Intent intent, String title, Drawable drawable, UserHandle user) {
        synchronized (mCache) {
            ComponentName component = intent.getComponent();

            if (component == null || drawable == null) {
                return mDefaultIcon;
            }

            CacheEntry entry = cacheLocked(component, title, drawable, user);
            return entry.icon;
        }
    }

    public Bitmap getIcon(ComponentName component, String title, Drawable drawable) {
        synchronized (mCache) {
            if(drawable == null || component == null) {
                return mDefaultIcon;
            }

            CacheEntry entry = cacheLocked(component, title, drawable, Process.myUserHandle());
            return entry.icon;
        }
    }

    public boolean isDefaultIcon(Bitmap icon) {
        return mDefaultIcon == icon;
    }

    /**Process.myUserHandle()*/
    private CacheEntry cacheLocked(ComponentName componentName, String title, Drawable drawable, UserHandle user) {
        CacheKey cacheKey = new CacheKey(componentName, user);
        CacheEntry entry = mCache.get(cacheKey);
        if (entry == null) {
            entry = new CacheEntry();
            mCache.put(cacheKey, entry);
            entry.title = title;
            entry.contentDescription = title;
            entry.icon = Utilities.createIconBitmap(drawable, mContext);
        }
        return entry;
    }
}

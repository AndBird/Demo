package com.example.launcher;

import android.content.Intent;
import android.os.UserHandle;


/**
 * Represents an item in the launcher.
 */
class BaseItemInfo {

    static final int NO_ID = -1;

    /**桌面容器id*/
    int screen = NO_ID;
    
    public int getScreen() {
		return screen;
	}

	public void setScreen(int screen) {
		this.screen = screen;
	}

	public int getCellIndex() {
		return cellIndex;
	}

	public void setCellIndex(int cellIndex) {
		this.cellIndex = cellIndex;
	}


	int cellIndex = NO_ID;

    UserHandle user;

    BaseItemInfo() {
        user = android.os.Process.myUserHandle();
    }

    BaseItemInfo(BaseItemInfo info) {
        
    }

    static String getPackageName(Intent intent) {
        if (intent != null) {
            String packageName = intent.getPackage();
            if (packageName == null && intent.getComponent() != null) {
                packageName = intent.getComponent().getPackageName();
            }
            if (packageName != null) {
                return packageName;
            }
        }
        return "";
    }
    
    static String getClassName(Intent intent) {
    	String className = "";
        if (intent != null) {
            if (intent.getComponent() != null) {
            	className = intent.getComponent().getClassName();
            }
            if (className != null) {
                return className;
            }
        }
        return "";
    }

   
    @Override
    public String toString() {
        return "Item(" + "screen=" + screen + " cellIndex=" + cellIndex + ")";
    }
}

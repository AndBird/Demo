package com.example.launcher;

import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import android.content.Context;
import android.text.TextUtils;

/**应用本地排序*/
public class AppLocalSortTool{
	private static final String TAG = AppLocalSortTool.class.getSimpleName();
	
	private static final String SAVE_SCREEN_INDEX = "screen";
	private static final String SAVE_CELL_INDEX = "cellIndex";
	
	/**是否是第一次加载应用列表(key)*/
	private static final String IS_FIRST_LOAD = "is_first_load";
	
	/**
	 * 获取保存文件名
	 * 
	 * */
	private static String getSaveFileName(){
		return "local_app_sort_save_filename";
	}
	
	
	/**保存数据到本地*/
	public static void saveAppSortInfoToLocal(Context context, List<AppInfo> appList){
		try {
			if(appList != null){
				for(int i = 0; i < appList.size(); i++){
					AppInfo info = appList.get(i);
					String result = changeAppSortInfoToJsonString(info);
					LauncherLogUtil.pringLogE(TAG, "save info=" + result);
					SharePreferenceTool.setParam(context, getSaveFileName(), info.packname, result);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**信息转换成json数组字符串*/
	public static String changeAppSortInfoToJsonString(AppInfo appInfo){
		String result = "";
		try {
			if(appInfo != null){
				JSONObject jsonObject = new JSONObject();
				jsonObject.put(SAVE_SCREEN_INDEX, appInfo.getScreen());
				jsonObject.put(SAVE_CELL_INDEX, appInfo.getCellIndex());
				result = jsonObject.toString();
				//LauncherLogUtil.pringLogE(TAG, "save info=" + result);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	

	public static boolean deleteSaveInfoByKey(Context context, String key){
		return SharePreferenceTool.removePrefKey(context, getSaveFileName(), key);
	}
		
	public static void deleteAllSaveInfo(Context context){
		 SharePreferenceTool.clearPref(context, getSaveFileName());
	}

	public static JSONObject getSaveInfoByKey(Context context, String key){
		try {
			if(TextUtils.isEmpty(key)){
                return null;
            }
			String data = (String)SharePreferenceTool.getParam(context, getSaveFileName(), key, null);
			if(!TextUtils.isEmpty(data)){
                return new JSONObject(data);
            }
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static boolean hasSaveInfoByKey(Context context, String key){
		if(TextUtils.isEmpty(key)){
			return false;
		}
		return SharePreferenceTool.hasKey(context, getSaveFileName(), key);
	}
	
	
	public static int getAppScreenIndex(JSONObject json){
		try {
			if(json != null && json.has(SAVE_SCREEN_INDEX)){
				return json.getInt(SAVE_SCREEN_INDEX);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public static int getAppCellIndex(JSONObject json){
		try {
			if(json != null && json.has(SAVE_CELL_INDEX)){
				return json.getInt(SAVE_CELL_INDEX);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	/**是否是第一次加载app*/
	public static boolean isFirstLoadApp(Context context){
		return SharePreferenceTool.getPrefBoolean(context, IS_FIRST_LOAD, true);
	}
	
	/**修改是否是第一次加载app的标识*/
	public static boolean changeFirstLoadApp(Context context, boolean isFirstLoad){
		return SharePreferenceTool.setPrefBoolean(context, IS_FIRST_LOAD, isFirstLoad);
	}
}

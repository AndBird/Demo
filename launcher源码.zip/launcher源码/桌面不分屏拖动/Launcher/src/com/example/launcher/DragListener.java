package com.example.launcher;

import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.View;


public interface DragListener {
	
	/**进入长按*/
	void onLongClick();
	
    void onDragStart();
    
    /**
     * The drag has ended
     */
    void onDragEnd();
    
    
    void scrollLeft();
    void scrollRight();

    /**
     * The touch point has entered the scroll area; a scroll is imminent.
     * This event will only occur while a drag is active.
     *
     * @param direction The scroll direction
     */
    boolean onEnterScrollArea(int x, int y, int direction);

    /**
     * The touch point has left the scroll area.
     * NOTE: This may not be called, if a drop occurs inside the scroll area.
     */
    boolean onExitScrollArea();
    
    
    DragLayer getDragLayer();
    
    
    public void startDrag(View dragSource, Bitmap b, int dragLayerX, int dragLayerY, int dragAction, 
            float initialDragViewScale);
}

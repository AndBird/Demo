package com.example.launcher;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Handler;


/**App加载*/
public class AppLoadMode{
	private final String TAG = AppLoadMode.class.getSimpleName();
	
	private LauncherApplication application;
	private IconCache mIconCache;
	
	private ArrayList<AppInfo> mAppList = null;
	private boolean isLoading = false;
	private Handler mHandler = new Handler();
	
	private AppLoadingCallBack mAppLoadingCallBack = null;
	
	public interface AppLoadingCallBack{
		/**开始加载安装程序
		 * 
		 * */
		public void startLoading(boolean isReload);
		/**加载完成*/
		public void loadFinish(List<AppInfo> list, boolean isReload);
	}
	
	public AppLoadMode(LauncherApplication application, IconCache iconCache) {
		this.application = application;
		this.mIconCache = iconCache;
		this.mAppList = new ArrayList<AppInfo>(40);
	}
	
	
	public void setAppLoadingCallBack(AppLoadingCallBack appLoadingCallBack){
		this.mAppLoadingCallBack = appLoadingCallBack;
	}
	
	/**
	 * @param isReload : true=>重新加载
	 * 
	 * 
	 * */
	public void startLoadApp(boolean isReload){
		if(isLoading){
			LauncherLogUtil.pringLogE(TAG, "an thread is loading");
			return ;
		}
		getInstalledApp(isReload);
	}
	
	/**获取已安装的程序*/
	private void getInstalledApp(final boolean isReload){
		  LauncherLogUtil.pringLogE(TAG, "start getInstalledApp");
		  isLoading = true;
		  new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					mHandler.post(new Runnable() {
						@Override
						public void run() {
							if(mAppLoadingCallBack != null){
								mAppLoadingCallBack.startLoading(isReload);
							}
						}
					});
					  mAppList.clear();
					  PackageManager packageManager = application.getPackageManager();
			          List<ApplicationInfo> packages = packageManager.getInstalledApplications(0);
			          Iterator<ApplicationInfo> l = packages.iterator();
			          while (l.hasNext()){
			              ApplicationInfo app = (ApplicationInfo) l.next();
			        	  if((app.flags & ApplicationInfo.FLAG_SYSTEM) > 0) {//系统自带
			        		  continue ;
			    		  }
			              
			              AppInfo info = new AppInfo();
			        	  if((app.flags & ApplicationInfo.FLAG_SYSTEM) > 0) {//系统自带
			        		  info.isSystemApp = true;
			    		  }else{
			    			  info.isSystemApp = false;
			    		  }
			              
			    		  String packname = app.packageName;//包名
			    		  info.intent = packageManager.getLaunchIntentForPackage(packname);
			    		  if(info.intent == null){
			    			  //一些系统引用无法启动，无mainActivity
			    			  continue;
			    		  }
			    		  
			    		  if(packname.equals(application.getPackageName())){
			    			  //过滤掉桌面自身
			    			  continue;
			    		  }
			    		  
			    		  
			              String appDir = app.publicSourceDir;//程序的路径
			              String label = "";
			              String  versionName = null;
			              try {
			                  label = packageManager.getApplicationLabel(app).toString();//Label
			                  PackageInfo pInfo = packageManager.getPackageInfo(packname, Context.MODE_APPEND);
			                  //versioncode = pInfo.versionCode + "";//版本号
			                  versionName = pInfo.versionName + "";//版本名
			             } catch (Exception e) {
			                  e.printStackTrace();
			             }
			              
			              info.name = label;
			              info.packname = packname;
			              File appFile = new File(appDir);//由路径创建一个File
			              info.size = appFile.length();
			              info.path = appDir;
			              info.versionName = versionName;
			              //Drawable icon = app.loadIcon(packageManager);
			              Drawable icon = packageManager.getApplicationIcon(app);//得到图标信息   
			              info.iconBitmap = mIconCache.getIcon(info.getComponent(), label, icon);
			              mAppList.add(info);
			          }
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					isLoading = false;
				}
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						if(mAppLoadingCallBack != null){
							@SuppressWarnings("unchecked")
							List<AppInfo> list = (ArrayList<AppInfo>) mAppList.clone();
							mAppLoadingCallBack.loadFinish(list, isReload);
						}
					}
				});
			}
		}).start();
	  }
	
	
}

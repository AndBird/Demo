package com.example.fragmentdemo;

import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

public class MyApplication extends Application {

	private List<Activity> list = new LinkedList<Activity>();
	private static MyApplication myApp;
	public static MyApplication getInstance()
	{
		return myApp;
	}
	@Override
	public void onCreate(){
		super.onCreate();
		myApp = this;
	}
	
	
	public void addActivity(Activity activity)
	{
		list.add(activity);
	}
	
	public Activity removeTopActivity(){
		return list.remove(list.size() - 1);
	}
	
	public Activity getTopActivity(){
		return list.get(list.size() - 1);
	}
	
	public void exitApp(){
		for(int i = list.size() - 1;i >= 0;i--){
			list.get(i).finish();
		}
	}
}
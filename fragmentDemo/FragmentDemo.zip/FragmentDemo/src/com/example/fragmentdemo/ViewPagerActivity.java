package com.example.fragmentdemo;

import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class ViewPagerActivity extends Activity{
	private final String TAG = ViewPagerActivity.class.getName();
	private LinearLayout tabLayout;
	private ViewPager viewPager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_viewpager_fragment);
		initView();
	}
	
	private void initView(){
		tabLayout = (LinearLayout) findViewById(R.id.tab_layout);
		tabLayout.setVisibility(View.GONE);
		viewPager = (ViewPager) findViewById(R.id.viewPager);

		initViewPager();
	}
	
	
	
	private void initViewPager(){
		 	List<ImageView> views = new ArrayList<ImageView>();  
		 	for(int i = 0; i < 4; i ++){
		 		ImageView image = new ImageView(getApplicationContext());
		 		image.setImageResource(R.drawable.ic_launcher);
		 		views.add(image);
		 	}
	        
	        //��ViewPager����������   
	        viewPager.setAdapter(new GuidePageAdapter(views));  
	        viewPager.setCurrentItem(0);
	}
	
	 // ָ��ҳ������������
    class GuidePageAdapter extends PagerAdapter {
    	private List<ImageView> pageViews;
    	public GuidePageAdapter(List<ImageView> list) {
			pageViews = list;
		}
        public int getCount() {
            return pageViews == null ? 0 : pageViews.size();
        }
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }
        public int getItemPosition(Object object) {
            return super.getItemPosition(object);
        }
        public void destroyItem(View arg0, int arg1, Object arg2) {
            ((ViewPager) arg0).removeView(pageViews.get(arg1));
        }
        public Object instantiateItem(View arg0, int arg1) {
            ((ViewPager) arg0).addView(pageViews.get(arg1));
            return pageViews.get(arg1);
        }
        public void restoreState(Parcelable arg0, ClassLoader arg1) {
        }
        public Parcelable saveState() {
            return null;
        }
        public void startUpdate(View arg0) {
        }
        public void finishUpdate(View arg0) {
        }
    }
}

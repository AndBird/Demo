package com.example.fragmentdemo;

import java.util.ArrayList;
import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ViewPagerFragmentActivity extends FragmentActivity implements OnPageChangeListener{
	private final String TAG = ViewPagerFragmentActivity.class.getName();
	private ImageButton back;
	private LinearLayout tabLayout;
	private TextView[] tabViews;
	private ViewPager viewPager;
	
	private ArrayList<Fragment> fragmentList;  
	private int curSelect = -1;//
	private int totalTabs = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_viewpager_fragment);
		initView();
	}
	
	private void initView(){
		tabLayout = (LinearLayout) findViewById(R.id.tab_layout);
		viewPager = (ViewPager) findViewById(R.id.viewPager);

		initTabItemView();
		initViewPager();
	}
	
	private void initTabItemView(){
		totalTabs = tabLayout.getChildCount();
		tabViews = new TextView[totalTabs];
		for(int i = 0;i < totalTabs;i++){
    		tabViews[i] = (TextView) tabLayout.getChildAt(i);
    		tabViews[i].setTag(i);
    		tabViews[i].setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					int position = (Integer)v.getTag();
					if(curSelect != position){
						setSelectItem(position, true);
					}
				}
			});
    	}
	}
	
	private void initViewPager(){
		 	fragmentList = new ArrayList<Fragment>();  
		 	for(int i = 0; i < totalTabs; i ++){
		 		Fragment fragment = new TestFragment3(null, i);  
		 		fragmentList.add(fragment);  
		 	}
	        
	        //��ViewPager����������   
	        viewPager.setAdapter(new MyFragmentPagerAdapter(getSupportFragmentManager(), fragmentList));  
	        setSelectItem(0, true);//���õ�ǰ��ʾ��ǩҳΪ��һҳ   
	        viewPager.setOnPageChangeListener(this);//ҳ��仯ʱ�ļ�����   
	}
	
	private void setSelectItem(int index, boolean change){
		if(curSelect >= 0){//����֮ǰ��ѡ�е�view
			 tabViews[curSelect].setTextColor(Color.BLACK);
		}
		
		 if(change){
			 viewPager.setCurrentItem(index);//���õ�ǰ��ʾ
		 }
		 tabViews[index].setTextColor(Color.RED);//���õ�ǰ��ʾ��ǩҳ
		 curSelect = index;
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		setSelectItem(arg0, false);
	}  
	
	
	public class MyFragmentPagerAdapter extends FragmentPagerAdapter{  
	    ArrayList<Fragment> list;  
	    public MyFragmentPagerAdapter(FragmentManager fm,ArrayList<Fragment> list) {  
	        super(fm);  
	        this.list = list;    
	    }  
	        
	    @Override  
	    public int getCount() {  
	        return list == null ? 0 : list.size();  
	    }  
	      
	    @Override  
	    public Fragment getItem(int arg0) {  
	        return list.get(arg0);  
	    }    
	}
}

package com.example.fragmentdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class WelecomeActivity extends Activity{
	private Button btn1, btn2, btn3, btn4;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welecome);
		btn1 = (Button) findViewById(R.id.btn1);
		btn2 = (Button) findViewById(R.id.btn2);
		btn3 = (Button) findViewById(R.id.btn3);
		btn4 = (Button) findViewById(R.id.btn4);
		
		/**fragment*/
		btn1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(WelecomeActivity.this, FragmentDemoActivity.class));
			}
		});
		
		/**fragment+tabhost*/
		btn2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(WelecomeActivity.this, FragmentTabHostActivity.class));
			}
		});
		
		/**viewpager+fragment*/
		btn3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(WelecomeActivity.this, ViewPagerFragmentActivity.class));
			}
		});
		
		/**viewpager��ʹ��*/
		btn4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(WelecomeActivity.this, ViewPagerActivity.class));
			}
		});
	}
}

/** Automatically generated file. DO NOT MODIFY */
package com.example.fragmentandviewpagerdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
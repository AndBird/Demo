package com.example.fragmentandviewpagerdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

/**���fragment�ص�����*/
public class FragmentOverLapDemoActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fragment_overlap_demo);
		
		//�򵥽���ص�
		findViewById(R.id.btn1).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(FragmentOverLapDemoActivity.this, FragmentOverLap1Activity.class));
			}
		});
		
		//��ԭ����ԭ��
		findViewById(R.id.btn2).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(FragmentOverLapDemoActivity.this, FragmentOverLap2Activity.class));
			}
		});
	}
}

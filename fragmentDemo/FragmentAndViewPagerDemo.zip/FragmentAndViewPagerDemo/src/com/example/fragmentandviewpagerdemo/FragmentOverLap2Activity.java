package com.example.fragmentandviewpagerdemo;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.test.fragment.TestFragment1;
import com.test.fragment.TestFragment2;
import com.test.fragment.TestLazyTypeFragment;
import com.test.fragment.TypeFragment;

/**Fragment�ص���ͨ����ԭ(����)ԭ��������ص�����*/
public class FragmentOverLap2Activity extends FragmentActivity{
	private static final String TAG = FragmentOverLap2Activity.class.getSimpleName();
	
	//���浱ǰfragment��index
	private final static String SAVE_SELECT_INDEX = "save_select_index";
	private Fragment[] fragments;
	private int pageSize = 4;
	private FragmentManager fm;
	private Fragment mContent;
	private int curSelect = 0;
	private int default_select = 0;
	
	private TextView[] menuViews;
	
	private Bundle savedInstanceState = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 //ȡ������ǰ��ҳ����
		 this.savedInstanceState = savedInstanceState;
		 if(savedInstanceState != null){
      		default_select = savedInstanceState.getInt(SAVE_SELECT_INDEX);
         	Log.e(TAG, "onCreate select=" + default_select);
      	 }else{
      		 default_select = 0;
      	 }
		setContentView(R.layout.activity_fragment_overlap);
		initView();
	}
	
	private void initView(){
		initFragment();
        initMenuView();
        
        if(savedInstanceState == null){
			fm = this.getSupportFragmentManager();
			FragmentTransaction ft = fm.beginTransaction();
			ft.replace(R.id.fragmentContent, fragments[default_select]);
			ft.commit();
			mContent = fragments[default_select];
			setSelectPage(default_select);
        }else{
        	mContent = fragments[default_select];
        	setSelectPage(default_select);
        }
	}
	
    private void initMenuView(){
         try {
             LinearLayout menuLay = (LinearLayout) findViewById(R.id.menu_layout);
             menuViews = new TextView[pageSize];

             for(int i = 0; i < pageSize; i++) {
                 menuViews[i] = (TextView) menuLay.getChildAt(i);
                 menuViews[i].setTag(i);
             	
                 menuViews[i].setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                     	try {
                             int index = Integer.parseInt(v.getTag().toString());
                             setViewPagerCurrentItem(index);
 						} catch (Exception e) {
 							e.printStackTrace();
 						}
                     }
                 });
             }
         } catch (Exception e) {
             e.printStackTrace();
         }
     }
	     
     /**����ѡ��index ҳ��*/
     public void setViewPagerCurrentItem(int index){
     	try {
              switchPage(fragments[index], index);
              setSelectPage(index);
              curSelect = index;
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
     }
	     

     /**��ʼ��fragment*/
     private void initFragment(){
     	try {
 		   if(fragments == null){
 			   fragments = new Fragment[pageSize];
		   }
 		   
 		   if(fragments[0] == null){
 			   fragments[0] = new TestFragment1();
 		   }
 		   
 		   if(fragments[1] == null){
 			   fragments[1] = new TestFragment2();
 		   }
 		   
 		   if(fragments[2] == null){
 			   fragments[2] = new TypeFragment();
     			Bundle bundle = new Bundle();
  				bundle.putString(TypeFragment.BUNDLE_TYPE, null);
  				bundle.putInt(TypeFragment.BUNDLE_INDEX, 3);
  				fragments[2].setArguments(bundle);
 		   }
 		   
 		   if(fragments[3] == null){
 			   fragments[3] = new TestLazyTypeFragment();
 			   Bundle bundle = new Bundle();
			   bundle.putString(TestLazyTypeFragment.BUNDLE_TYPE, "");
			   bundle.putInt(TestLazyTypeFragment.BUNDLE_INDEX, 4);
			   fragments[3].setArguments(bundle);
 		   }
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
     }

	    
     private void setSelectPage(int index){
     	try {
           for(int i = 0; i < pageSize; i++){
               if(i == index){
                   setMenuState(i, true);
               }else{
                   setMenuState(i, false);
               }
           }
 		} catch (Exception e) {
 			e.printStackTrace();
 		}      
     }

     private void setMenuState(int index, boolean select){
         try {
    	 	if(select){
        		menuViews[index].setBackgroundColor(Color.RED);
    	 	}else{
    	 		menuViews[index].setBackgroundColor(Color.WHITE);
    	 	}
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
     }
	
	private void switchPage(Fragment to, int index){
		try {
			 if(mContent != to){
				FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
				if(!to.isAdded()){
					transaction.hide(mContent).add(R.id.fragmentContent, to).commit();
				}else{
					transaction.hide(mContent).show(to).commit();
				}
				mContent = to;
				curSelect = index;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
  /**
   * ��������ص�����
   * */
   @Override
    protected void onSaveInstanceState(Bundle outState){
    	//���浱ǰҳ���λ��
    	outState.putInt(SAVE_SELECT_INDEX, curSelect);
    	super.onSaveInstanceState(outState);
    	Log.e(TAG, "onSaveInstanceState curSelect=" + curSelect);
    }
    
   //��onStart֮��,onResume֮ǰ����
    /*@Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
    	super.onRestoreInstanceState(savedInstanceState);
    	default_select = savedInstanceState.getInt(SAVE_SELECT_INDEX);
    	Log.e(TAG, "onRestoreInstanceState select=" + default_select);
    }*/
    
    /**ͨ����ԭ����ص�
     * <br>�����Activity���պ��ؽ�����ôonAttachFragment����onCreate()ǰ����,����ʱ��ʾ
     * �����ٸ�Fragment������ͻ���ö��ٴ���дonAttachFragment���������µ�Fragmentָ����
     * ԭ��δ�����ٵ�fragment
     * */
    @Override
    public void onAttachFragment(Fragment fragment) {
    	// TODO Auto-generated method stub
    	//super.onAttachFragment(fragment);
    	if(fragments == null){
    		fragments = new Fragment[pageSize];
    	}
    	
    	//fragments[0]Ϊnullʱ����ʾ���պ��ؽ�(fragment��Ϊ��)�����½�
    	if(fragments[0] == null && fragment instanceof TestFragment1){
    		fragments[0] = fragment;
    	}
    	
    	if(fragments[1] == null && fragment instanceof TestFragment2){
    		fragments[1] = fragment;
    	}
    	
    	if(fragments[2] == null && fragment instanceof TypeFragment){
    		fragments[2] = fragment;
    	}
    	
    	if(fragments[3] == null && fragment instanceof TestLazyTypeFragment){
    		fragments[3] = fragment;
    	}
    	
    	/*
    	 * ���ڲ���û����ʾ����fragment����Ҫ��initFragment()�г�ʼ��,initFragment��
    	 * ��activity�����������Զ����ã�����������
    	 * */
    }
    
    
    /**
	 * end ��������ص�����*/
}

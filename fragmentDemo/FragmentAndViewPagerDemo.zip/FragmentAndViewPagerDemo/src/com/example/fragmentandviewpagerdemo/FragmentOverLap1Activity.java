package com.example.fragmentandviewpagerdemo;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.test.fragment.TestFragment1;
import com.test.fragment.TestFragment2;
import com.test.fragment.TestLazyTypeFragment;
import com.test.fragment.TypeFragment;

/**Fragment�ص����򵥽��*/
public class FragmentOverLap1Activity  extends FragmentActivity{
	private static final String TAG = FragmentOverLap1Activity.class.getSimpleName();
	
	private Fragment[] fragments;
	private int pageSize = 4;
	private FragmentManager fm;
	private Fragment mContent;
	private int curSelect = 0;
	
	private TextView[] menuViews;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fragment_overlap);
		initView();
	}
	
	private void initView(){
		initFragment();
        initMenuView();

		fm = this.getSupportFragmentManager();
		FragmentTransaction ft = fm.beginTransaction();
		ft.replace(R.id.fragmentContent, fragments[0]);
		ft.commit();
		mContent = fragments[0];
		setSelectPage(0);
	}
	
    private void initMenuView(){
         try {
             LinearLayout menuLay = (LinearLayout) findViewById(R.id.menu_layout);
             menuViews = new TextView[pageSize];

             for(int i = 0; i < pageSize; i++) {
                 menuViews[i] = (TextView) menuLay.getChildAt(i);
                 menuViews[i].setTag(i);
             	
                 menuViews[i].setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                     	try {
                             int index = Integer.parseInt(v.getTag().toString());
                             setViewPagerCurrentItem(index);
 						} catch (Exception e) {
 							e.printStackTrace();
 						}
                     }
                 });
             }
         } catch (Exception e) {
             e.printStackTrace();
         }
     }
	     
     /**����ѡ��index ҳ��*/
     public void setViewPagerCurrentItem(int index){
     	try {
              switchPage(fragments[index], index);
              setSelectPage(index);
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
     }
	     

     /**��ʼ��fragment*/
     private void initFragment(){
     	try {
   			   fragments = new Fragment[pageSize];
               fragments[0] = new TestFragment1();
			   fragments[1] = new TestFragment2();
			   fragments[2] = new TypeFragment();
			   Bundle bundle = new Bundle();
  			   bundle.putString(TypeFragment.BUNDLE_TYPE, null);
  			   bundle.putInt(TypeFragment.BUNDLE_INDEX, 3);
  			   fragments[2].setArguments(bundle);
			   
               fragments[3] = new TestLazyTypeFragment();
               bundle = new Bundle();
			   bundle.putString(TestLazyTypeFragment.BUNDLE_TYPE, "");
			   bundle.putInt(TestLazyTypeFragment.BUNDLE_INDEX, 4);
			   fragments[3].setArguments(bundle);
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
     }

	    
     private void setSelectPage(int index){
     	try {
           for(int i = 0; i < pageSize; i++){
               if(i == index){
                   setMenuState(i, true);
               }else{
                   setMenuState(i, false);
               }
           }
 		} catch (Exception e) {
 			e.printStackTrace();
 		}      
     }

     private void setMenuState(int index, boolean select){
         try {
    	 	if(select){
        		menuViews[index].setBackgroundColor(Color.RED);
    	 	}else{
    	 		menuViews[index].setBackgroundColor(Color.WHITE);
    	 	}
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
     }
	
	private void switchPage(Fragment to, int index){
		try {
			 if(mContent != to){
				FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
				if(!to.isAdded()){
					transaction.hide(mContent).add(R.id.fragmentContent, to).commit();
				}else{
					transaction.hide(mContent).show(to).commit();
				}
				mContent = to;
				curSelect = index;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ���Fragment�ص���
	 * ��1.����Ϊÿ��Fragment�����ļ����ñ���ɫ���ڸǣ����������εķ���
	 * ��2.������Activity��״̬���ص���������Activity�����գ�Ȼ���ؽ�����ģ���onSaveInstanceState�д���
	 * ��3.��onAttachFragment�д����������Activity���պ��ؽ�����ôonAttachFragment����onCreate()ǰ����
	 * */
	 @Override
    protected void onSaveInstanceState(Bundle outState){
	 	//������ͨ��������Activity������ص����⣬ÿ���ؽ���������
    	//super.onSaveInstanceState(outState);
    }
	 
	 
	 //����:��������Activity��״̬(����Ҫ����)��Ȼ��ͨ���Ƴ�������ص�����
	 @Override
    public void onAttachFragment(Fragment fragment) {
    	// TODO Auto-generated method stub
    	//super.onAttachFragment(fragment);
    	if(fragments == null){
    		 //��֮ǰ��fragment�Ƴ�,�����ص�
	    	 Log.e(TAG, "onAttachFragment");
	    	 fm = this.getSupportFragmentManager();
	         FragmentTransaction ft = fm.beginTransaction();
	         ft.remove(fragment);
	         ft.commit();
    	}
    }
	
}

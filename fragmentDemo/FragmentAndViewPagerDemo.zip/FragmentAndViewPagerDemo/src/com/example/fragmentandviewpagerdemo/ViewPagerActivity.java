package com.example.fragmentandviewpagerdemo;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * ViewPager��ʹ��
 * */
public class ViewPagerActivity extends Activity implements OnPageChangeListener{
	private final String TAG = ViewPagerActivity.class.getSimpleName();
	
	private HorizontalScrollView horizontalScrollView;
	private LinearLayout tabLayout;
	private TextView[] tabViews;
	
	private ViewPager viewPager;
	
	private int curSelect = -1;//
	private int totalTabs = 0;//ҳ���ܸ���

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_viewpager);
		initView();
	}
	
	private void initView(){
		horizontalScrollView = (HorizontalScrollView) findViewById(R.id.HorizontalScrollView);
		tabLayout = (LinearLayout) findViewById(R.id.tab_layout);
		viewPager = (ViewPager) findViewById(R.id.viewPager);

		initTabItemView();
		initViewPager();
	}
	
	private void initTabItemView(){
		totalTabs = tabLayout.getChildCount();
		tabViews = new TextView[totalTabs];
		for(int i = 0;i < totalTabs;i++){
    		tabViews[i] = (TextView) tabLayout.getChildAt(i);
    		tabViews[i].setTag(i);
    		tabViews[i].setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					int position = (Integer)v.getTag();
					if(curSelect != position){
						/*
						 * ����ȡ��setSelectItem(position, true)�ĵ���;
						 * ������ô˷���������viewPager.setCurrentItemʱ�ᵼ��setSelectItem������2��;
						 * ��ΪsetCurrentItem�������ú�OnPageChangeListener�ص�onPageSelected()������
						 * */
						
						//���õ�ǰ��ʾҳ��
						viewPager.setCurrentItem(position);
					}
				}
			});
    	}
	}
	
	private void initViewPager(){
	 	List<ImageView> views = new ArrayList<ImageView>();  
	 	for(int i = 0; i < totalTabs; i ++){
	 		ImageView image = new ImageView(getApplicationContext());
	 		image.setImageResource(R.drawable.ic_launcher);
	 		views.add(image);
	 	}
        
        //��ViewPager����������   
	    //��ʼ�����е�ҳ��
	 	//viewPager.setOffscreenPageLimit(views.size());
        viewPager.setAdapter(new GuidePageAdapter(views));  
        viewPager.setOnPageChangeListener(this);
        //Ĭ��ѡ�е�һҳ
        curSelect = 0;
        viewPager.setCurrentItem(curSelect);
        //��Ȼ������OnPageChangeListener�����������״�ʱonPageSelected��һ������
        setSelectItem(curSelect, false);
	}
	
	/**���õ�ǰѡ��״̬
	 * 
	 * @param index : ��ǰѡ�����
	 * @param needChange : ��Ҫ�ı�viewpager����ʾҳ��
	 * 
	 * */
	private void setSelectItem(int index, boolean needChange){
		//����֮ǰ��ѡ�е�view
		if(curSelect >= 0){
			 tabViews[curSelect].setTextColor(Color.BLACK);
		}
		
//		 if(needChange){
//		//���õ�ǰ��ʾ
//			 viewPager.setCurrentItem(index);
//		 }
		
		 //�ǵ���˵����л�ҳ��ʱ��Ҫ����
		 if(!needChange){
			 scrollMenuPos(index);
		 }
		 
		 //���õ�ǰ��ʾ��ǩҳ��״̬
		 tabViews[index].setTextColor(Color.RED);
		 curSelect = index;
	}
	

	 
	/**�����˵���*/
	private void scrollMenuPos(final int index){
		try {
//			if(index > 3){
//				int x = tabViews[0].getWidth() * (index - 1);
//				mHorizontalScrollView.scrollTo(x, 0);
//			}else{
//				mHorizontalScrollView.scrollTo(0, 0);
//			}
		
			//�ù�������Ȼ
			if(index > 2){
				int x = tabViews[0].getWidth() * (index - 1);
				horizontalScrollView.smoothScrollTo(x, 0);
			}else{
				horizontalScrollView.smoothScrollTo(0, 0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**ָ��ҳ������������*/
    class GuidePageAdapter extends PagerAdapter {
    	private List<ImageView> pageViews;
    	public GuidePageAdapter(List<ImageView> list) {
			pageViews = list;
		}
        public int getCount() {
            return pageViews == null ? 0 : pageViews.size();
        }
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }
        public int getItemPosition(Object object) {
            return super.getItemPosition(object);
        }
        public void destroyItem(View arg0, int arg1, Object arg2) {
            ((ViewPager) arg0).removeView(pageViews.get(arg1));
        }
        public Object instantiateItem(View arg0, int arg1) {
            ((ViewPager) arg0).addView(pageViews.get(arg1));
            return pageViews.get(arg1);
        }
        public void restoreState(Parcelable arg0, ClassLoader arg1) {
        }
        public Parcelable saveState() {
            return null;
        }
        public void startUpdate(View arg0) {
        }
        public void finishUpdate(View arg0) {
        }
    }
    
    @Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		setSelectItem(arg0, false);
	}  
}

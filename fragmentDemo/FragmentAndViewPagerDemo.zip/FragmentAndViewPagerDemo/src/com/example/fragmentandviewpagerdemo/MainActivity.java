package com.example.fragmentandviewpagerdemo;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**demo���*/
public class MainActivity extends Activity {
	private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btn1 = (Button) findViewById(R.id.btn1);
		btn2 = (Button) findViewById(R.id.btn2);
		btn3 = (Button) findViewById(R.id.btn3);
		btn4 = (Button) findViewById(R.id.btn4);
		btn5 = (Button) findViewById(R.id.btn5);
		btn6 = (Button) findViewById(R.id.btn6);
		btn7 = (Button) findViewById(R.id.btn7);
		
		
		/*Fragment�ļ�ʹ��*/
		btn1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, FragmentDemoActivity.class));
			}
		});
		
		/*ViewPager��ʹ��*/
		btn2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, ViewPagerActivity.class));
			}
		});
		
		/*FragmentTabHost*/
		btn3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, FragmentTabHostActivity.class));
			}
		});

		/*ViewPager��Ƕ��Fragment*/
		btn4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, FragmentInViewPagerActivity.class));
			}
		});
		
		/*Fragment��ʹ��Fragment(����Fragment����Viewpager�еģ�
		 *��Ȼ�����ʹ��ViewPagerʱ��Fragment��ʹ��Fragment�÷�������Fragment��
		 *ʹ�ã�ֻ���ڲ�Fragment��getChildFragmentManager)
		 */
		btn5.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, FragmentInFragmentActivity.class));
			}
		});
		
		/*Fragment�ӳټ���*/
		btn6.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, LazyFragmentInViewPagerActivity.class));
			}
		});
		
		/*fragment�ص�����*/
		btn7.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MainActivity.this, FragmentOverLapDemoActivity.class));
			}
		});
	}
}

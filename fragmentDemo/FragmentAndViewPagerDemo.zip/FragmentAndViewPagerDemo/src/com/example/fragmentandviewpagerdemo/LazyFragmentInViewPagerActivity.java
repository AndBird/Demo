package com.example.fragmentandviewpagerdemo;

import java.util.ArrayList;
import java.util.List;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.test.fragment.TestLazyTypeFragment;
import com.test.fragment.TypeFragment;

/**fragment�ӳټ���*/
public class LazyFragmentInViewPagerActivity extends FragmentActivity implements OnPageChangeListener{
	private final String TAG = LazyFragmentInViewPagerActivity.class.getSimpleName();
	private HorizontalScrollView horizontalScrollView;
	private LinearLayout tabLayout;
	private TextView[] tabViews;
	private ViewPager viewPager;
	
	private ArrayList<Fragment> fragmentList;  
	private int curSelect = -1;//
	private int totalTabs = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_viewpager);
		initView();
	}
	
	private void initView(){
		horizontalScrollView = (HorizontalScrollView) findViewById(R.id.HorizontalScrollView);
		tabLayout = (LinearLayout) findViewById(R.id.tab_layout);
		viewPager = (ViewPager) findViewById(R.id.viewPager);

		initTabItemView();
		initViewPager();
	}
	
	private void initTabItemView(){
		totalTabs = tabLayout.getChildCount();
		tabViews = new TextView[totalTabs];
		for(int i = 0;i < totalTabs;i++){
    		tabViews[i] = (TextView) tabLayout.getChildAt(i);
    		tabViews[i].setTag(i);
    		tabViews[i].setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					int position = (Integer)v.getTag();
					if(curSelect != position){
						/*
						 * ����ȡ��setSelectItem(position, true)�ĵ���;
						 * ������ô˷���������viewPager.setCurrentItemʱ�ᵼ��setSelectItem������2��;
						 * ��ΪsetCurrentItem�������ú�OnPageChangeListener�ص�onPageSelected()������
						 * */
						
						//���õ�ǰ��ʾҳ��
						viewPager.setCurrentItem(position);//���õ�ǰ��ʾ
					}
				}
			});
    	}
	}
	
	private void initViewPager(){
		 	fragmentList = new ArrayList<Fragment>();  
		 	for(int i = 0; i < totalTabs; i ++){
		 		//Fragment fragment = new TestLazyTypeFragment(null, i);
		 		
		 		Fragment fragment = new TestLazyTypeFragment();
		 		Bundle bundle = new Bundle();
				bundle.putString(TypeFragment.BUNDLE_TYPE, null);
				bundle.putInt(TypeFragment.BUNDLE_INDEX, i);
				fragment.setArguments(bundle);
		 		fragmentList.add(fragment);  
		 	}
	        
	        //��ViewPager����������   
		    //��ʼ�����е�ҳ��
		 	viewPager.setOffscreenPageLimit(fragmentList.size());
	        viewPager.setAdapter(new MyFragmentPagerAdapter(getSupportFragmentManager(), fragmentList));  
	        //ҳ��仯ʱ�ļ�����
	        viewPager.setOnPageChangeListener(this);  
	        //Ĭ��ѡ�е�һҳ
	        curSelect = 0;
	        viewPager.setCurrentItem(curSelect);
	        //��Ȼ������OnPageChangeListener�����������״�ʱonPageSelected��һ������
	        setSelectItem(curSelect, false);
	}
	
	/**���õ�ǰѡ��״̬
	 * 
	 * @param index : ��ǰѡ�����
	 * @param needChange : ��Ҫ�ı�viewpager����ʾҳ��
	 * 
	 * */
	private void setSelectItem(int index, boolean needChange){
		//����֮ǰ��ѡ�е�view
		if(curSelect >= 0){
			 tabViews[curSelect].setTextColor(Color.BLACK);
		}
		
//		 if(needChange){
//			 //���õ�ǰ��ʾ
//			 viewPager.setCurrentItem(index);
//		 }
		
		 //�ǵ���˵����л�ҳ��ʱ��Ҫ����
		 if(!needChange){
			 scrollMenuPos(index);
		 }
		 //���õ�ǰ��ʾ��ǩҳ��״̬
		 tabViews[index].setTextColor(Color.RED);
		 curSelect = index;
	}

	/**�����˵���*/
	private void scrollMenuPos(final int index){
		try {
//			 if(index > 3){
//				int x = tabViews[0].getWidth() * (index - 1);
//				mHorizontalScrollView.scrollTo(x, 0);
//			}else{
//				mHorizontalScrollView.scrollTo(0, 0);
//			}
		
			//�ù�������Ȼ
			if(index > 2){
				int x = tabViews[0].getWidth() * (index - 1);
				horizontalScrollView.smoothScrollTo(x, 0);
			}else{
				horizontalScrollView.smoothScrollTo(0, 0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	
	
	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		setSelectItem(arg0, false);
	}  
	
	
	public class MyFragmentPagerAdapter extends FragmentPagerAdapter{ 
		private FragmentManager fm;
	    private ArrayList<Fragment> list;  
	    public MyFragmentPagerAdapter(FragmentManager fm,ArrayList<Fragment> list) {  
	        super(fm);  
	        this.fm = fm;
	        this.list = list;    
	    }  
	        
	    @Override  
	    public int getCount() {  
	        return list == null ? 0 : list.size();  
	    }  
	      
	    @Override  
	    public Fragment getItem(int arg0) {  
	        return list.get(arg0);  
	    } 
	    
	    /**
	     * ��������ҳ������(���ڶ�ȡ�˻����fragment�����ӣ���������������
	     * ��ʱ���ٽ��н��ȸ���ʱ���ᷢ�����е�fragment�еı�������null,��Ϊ�����õ�Listδ����Ч)
	     * 
	     * @param items
	     */
	    public void setNewContent(List<Fragment> items){
	    	try {
	    		 if (items != null){
	    		        for (int i = 0; i < list.size(); i++){
	    		          fm.beginTransaction().remove(list.get(i)).commit();
	    		        }
	    		        list.clear();
	    		        list.addAll(items);
	    		   }
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	    
	    
	    @Override       
	    public void destroyItem(ViewGroup container, int position, Object object) {            
	    	//��ֹ����fragment,����Fragment�ظ���ʼ��
	    	//super.destroyItem(container, position, object); 
	    	//Log.e(TAG, "destroyItem " + position);
	    }
	}
}

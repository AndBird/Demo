package com.test.fragment;

import java.util.ArrayList;
import java.util.List;

import com.example.fragmentandviewpagerdemo.R;


import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**fragment��ʹ��viewpager��Ƕ��fragment*/
public class ViewPagerFragment extends Fragment implements OnPageChangeListener{
	private final String TAG = ViewPagerFragment.class.getSimpleName();
	
	private Activity activity;
	private View rootView;
	
	private HorizontalScrollView horizontalScrollView;
	private LinearLayout tabLayout;
	private TextView[] tabViews;
	private ViewPager viewPager;
	
	private ArrayList<Fragment> fragmentList;  
	private int curSelect = -1;//
	private int totalTabs = 0;


	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		Log.e(TAG, "onAttach");
		this.activity = activity;
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Log.e(TAG, "onCreate");
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		Log.e(TAG, "onCreateView");
		rootView = inflater.inflate(R.layout.activity_viewpager, null);
		initView();
		return rootView;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		Log.e(TAG, "onActivityCreated");
	}
	
	@Override
	public void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		Log.e(TAG, "onStart");
	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Log.e(TAG, "onResume");
	}
	
	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Log.e(TAG, "onPause");
	}
	
	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Log.e(TAG, "onStop");
	}
	
	@Override
	public void onDestroyView() {
		// TODO Auto-generated method stub
		super.onDestroyView();
		Log.e(TAG, "onDestroyView");
	}
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.e(TAG, "onDestroy");
	}
	
	@Override
	public void onDetach() {
		// TODO Auto-generated method stub
		super.onDetach();
		Log.e(TAG, "onDetach");
	}
	
	/**fragment��ͨ�л���Ч*/
	@Override
	public void onHiddenChanged(boolean hidden) {
		// TODO Auto-generated method stub
		super.onHiddenChanged(hidden);
		Log.e(TAG, "onHiddenChanged hidden=" + hidden);
	}
	
	/**viewPager����Ч*/
	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		// TODO Auto-generated method stub
		super.setUserVisibleHint(isVisibleToUser);
		Log.e(TAG, "setUserVisibleHint isVisibleToUser=" + isVisibleToUser);
	}
	
	private void initView(){
		horizontalScrollView = (HorizontalScrollView) rootView.findViewById(R.id.HorizontalScrollView);
		tabLayout = (LinearLayout) rootView.findViewById(R.id.tab_layout);
		viewPager = (ViewPager) rootView.findViewById(R.id.viewPager);

		initTabItemView();
		initViewPager();
	}
	
	private void initTabItemView(){
		totalTabs = tabLayout.getChildCount();
		tabViews = new TextView[totalTabs];
		for(int i = 0;i < totalTabs;i++){
    		tabViews[i] = (TextView) tabLayout.getChildAt(i);
    		tabViews[i].setTag(i);
    		tabViews[i].setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					int position = (Integer)v.getTag();
					if(curSelect != position){
						/*
						 * ����ȡ��setSelectItem(position, true)�ĵ���;
						 * ������ô˷���������viewPager.setCurrentItemʱ�ᵼ��setSelectItem������2��;
						 * ��ΪsetCurrentItem�������ú�OnPageChangeListener�ص�onPageSelected()������
						 * */
						
						//���õ�ǰ��ʾҳ��
						viewPager.setCurrentItem(position);
					}
				}
			});
    	}
	}
	
	private void initViewPager(){
		 	fragmentList = new ArrayList<Fragment>();  
		 	for(int i = 0; i < totalTabs; i ++){
		 		//Fragment fragment = new TypeFragment(null, i);  
		 		
		 		Fragment fragment = new TypeFragment();
		 		Bundle bundle = new Bundle();
				bundle.putString(TypeFragment.BUNDLE_TYPE, null);
				bundle.putInt(TypeFragment.BUNDLE_INDEX, i);
				fragment.setArguments(bundle);
		 		fragmentList.add(fragment);  
		 	}
	        
	        //��ViewPager����������   
		    //��ʼ�����е�ҳ��
		 	//viewPager.setOffscreenPageLimit(views.size());
	        viewPager.setAdapter(new MyFragmentPagerAdapter(getChildFragmentManager(), fragmentList)); //�˴�ֻ����getChildFragmentManager������getFragmentManagerʱһ��Fragment��Ƕ��Viewpager����������ʾ����������һ��Fragment(copy��ǰ��Fragment)ҲǶ��ViewPagerʱ���ͻᵼ������һ���޷���ʾ 
	        //ҳ��仯ʱ�ļ�����
	        viewPager.setOnPageChangeListener(this);   
	        //Ĭ��ѡ�е�һҳ
	        curSelect = 0;
	        viewPager.setCurrentItem(curSelect);
	        //��Ȼ������OnPageChangeListener�����������״�ʱonPageSelected��һ������
	        setSelectItem(curSelect, false);
	}
	
	/**���õ�ǰѡ��״̬
	 * 
	 * @param index : ��ǰѡ�����
	 * @param needChange : ��Ҫ�ı�viewpager����ʾҳ��
	 * 
	 * */
	private void setSelectItem(int index, boolean needChange){
		//����֮ǰ��ѡ�е�view
		if(curSelect >= 0){
			 tabViews[curSelect].setTextColor(Color.BLACK);
		}
		
		//��ͨ���˷����������л�ҳ�棬ֻ���������˵�
//		 if(needChange){
//		     //���õ�ǰ��ʾҳ
//			 viewPager.setCurrentItem(index);
//		 }
		
		 //�ǵ���˵����л�ҳ��ʱ����
		 if(!needChange){
			 scrollMenuPos(index);
		 }
		 //���õ�ǰ��ʾ��ǩҳ��״̬
		 tabViews[index].setTextColor(Color.RED);
		 curSelect = index;
	}
	

 	/**�����˵�*/
	private void scrollMenuPos(final int index){
		try {
//			if(index > 3){
//				int x = tabViews[0].getWidth() * (index - 1);
//				mHorizontalScrollView.scrollTo(x, 0);
//			}else{
//				mHorizontalScrollView.scrollTo(0, 0);
//			}
		
			//�ù�������Ȼ
			if(index > 2){
				int x = tabViews[0].getWidth() * (index - 1);
				horizontalScrollView.smoothScrollTo(x, 0);
			}else{
				horizontalScrollView.smoothScrollTo(0, 0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPageSelected(int arg0) {
		setSelectItem(arg0, false);
	}  
	
	
	public class MyFragmentPagerAdapter extends FragmentPagerAdapter{  
	    private ArrayList<Fragment> list;  
	    private FragmentManager fm;
	    public MyFragmentPagerAdapter(FragmentManager fm,ArrayList<Fragment> list) {  
	        super(fm);  
	        this.list = list; 
	        this.fm = fm;
	    }  
	        
	    @Override  
	    public int getCount() {  
	        return list == null ? 0 : list.size();  
	    }  
	      
	    @Override  
	    public Fragment getItem(int arg0) {  
	        return list.get(arg0);  
	    } 
	    
	    
	    /**
	     * ��������ҳ������(���ڶ�ȡ�˻����fragment�����ӣ���������������
	     * ��ʱ���ٽ��н��ȸ���ʱ���ᷢ�����е�fragment�еı�������null,��Ϊ�����õ�Listδ����Ч)
	     * @param items
	     */
	    public void setNewContent(List<Fragment> items){
	    	try {
	    		 if (items != null){
	    		        for (int i = 0; i < list.size(); i++){
	    		          fm.beginTransaction().remove(list.get(i)).commit();
	    		        }
	    		        list.clear();
	    		        list.addAll(items);
	    		   }
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	    
	    
	    @Override       
	    public void destroyItem(ViewGroup container, int position, Object object) {            
	    	//��ֹ����fragment,����Fragment�ظ���ʼ��
	    	//super.destroyItem(container, position, object); 
	    	//Log.e(TAG, "destroyItem " + position);
	    }
	}
}

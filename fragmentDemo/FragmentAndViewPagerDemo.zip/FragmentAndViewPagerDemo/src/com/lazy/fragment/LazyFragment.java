package com.lazy.fragment;


import com.example.fragmentandviewpagerdemo.R;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class LazyFragment extends BaseLazyFragment{
	public Activity activity;
	public View rootView;
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		this.activity = activity;
		//initHandler();
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
		super.onCreateView(inflater, container, savedInstanceState);//isViewInited = true;
		rootView = inflater.inflate(R.layout.fragment_layout1, container, false);
		//initView();	
		return rootView;
	}
	
	
//	@Override
//  public void setUserVisibleHint(boolean isVisibleToUser) {
// 	     //�������setUserVisibleHint������һ��Ҫ����
//       super.setUserVisibleHint(isVisibleToUser);
//  }

	@Override
	public void startLazyLoad() {
		//���������
		Log.e("lazyLoad", "lazyLoad called, start load data");
	}
}

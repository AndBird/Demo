package tab;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class TabPageActivity1 extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		TextView t = new TextView(this);
		t.setText("ҳ��1");
		setContentView(t);
	}
}
package tab;

import com.example.tab.R;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

public class TabIntentInTabActivity extends TabActivity{
	private TabHost tabHost;
	private TabWidget tabWidget;
	private int preTabId = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_item_is_intent);
		tabHost = this.getTabHost();
		tabWidget = this.getTabWidget();
		tabHost.setFocusable(true);
		
		
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			
			@Override
			public void onTabChanged(String tabId) {
				// TODO Auto-generated method stub
				int tId = Integer.parseInt(tabId);
				if(tId != preTabId)
				{
					setTabBg(tId, true);
					setTabBg(preTabId, false);
					preTabId = tId;
				}
			}
		});
		Intent intent = new Intent(this, TabPageActivity1.class);
		tabHost.addTab(buildTabSpec("0", "��ǩ1", intent));
		intent = new Intent(this, TabPageActivity2.class);
		tabHost.addTab(buildTabSpec("1", "��ǩ2", intent));
	}
	
	
	private TabSpec buildTabSpec(String tabId, String tag1, Intent intent) {
		try {
			View view = View.inflate(this, R.layout.selector, null);
			//((ImageView) view.findViewById(R.id.tab_iv_icon)).setImageResource(icon);
			((TextView) view.findViewById(R.id.tab_tv_text)).setText(tag1);
			//((TextView) view.findViewById(R.id.tab_bottom_text)).setText(tag2);
			if(tabId.equals("0"))
			{
				view.findViewById(R.id.tabIndicator).setVisibility(View.VISIBLE);
				view.findViewById(R.id.tabDivider).setVisibility(View.INVISIBLE);
				//view.findViewById(R.id.tabView).setBackgroundColor(getResources().getColor(R.color.main_tab_bg_sel));
			} else
			{
				view.findViewById(R.id.tabIndicator).setVisibility(View.INVISIBLE);
				view.findViewById(R.id.tabDivider).setVisibility(View.VISIBLE);
				//view.findViewById(R.id.tabView).setBackgroundColor(getResources().getColor(R.color.main_tab_bg_nor)); 
			}
			return tabHost.newTabSpec(tabId).setIndicator(view).setContent(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	   private void setTabBg(int tabId, boolean isSelected)
	    {
	    	System.out.println("tabId:" + tabId);
	    	View myTabView = tabWidget.getChildTabViewAt(tabId);
			View tabIndicator = myTabView.findViewById(R.id.tabIndicator);
			View tabDivider = myTabView.findViewById(R.id.tabDivider);
			View tabView = myTabView.findViewById(R.id.tabView);
			if(isSelected){
				tabIndicator.setVisibility(View.VISIBLE);
				tabDivider.setVisibility(View.INVISIBLE);
				tabView.setBackgroundColor(0x14161d);
			} else
			{
				tabIndicator.setVisibility(View.INVISIBLE);
				tabDivider.setVisibility(View.VISIBLE);
				tabView.setBackgroundColor(0x272c39);
			}
	    }

}

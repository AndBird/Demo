package tab;

import com.example.tab.R;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;

public class TabIsViewInActivity extends  android.app.Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_item_is_view);
		TabHost tabHost = (TabHost)findViewById(R.id.tabhost);
		tabHost.setup();
		
		//��1����Ҫ����,����tab
		//������ʾ��tab(tab�ֳɵ�����xml�ļ�����Ҫ��)�����߽�tab��xml layoutֱ��д�뵽activity��
		LayoutInflater.from(this).inflate(R.layout.tab_item1, tabHost.getTabContentView(),true); 
		LayoutInflater.from(this).inflate(R.layout.tab_item2, tabHost.getTabContentView(),true);
		//tab1�Ǳ�ţ�ҳ0�Ǳ�ǩ�������������ʾ����������tab01��tab_item1�ĸ�id
		tabHost.addTab(tabHost.newTabSpec("tab1").setIndicator("ҳ0").setContent(R.id.tab01));
		tabHost.addTab(tabHost.newTabSpec("tab2").setIndicator("ҳ1").setContent(R.id.tab02));
		
		
		//��2��
		tabHost.addTab(tabHost.newTabSpec("tab3").setIndicator("ҳ2").setContent(new TabHost.TabContentFactory() {
			@Override
			public View createTabContent(String tag) {
				// TODO Auto-generated method stub
				return LayoutInflater.from(getApplicationContext()).inflate(R.layout.tab_item1, null);
			}
		}));
		tabHost.addTab(tabHost.newTabSpec("tab4").setIndicator("ҳ3").setContent(new TabHost.TabContentFactory() {
			@Override
			public View createTabContent(String tag) {
				// TODO Auto-generated method stub
				return LayoutInflater.from(getApplicationContext()).inflate(R.layout.tab_item1, null);
			}
		}));
		
	    
//	//����
//	tabHost.setOnTabChangedListener(new OnTabChangeListener() {
//		
//		@Override
//		public void onTabChanged(String arg0) {
//			// TODO Auto-generated method stub
//			if(arg0.equals("tab2")){
//				
//				//LinearLayout layout=(LinearLayout)LinearLayout.inflate(context, resource, root)
//				LinearLayout layout=(LinearLayout)findViewById(R.id.tab2);
//				LinearLayout layout1=(LinearLayout)findViewById(R.id.lay);
//				
//			    LinearLayout view=(LinearLayout)LinearLayout.inflate(TabActivity.this, R.layout.tab, null);
//			layout1.removeAllViews();
//			    layout1.addView(view);
//			}
//			
//		}
//	});
		
	}
}

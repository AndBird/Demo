package tab;

import com.example.tab.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class MainActivity extends Activity{
	private View activity1, activity2, activity3, activity4;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		activity1 = findViewById(R.id.intent1);
		activity2 = findViewById(R.id.intent2);
		activity3 = findViewById(R.id.intent3);
		activity4 = findViewById(R.id.intent4);
		
		activity1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent in = new Intent(MainActivity.this, TabIsViewInActivity.class);
				startActivity(in);
			}
		});
		
		activity2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent in = new Intent(MainActivity.this, TabIntentInTabActivity.class);
				startActivity(in);
			}
		});
		
		activity3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent in = new Intent(MainActivity.this, TabIntentWithOutTabWidgetInTabActivity.class);
				startActivity(in);
			}
		});
		
		
		activity4.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				// TODO Auto-generated method stub
				Intent in = new Intent(MainActivity.this, TabIntentWithOutTabWidgetInActivity.class);
				startActivity(in);
			}
		});
		
		
		
	}
}

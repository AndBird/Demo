package tab;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RadioButton;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TabHost.OnTabChangeListener;
import com.example.tab.R;

public class TabIntentWithOutTabWidgetInActivity extends ActivityGroup{
	private final String TAG = TabIntentWithOutTabWidgetInActivity.class.getSimpleName();
	
	private TabHost tabHost;
	private TabWidget tabWidget;
	
	private RadioButton rbMenu1, rbMenu2, rbMenu3, rbMenu4;
	
	private int currIndex = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_item_is_intent_in_activity);
		
		
		tabHost = (TabHost) findViewById(R.id.tabhost);
		//�̳�activity
		//LocalActivityManager groupActivity = new LocalActivityManager(this,false);
		//groupActivity.dispatchCreate(savedInstanceState);  
		//tabHost.setup(groupActivity);
		
		//�̳�ActivityGroup
		tabHost.setup(getLocalActivityManager());
		initMenuView();
		
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			@Override
			public void onTabChanged(String tabId) {
				// TODO Auto-generated method stub
				Log.e(TAG, "tabId=" + tabId);
			}
		});
		
		Intent intent1 = new Intent(this, TabPageActivity1.class);
		Intent intent2 = new Intent(this, TabPageActivity2.class);
		tabHost.addTab(tabHost.newTabSpec("1").setIndicator("tab1").setContent(intent1));
		tabHost.addTab(tabHost.newTabSpec("2").setIndicator("tab2").setContent(intent2));
		tabHost.addTab(tabHost.newTabSpec("3").setIndicator("tab3").setContent(intent1));
		tabHost.addTab(tabHost.newTabSpec("4").setIndicator("tab4").setContent(intent2));
	}
	   
	private void initMenuView(){
	   rbMenu1 = (RadioButton) findViewById(R.id.rbMenu1);
	   rbMenu2 = (RadioButton) findViewById(R.id.rbMenu2);
	   rbMenu3 = (RadioButton) findViewById(R.id.rbMenu3);
	   rbMenu4 = (RadioButton) findViewById(R.id.rbMenu4);
	   
	   rbMenu1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 0;
				//�л���1������
				tabHost.setCurrentTabByTag("1");
			}
	   });
	   
	   rbMenu2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 1;
				//�л���2������
				tabHost.setCurrentTabByTag("2");
			}
	   });
	   
	   rbMenu3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 2;
				//�л���3������
				tabHost.setCurrentTabByTag("3");
			}
	   });
	   
	   rbMenu4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 3;
				//�л���4������
				tabHost.setCurrentTabByTag("4");
			}
	   });
	}

}

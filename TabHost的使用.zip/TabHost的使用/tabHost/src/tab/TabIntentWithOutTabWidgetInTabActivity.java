package tab;

import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RotateDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RadioButton;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

import com.example.tab.R;

public class TabIntentWithOutTabWidgetInTabActivity extends TabActivity{
	private final String TAG = TabIntentWithOutTabWidgetInTabActivity.class.getSimpleName();
	
	private TabHost tabHost;
	private TabWidget tabWidget;
	
	private RadioButton rbMenu1, rbMenu2, rbMenu3, rbMenu4;
	
	private int currIndex = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_item_is_intent2);
		
		initMenuView();
		
		tabHost = this.getTabHost();
		tabWidget = this.getTabWidget();
		tabHost.setFocusable(true);
		
		
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			
			@Override
			public void onTabChanged(String tabId) {
				// TODO Auto-generated method stub
				Log.e(TAG, "tabId=" + tabId);
			}
		});
		
		Intent intent1 = new Intent(this, TabPageActivity1.class);
		Intent intent2 = new Intent(this, TabPageActivity2.class);
		tabHost.addTab(tabHost.newTabSpec("1").setIndicator("tab1").setContent(intent1));
		tabHost.addTab(tabHost.newTabSpec("2").setIndicator("tab2").setContent(intent2));
		tabHost.addTab(tabHost.newTabSpec("3").setIndicator("tab3").setContent(intent1));
		tabHost.addTab(tabHost.newTabSpec("4").setIndicator("tab4").setContent(intent2));
	}
	   
   private void initMenuView(){
	   rbMenu1 = (RadioButton) findViewById(R.id.rbMenu1);
	   rbMenu2 = (RadioButton) findViewById(R.id.rbMenu2);
	   rbMenu3 = (RadioButton) findViewById(R.id.rbMenu3);
	   rbMenu4 = (RadioButton) findViewById(R.id.rbMenu4);
	   
	   
	   Drawable[] draws = rbMenu1.getCompoundDrawables();
	   if(draws != null && draws.length >= 1){
		   Log.e(TAG, "drawable len=" + draws.length);
		   if(draws[1] != null){
			   Rect r = draws[1].getBounds();
			   Log.e(TAG, "drawable size=" + draws[1].getMinimumWidth() + "*" + draws[1].getMinimumHeight());
			   Log.e(TAG, "drawable size=" + draws[1].getIntrinsicWidth() + "*" + draws[1].getIntrinsicHeight());
			   Log.e(TAG, "drawable size=" + r.left + "," + r.top + "," + r.right + "," + r.bottom);
			   Log.e(TAG, "drawable size=" + (r.right - r.left) + "*" + (r.bottom - r.top));
			   draws[1].setBounds(r.left + 20, r.top + 40, r.right - 20, r.bottom);
		   }
		   
	   }
	   
	   
	   rbMenu1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 0;
				//�л���1������
				tabHost.setCurrentTabByTag("1");
			}
	   });
	   
	   rbMenu2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 1;
				//�л���2������
				tabHost.setCurrentTabByTag("2");
			}
	   });
	   
	   rbMenu3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 2;
				//�л���3������
				tabHost.setCurrentTabByTag("3");
			}
	   });
	   
	   rbMenu4.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currIndex = 3;
				//�л���4������
				tabHost.setCurrentTabByTag("4");
			}
	   });
   }
}

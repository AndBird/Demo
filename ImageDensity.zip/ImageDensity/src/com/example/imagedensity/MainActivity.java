package com.example.imagedensity;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity{
	private final static String TAG = MainActivity.class.getSimpleName();
	private TextView[] textViews;
	private ImageView[] imageViews;
	private int[] resId = new int[]{R.drawable.test_drawable, R.drawable.test_no, R.drawable.test_l, R.drawable.test_m, R.drawable.test_h, R.drawable.test_xh, R.drawable.test_xxh};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initView();
		
		
		
	}
	
	private void initView(){
		textViews = new TextView[7];
		imageViews = new ImageView[7];
		textViews[0] = (TextView) findViewById(R.id.textView1);
		imageViews[0] = (ImageView) findViewById(R.id.imageview1);

		textViews[1] = (TextView) findViewById(R.id.textView2);
		imageViews[1] = (ImageView) findViewById(R.id.imageview2);
		
		textViews[2] = (TextView) findViewById(R.id.textView3);
		imageViews[2] = (ImageView) findViewById(R.id.imageview3);
		
		textViews[3] = (TextView) findViewById(R.id.textView4);
		imageViews[3] = (ImageView) findViewById(R.id.imageview4);
		
		textViews[4] = (TextView) findViewById(R.id.textView5);
		imageViews[4] = (ImageView) findViewById(R.id.imageview5);
		
		textViews[5] = (TextView) findViewById(R.id.textView6);
		imageViews[5] = (ImageView) findViewById(R.id.imageview6);
		
		textViews[6] = (TextView) findViewById(R.id.textView7);
		imageViews[6] = (ImageView) findViewById(R.id.imageview7);
		
		
		TextView textView = (TextView) findViewById(R.id.textView0);
		DisplayMetrics dc = getResources().getDisplayMetrics();
		textView.setText("��Ļ����:\ndensity=" + dc.density + " ,densityDpi=" + dc.densityDpi + " ,xdpi=" + dc.xdpi + " ,ydpi=" + dc.ydpi + " ,size=" + dc.widthPixels + "*" + dc.heightPixels
				 + "\nͼƬ��ʵ�ߴ�:300 * 160");
		
		
		for(int i = 0; i < textViews.length; i++){
	        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), resId[i]);
	        int w = bitmap.getWidth();
	        int h = bitmap.getHeight();
	        bitmap.recycle();
			TypedValue value = getTargetDensityByResource(getResources(), resId[i]);
			textViews[i].setText("��Դ����:" + value.string + ",   density=" + value.density + "\n�ߴ�:" + w + "*" + h + " ,scale=" + dc.densityDpi + "/" +  value.density);
		}
		
	    final ImageView	imageView = (ImageView) findViewById(R.id.imageview8); 
	    imageView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				 Animation animation = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.scale_translate);
				 imageView.startAnimation(animation);
				/*if(imageViews[6].getVisibility() != View.VISIBLE){
					imageViews[6].setVisibility(View.VISIBLE);
				}else{
					imageViews[6].setVisibility(View.GONE);
				}*/
			}
		});
		
	    
	    Bitmap bitmap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() + "/test_no.png");
	    if(bitmap != null){
	    	Toast.makeText(getApplicationContext(), "" + bitmap.getWidth() + "*" + bitmap.getHeight(), Toast.LENGTH_SHORT).show();
	    	bitmap.recycle();
	    }
	}

	 /*����ͼƬ�����ļ��е�����*/
	 private TypedValue getTargetDensityByResource(Resources resources, int res_id) {
         TypedValue value = new TypedValue();
         resources.openRawResource(res_id, value);
         Log.e(TAG, "value.density: " + value.density + "," + value.string);
         return value;
	 }
	 
	  /*����ͼƬ����ͼƬ�ڲ�ͬ�ܶȵ��ֻ��ϲ��ᱻ����*/
	  private Bitmap decodeResourceNoScale(Resources resources, int res_id) {
          TypedValue value = new TypedValue();
          resources.openRawResource(res_id, value);
          BitmapFactory.Options opts = new BitmapFactory.Options();
          opts.inTargetDensity = value.density;
          return BitmapFactory.decodeResource(resources, res_id, opts);
	  }
}

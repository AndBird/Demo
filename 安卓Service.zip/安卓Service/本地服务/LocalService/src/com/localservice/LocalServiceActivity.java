package com.localservice;


import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class LocalServiceActivity extends Activity{
	private static final String TAG = LocalService.class.getSimpleName();
	private Button get;
	private TextView msgTextView;
	
	
	private LocalService.MsgBinder binder;
	private ServiceConnection conn = new ServiceConnection(){
		@Override
		public void onServiceConnected(ComponentName name, IBinder service){
			
			binder = (LocalService.MsgBinder) service;
			Log.e(TAG, "onServiceConnected");
		}
		
		@Override
		public void onServiceDisconnected(ComponentName name){
			binder = null;
			Log.e(TAG, "onServiceDisconnected");
		}
	};
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_localservice);
		get = (Button) findViewById(R.id.get);
		msgTextView = (TextView) findViewById(R.id.message);
		
		// ��������󶨵�Service��Intent
		Intent intent = new Intent(this, LocalService.class);
		bindService(intent, conn, Service.BIND_AUTO_CREATE);
		
		get.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				try{
					// ��ȡ����ʾԶ��Service��״̬
					if(binder != null){
						msgTextView.setText(binder.getMessage());
					}else{
						Toast.makeText(getApplicationContext(), "��û���ӳɹ�", Toast.LENGTH_SHORT).show();
					}
				}catch (Exception e){
					e.printStackTrace();
				}
			}
		});
	}
	
	@Override
	public void onDestroy(){
		super.onDestroy();
		// �����
		this.unbindService(conn);
	}
}

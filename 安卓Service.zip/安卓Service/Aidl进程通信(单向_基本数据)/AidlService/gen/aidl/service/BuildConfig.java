/** Automatically generated file. DO NOT MODIFY */
package aidl.service;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
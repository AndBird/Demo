package aidl.client;


import com.service.aidl.ClientCallBack;
import com.service.aidl.RemoteMessage;
import aidl.client.R;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/*Aidl Client*/
public class MainActivity extends Activity{
	private Button get;
	private TextView msgTextView;
	private int count = 0;
	
	private RemoteMessage remoteService;
	private ServiceConnection conn = new ServiceConnection(){
		@Override
		public void onServiceConnected(ComponentName name, IBinder service){
			// 获取远程Service的onBind方法返回的对象的代理
			remoteService = RemoteMessage.Stub.asInterface(service);
			Log.e("aidl", "onServiceConnected");
		}
		
		@Override
		public void onServiceDisconnected(ComponentName name){
			remoteService = null;
			Log.e("aidl", "onServiceDisconnected");
		}
	};
	
	
	//private ClientCallBack.Stub callBack = new ClientCallBack.Stub() {
	private ClientCallBack callBack = new ClientCallBack.Stub() {
		@Override
		public String sendMessageToClient(String msg) throws RemoteException {
			// TODO Auto-generated method stub
			final String tString = msg;
			msgTextView.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					msgTextView.append("\n");
					msgTextView.append(tString);
				}
			});
			return null;
		}
		
		@Override
		public String getMessageFromClient() throws RemoteException {
			// TODO Auto-generated method stub
			count++;
			return "远程Service" + count;
		}
	};
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		get = (Button) findViewById(R.id.get);
		msgTextView = (TextView) findViewById(R.id.message);
		
		// 创建所需绑定的远程Service的Intent
		Intent intent = new Intent();
		//"com.aidl.action.AIDL_SERVICE"为远程Service在AndroidManifest.xml中定义的Action
		intent.setAction("com.aidl.action.AIDL_SERVICE");
		bindService(intent, conn, Service.BIND_AUTO_CREATE);
		
		get.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				try{
					// 获取并显示远程Service的状态
					if(remoteService != null){
						msgTextView.append("\n");
						msgTextView.setText(remoteService.getMessageFromServer(callBack));
					}else{
						Toast.makeText(getApplicationContext(), "还没连接成功", Toast.LENGTH_SHORT).show();
					}
				}catch (RemoteException e){
					e.printStackTrace();
				}
			}
		});
	}
	@Override
	public void onDestroy()
	{
		super.onDestroy();
		// 解除绑定
		this.unbindService(conn);
	}
}


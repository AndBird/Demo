package aidl.service;


import com.service.aidl.ClientCallBack;
import com.service.aidl.RemoteMessage;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/*Aidl Client*/
public class MainActivity extends Activity{
	final String TAG = "aidl client";
	
	private Button get;
	private TextView msgTextView;
	private int count = 0;
	
	private RemoteMessage remoteService;
	private ServiceConnection conn = new ServiceConnection(){
		@Override
		public void onServiceConnected(ComponentName name, IBinder service){
			// 获取远程Service的onBind方法返回的对象的代理
			if(service != null){
				//用于将服务端的Binder对象转换为客户端需要的AIDL接口类型的对象
				remoteService = RemoteMessage.Stub.asInterface(service);
				Log.e(TAG, "onServiceConnected succ");
				
				try {
					remoteService.registerListener(clientCallBack);
					//给binder设置死忙代理，当Binder死忙时就可以收到通知
					service.linkToDeath(mDeathRecipient, 0);
				} catch (RemoteException e) {
					e.printStackTrace();
				}
				//判断Binder是否死忙
	            //boolean binderAlive = service.isBinderAlive();
			}else{
				Log.e(TAG, "onServiceConnected fail");
			}
		}
		
		@Override
		public void onServiceDisconnected(ComponentName name){
			remoteService = null;
			Log.e(TAG, "onServiceDisconnected");
		}
	};
	
	
	//private ClientCallBack.Stub callBack = new ClientCallBack.Stub() {
	private ClientCallBack clientCallBack = new ClientCallBack.Stub() {
		@Override
		public String sendMessageToClient(String msg) throws RemoteException {
			// TODO Auto-generated method stub
			final String tString = msg;
			msgTextView.post(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					msgTextView.append("\n");
					msgTextView.append(tString);
				}
			});
			return "client back";
		}
		
		@Override
		public String getMessageFromClient() throws RemoteException {
			// TODO Auto-generated method stub
			count++;
			return "远程Service" + count;
		}
	};
	
	
    private IBinder.DeathRecipient mDeathRecipient = new IBinder.DeathRecipient() {
        @Override
        public void binderDied() {
        	Log.e(TAG,  "binderDied");
            if (remoteService == null) {
                return;
            }
            //移除之前绑定的代理并重新绑定远程服务
            remoteService.asBinder().unlinkToDeath(mDeathRecipient, 0);
            remoteService = null;
            bindService();
        }
    };
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		get = (Button) findViewById(R.id.get);
		msgTextView = (TextView) findViewById(R.id.message);
		
		bindService();
		
		get.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0){
				try{
					// 获取并显示远程Service的状态
					if(remoteService != null){
						msgTextView.append("\n");
						msgTextView.setText(remoteService.getMessageFromServer());
					}else{
						Toast.makeText(getApplicationContext(), "还没连接成功", Toast.LENGTH_SHORT).show();
					}
				}catch (RemoteException e){
					e.printStackTrace();
				}
			}
		});
	}
	
	
	private void bindService(){
		Log.e(TAG, "bindService");
		// 创建所需绑定的远程Service的Intent
		Intent intent = new Intent();
		//intent.setClassName("aidl.service", "aidl.service.AidlService");
		//"com.aidl.action.AIDL_SERVICE"为远程Service在AndroidManifest.xml中定义的Action
		intent.setAction("com.aidl.action.AIDL_SERVICE");
		bindService(intent, conn, Service.BIND_AUTO_CREATE);
	}
	
	
	@Override
	public void onDestroy(){
		super.onDestroy();
		//解除监听接口
        if (remoteService != null && remoteService.asBinder().isBinderAlive()) {
            try {
                remoteService.unregisterListener(clientCallBack);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
		// 解除绑定
        if(conn != null){
        	this.unbindService(conn);
        }
	}
}


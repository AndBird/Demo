﻿package aidl.service;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.Parcel;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;

import com.service.aidl.ClientCallBack;
import com.service.aidl.RemoteMessage;

public class AidlService extends Service{
	
	private final String TAG = "aidl service";
	
	private MsgBinder msgBinder;
	
	private AtomicBoolean serviceStop = new AtomicBoolean(false);
	private RemoteCallbackList<ClientCallBack> listenerList = new RemoteCallbackList<ClientCallBack>();
	
	private Timer timer;
	private String msg = "当前通讯次数:";
	private int count = 0;
	

	 /**
	  * 继承Stub，也就是实现了ICat接口，并实现了IBinder接口
	  * 
	  * */
	public class MsgBinder extends RemoteMessage.Stub{

		@Override
		public String getMessageFromServer() throws RemoteException {
			count++;
			String string = msg + count;
			Log.e(TAG, "remote service msg=" + string);
			return string;
		}

		@Override
		public void registerListener(ClientCallBack clientCallBack)
				throws RemoteException {
			// TODO Auto-generated method stub
			if(listenerList != null){
				listenerList.register(clientCallBack);
			}
		}

		@Override
		public void unregisterListener(ClientCallBack clientCallBack)
				throws RemoteException {
			// TODO Auto-generated method stub
			if(listenerList != null){
				listenerList.unregister(clientCallBack);
			}
		}
		
		@Override
		public boolean onTransact(int code, Parcel data, Parcel reply, int flags)
				throws RemoteException {
			//包名验证
			Log.e(TAG,  "onTransact");
			String packageName = null;
			String[] packages = getPackageManager().getPackagesForUid(getCallingUid());
			if(packages != null && packages.length > 0){
				packageName = packages[0];
			}
			if(packageName == null || !packageName.startsWith("aidl.client") && !packageName.startsWith("aidl.service")){
				Log.e(TAG, "onTransact 拒绝调用:" + packageName);
				return false;
			}
			
			/*权限校验：客户端和服务端是同一个应用的，权限校验在onBind和onTransact中校验都能通过。如果
			 * 客户端和服务端是两个应用时无法在onBind()实现权限校验的问题，此时客户端的权限
			 * 校验可以放在onTransact中校验
			 * */
			int check = checkCallingOrSelfPermission("com.aidl.permission.REMOTE_SERVICE_PERMISSION");
			//int check = checkPermission("com.aidl.permission.REMOTE_SERVICE_PERMISSION", getCallingPid(), getCallingUid());
	        if (check == PackageManager.PERMISSION_DENIED) {
	        	Log.e(TAG, "onTransact permission deny");
	            return false;
	        }
			return super.onTransact(code, data, reply, flags);
		}
	}	
	
	
	@Override
	public void onCreate(){
		super.onCreate();
		Log.e(TAG, "onCreate");
		msgBinder = new MsgBinder();
		
		timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				if(listenerList != null){
					 int n = listenerList.beginBroadcast();
					 try {
					     for (int i = 0; i < n; i++) {
					           ClientCallBack listener = listenerList.getBroadcastItem(i);
					           if (listener != null) {
									String msg = listener.getMessageFromClient();
									Log.e(TAG, "get msg:" + msg);
									String string = "服务端发送:" + msg;
									String s = listener.sendMessageToClient(string);
									Log.e(TAG, "send msg back:" + s);
					           }
					    }
					 } catch (RemoteException e) {
					        e.printStackTrace();
					 }
					 listenerList.finishBroadcast();
				}
				
			}
		}, new Date(), 5000);
	}
	
	@Override
	public IBinder onBind(Intent arg0){
		Log.e(TAG, "onBind");
		/* 返回msgBinder对象:
		 * 1.在绑定本地Service的情况下，该msgBinder对象会直接
		 * 传给客户端的ServiceConnection对象的onServiceConnected方法的第二个参数；
		 * 2.在绑定远程Service的情况下，只将msgBinder对象的代理传给客户端的ServiceConnection对象
		 * 的onServiceConnected方法的第二个参数；
		 */
		
		/*同一个应用的权限校验：onBind()这里只能校验同一个应用多进程权限问题。onBind()是在客户端连接服务端时调用，如果客户端不能在此处通过校验则无发连接到服
		 * 务。如果客户端和服务端是两个应用，则无法在onBind()实现权限校验的功能，这里只能校验同一个应用内的多进程权限。
		 * 两个应用的权限校验应该放置到onTransact()方法中校验
		 * */
	    int check = checkCallingOrSelfPermission("com.aidl.permission.REMOTE_SERVICE_PERMISSION");
        if (check == PackageManager.PERMISSION_DENIED) {
        	Log.e(TAG, "permission deny");
            return null;
        }
		if(msgBinder == null || msgBinder.isBinderAlive()){
             msgBinder = new MsgBinder();
       }
		return msgBinder;
	}
	
	@Override
	public void onDestroy(){
		Log.e(TAG, "onDestroy");
		serviceStop.set(true);
		//销毁回调资源 否则要内存泄露
		if(listenerList != null){
			listenerList.kill();
		}
		super.onDestroy();
		if(timer != null){
			timer.cancel();
			timer = null;
		}
	}
}


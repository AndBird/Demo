package com.andbird.filemanager;

import java.io.File;
import com.andbird.filemanager.EventHandler.FileListAdapter;
import com.andbird.filemanager.R;
import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class FileExplorerActivity extends ListActivity  {
	private static final String TAG = FileExplorerActivity.class.getSimpleName();
	private static FileManager fileManager;
	private static SharedPreferences settings;

	private EventHandler handler;
	private FileListAdapter fileListAdapter;

	private boolean  use_back_key = true;//�Ƿ���Ժ���
	private TextView  path_label;  //��ǰĿ¼·����ʾ
	private TextView  detail_label;
	
	private static String filePathKey;
	private static String fileFilter;//�ļ���׺����
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_file_explorer);
		/*��ȡ�û�����*/
		readSettings();
		initView();
		
	}
	
	private void initView(){
		try {
			handler = new EventHandler(FileExplorerActivity.this, fileManager);
			handler.setTextColor(FileExplorerConfig.dbColor);
			fileListAdapter = handler.new FileListAdapter();

			/*sets the ListAdapter for our ListActivity and
			 *gives our EventHandler class the same adapter
			 */
			handler.setListAdapter(fileListAdapter); 
			setListAdapter(fileListAdapter);
			
			path_label = (TextView)findViewById(R.id.path_label);
			detail_label = (TextView)findViewById(R.id.detail_label);
			path_label.setText(fileManager.getCurrentDir());
			handler.setUpdateLabel(path_label, detail_label);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	@Override
	public void onPause(){
		super.onPause();
	}

	@Override
	public void onDestroy(){
		super.onDestroy();
	}


	@Override
	public void onListItemClick(ListView parent, View view, int position, long id) {
		final String item = handler.getData(position);
		File file = new File(fileManager.getCurrentDir() + "/" + item);
		if (file.isDirectory()) {
			Utils.printLog(TAG, "click directory path:" + file.getAbsolutePath());
			if(file.canRead()) {
				handler.updateDirectory(fileManager.getNextDir(file.getAbsolutePath(), true));
				Utils.printLog(TAG, "Current Dir:"+fileManager.getCurrentDir());
				Utils.printLog(TAG, "Path Stack:"+fileManager.path_stack);
				path_label.setText(fileManager.getCurrentDir());

				/*set back button switch to true (this will be better implemented later)*/
				if(!use_back_key){
					use_back_key = true;
				}
			}else {
				Toast.makeText(this, R.string.cantreadfolder, Toast.LENGTH_SHORT).show();
			}
		}else{
			//����ѡ����
//			Intent in = new Intent(MainActivity.this, DirectoryInfo.class);
//			in.putExtra("PATH_NAME", file.getAbsolutePath());
//			startActivity(in);
			
			String filePath = file.getAbsolutePath();
			if(!TextUtils.isEmpty(fileFilter) && !filePath.endsWith(fileFilter)){
				Toast.makeText(getApplicationContext(), "��ѡ����ʵ��ļ�", Toast.LENGTH_SHORT).show();
				return;
			}
			Intent intent = new Intent();
			intent.putExtra(filePathKey, filePath);
			setResult(RESULT_OK, intent);
			finish();
		}
	}
	

	@Override
	protected void onStop(){
		super.onStop();
		//�������²鿴·��
		writeLastOpenedDirectory(fileManager.getCurrentDir());
	}



	/*
	 * (non-Javadoc)
	 * This will check if the user is at root directory. If so, if they press back
	 * again, it will close the application. 
	 * @see android.app.Activity#onKeyDown(int, android.view.KeyEvent)
	 */
	@Override
	public boolean onKeyDown(int keycode, KeyEvent event){
		String current = fileManager.getCurrentDir();
       if(keycode == KeyEvent.KEYCODE_BACK && use_back_key && !current.equals("/")) {
			handler.updateDirectory(fileManager.getPreviousDir());
			path_label.setText(fileManager.getCurrentDir());
			return true;
		} else if (keycode == KeyEvent.KEYCODE_BACK && use_back_key && current.equals("/")) {
			Toast.makeText(FileExplorerActivity.this, R.string.pressbackagaintoquit, Toast.LENGTH_SHORT).show();
			use_back_key = false;
			path_label.setText(fileManager.getCurrentDir());
			return false;
		} else if (keycode == KeyEvent.KEYCODE_BACK && !use_back_key && current.equals("/")) {
			finish();
			return false;
		}
		return false;
	}


	//��ȡ�û�����
	public void readSettings() {
		try {
			settings = getSharedPreferences(FileExplorerConfig.USER_PREFS_NAME, MODE_PRIVATE);
			//FileExplorerConfig.dbLastOpenDir  = settings.getString(FileExplorerConfig.PREFS_LASTOPENDIR, FileExplorerConfig.dbLastOpenDir);
			//FileExplorerConfig.dbDefaultHome = settings.getString(FileExplorerConfig.PREFS_DEFAULTHOME, FileExplorerConfig.dbDefaultHome);
			fileManager = new FileManager();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//�����û�����
	public void writeSettings(boolean check_hidden, int color, int sort, String defaulthome, boolean advdebug){
		try {
			SharedPreferences.Editor editor = settings.edit();
			editor.putString(FileExplorerConfig.PREFS_DEFAULTHOME, defaulthome);
			editor.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//�������һ�β鿴��Ŀ¼
	public void writeLastOpenedDirectory(String currentOpenedDirectory) {
		try {
			SharedPreferences settings = getSharedPreferences(FileExplorerConfig.USER_PREFS_NAME, MODE_PRIVATE);
			SharedPreferences.Editor editor = settings.edit();
			if (currentOpenedDirectory == null) {
				currentOpenedDirectory = FileExplorerConfig.getSdcardPath();
			}
			Utils.printLog(TAG, "OnStop fileManager.getCurrentDir:"+currentOpenedDirectory);
			editor.putString(FileExplorerConfig.PREFS_LASTOPENDIR, currentOpenedDirectory); 
			editor.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ˵��
	 * @param filePathKey : �ļ�·���ش�key
	 * @param fileFilter  : �ļ���׺����
	 * 
	 * */
	public static void startActivityForResultSelf(Activity activity, int requestCode, String filePathKey, String fileFilter){
		try {
			Intent in = new Intent(activity, FileExplorerActivity.class);
			FileExplorerActivity.filePathKey = filePathKey;
			FileExplorerActivity.fileFilter = fileFilter;
			activity.startActivityForResult(in, requestCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

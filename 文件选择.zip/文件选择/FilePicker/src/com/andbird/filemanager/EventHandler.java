package com.andbird.filemanager;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import com.andbird.filemanager.R;
import android.content.Context;
import android.graphics.Color;
import android.text.format.Formatter;
import android.view.View.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class EventHandler{
	private static final String TAG = EventHandler.class.getSimpleName();
	private final Context context;
	private final FileManager fileManager;
	private FileListAdapter fileListAdapter;
	private int color = Color.WHITE;

	//the list used to feed info into the array adapter and when multi-select is on
	private ArrayList<String> fileDataList;//�ļ��б���Ϣ
	private ArrayList<String> multiselect_data;//��ѡ�б�
	private TextView path_label;//��ǰ·����ʾView
	private SimpleDateFormat simpleDateFormat;

	public EventHandler(Context context, final FileManager manager) {
		this.context = context;
		fileManager 	 = manager;
		fileDataList  = new ArrayList<String>(fileManager.getLastOpenedDir());
		simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	}

	public void setListAdapter(FileListAdapter adapter) {
		fileListAdapter = adapter;
	}

	/**
	 * This method is called from the Main activity and is passed
	 * the TextView that should be updated as the directory changes
	 * so the user knows which folder they are in.
	 * 
	 * @param path	The label to update as the directory changes
	 * @param label	the label to update information
	 */
	public void setUpdateLabel(TextView path, TextView label) {
		path_label = path;
		path_label.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				String currentDir = fileManager.getCurrentDir();
				if (currentDir != "/") {
					updateDirectory(fileManager.getPreviousDir());
					if(path_label != null)
						path_label.setText(fileManager.getCurrentDir());
				}
			}
		});
	}


	public void setTextColor(int color) {
		this.color = color;
	}


	public String getData(int position) {
		if(position > fileDataList.size() - 1 || position < 0)
			return null;
		return fileDataList.get(position);
	}

	/**
	 * called to update the file contents as the user navigates there
	 * phones file system. 
	 * 
	 * @param content	an ArrayList of the file/folders in the current directory.
	 */
	public void updateDirectory(ArrayList<String> content) {	
		if(!fileDataList.isEmpty())
			fileDataList.clear();

		for(String data : content)
			fileDataList.add(data);

		fileListAdapter.notifyDataSetChanged();
	}

	private static class ViewHolder {
		TextView fileNameView;
		TextView timeView;
		TextView bottomView;
		ImageView icon;
		ImageView mSelect;	//multi-select check mark icon
	}


	public class FileListAdapter extends ArrayAdapter<String> {
		private final int KB = 1024;
		private final int MB = KB * KB;
		private final int GB = MB * KB;
		private String display_size;
		private ArrayList<Integer> positions;

		public FileListAdapter() {
			super(context, R.layout.listview_file_explorer_tablerow, fileDataList);
		}

		public void addMultiPosition(int index, String path) {
			if(positions == null)
				positions = new ArrayList<Integer>();

			if(multiselect_data == null) {
				positions.add(index);
				add_multiSelect_file(path);

			} else if(multiselect_data.contains(path)) {
				if(positions.contains(index))
					positions.remove(new Integer(index));

				multiselect_data.remove(path);

			} else {
				positions.add(index);
				add_multiSelect_file(path);
			}

			notifyDataSetChanged();
		}

		public String getFilePermissions(File file) {
			String per = "-";

			if(file.isDirectory())
				per += "d";
			if(file.canRead())
				per += "r";
			if(file.canWrite())
				per += "w";

			return per;
		}


		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			int num_items = 0;
			String temp = fileManager.getCurrentDir();
			File file = new File(temp + "/" + fileDataList.get(position));
			String[] list = file.list();

			if(list != null){
				num_items = list.length;
			}

			if(convertView == null || convertView.getTag() == null) {
				LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = inflater.inflate(R.layout.listview_file_explorer_tablerow, parent, false);

				holder = new ViewHolder();
				holder.fileNameView = (TextView)convertView.findViewById(R.id.fileName);
				holder.timeView = (TextView)convertView.findViewById(R.id.timeView);
				holder.bottomView = (TextView)convertView.findViewById(R.id.bottom_view);
				holder.icon = (ImageView)convertView.findViewById(R.id.row_image);
				holder.mSelect = (ImageView)convertView.findViewById(R.id.multiselect_icon);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder)convertView.getTag();
			}

			if(positions != null && positions.contains(position)){
				holder.mSelect.setVisibility(ImageView.VISIBLE);
			}else{
				holder.mSelect.setVisibility(ImageView.GONE);
			}
			
			//����������ɫ
			holder.fileNameView.setTextColor(color);
			//holder.timeView.setTextColor(color);
			holder.bottomView.setTextColor(color);

			holder.fileNameView.setText(file.getName());
			holder.timeView.setText(simpleDateFormat.format(new Date(file.lastModified())));
			//����ͼ��
			if(file.isDirectory()){
				holder.icon.setImageResource(R.drawable.folder);
			} else if(file.isFile()  ) {
				String ext = file.toString();
				String sub_ext = ext.substring(ext.lastIndexOf(".") + 1);
				if (Arrays.asList(FileExplorerConfig.supportedAudioFileFormats).contains(sub_ext.toLowerCase())){
					holder.icon.setImageResource(R.drawable.music);
				}else if(Arrays.asList(FileExplorerConfig.supportedVideoFileFormats).contains(sub_ext.toLowerCase())){
					holder.icon.setImageResource(R.drawable.movies);
				}else if(ext.endsWith(".apk")){
					holder.icon.setImageResource(R.drawable.apk_icon);
				}else{
					holder.icon.setImageResource(R.drawable.file_icon);
				}
			}

			if(file.isFile()){
				//�ļ�ֱ����ʾ��С
				long size = file.length();
				display_size = Formatter.formatFileSize(context, size);
				/*if (size > GB){
					display_size = String.format("%.2f Gb ", (double)size / GB);
				else if (size < GB && size > MB)
					display_size = String.format("%.2f Mb ", (double)size / MB);
				else if (size < MB && size > KB)
					display_size = String.format("%.2f Kb ", (double)size/ KB);
				else
					display_size = String.format("%.2f bytes ", (double)size);
				 */
				if(file.isHidden()){
					holder.bottomView.setText("(hidden) | " + display_size );
				}else{
					holder.bottomView.setText(display_size );
				}
			} else {
				if(file.isHidden()){
					holder.bottomView.setText("(hidden) | " + num_items + " �� ");
				}else{
					holder.bottomView.setText(num_items + " �� ");
				}
			}
			return convertView;
		}

		private void add_multiSelect_file(String src) {
			if(multiselect_data == null){
				multiselect_data = new ArrayList<String>();
			}
			multiselect_data.add(src);
		}
	}
}

package com.andbird.filemanager;

import java.io.File;

import android.graphics.Color;
import android.os.Environment;

public class FileExplorerConfig {
	private static final String TAG = FileExplorerConfig.class.getSimpleName();
	public static String defaultDir = "/sdcard";

	public static final String USER_PREFS_NAME = "user_FileExplorer_setting";	//user preference file name
	public static final String PREFS_LASTOPENDIR = "lastopeneddir"; //����򿪵�Ŀ¼
	public static final String PREFS_DEFAULTHOME = "defaulthomedir";//Ĭ��
	public static final String PREFS_SORT = "sort";//��������

	public static boolean show_hide_file  = false; // Show/Hide hidden folders
	public static int  dbColor = Color.BLACK; //������ɫ
	public static int  dbSort  = FileManager.SORT_ALPHA;//��������
	public static String  dbLastOpenDir  = getSdcardPath(); 
	public static String  dbDefaultHome	 = getSdcardPath();
	
	
	public static void setSortType(int type) {
		FileExplorerConfig.dbSort = type;
	}

	public static void setDefaultHome(String value){
		Utils.printLog(TAG,  "setDefault Home value:"+value);
		if(value != null) {
			File file = new File(value);
			//if (value.contains("/")){
			if ( (file.isDirectory()&& file.exists()) ){
				FileExplorerConfig.dbDefaultHome = value;	
			} else {
				FileExplorerConfig.dbDefaultHome = defaultDir; //"/sdcard";
			}
		}
	}


	public static void setLastOpenDir(String value){
		Utils.printLog(TAG, "setLastOpendir value:"+value);
		if (value.contains("/")){
			FileExplorerConfig.dbLastOpenDir = value;	
		} else {
			FileExplorerConfig.dbLastOpenDir = defaultDir; //"/sdcard";
		}
	}


	public static String getSdcardPath(){
		String sdcardPath = Environment.getExternalStorageDirectory().getAbsolutePath();
		Utils.printLog(TAG,  "sdcardPath:"+sdcardPath);
		return sdcardPath;
	}
	
	
	public static final String supportedVideoFileFormats[] = 
		{   "mp4","wmv","avi","mkv","dv",
		"rm","mpg","mpeg","flv","divx",
		"swf","dat","h264","h263","h261",
		"3gp","3gpp","asf","mov","m4v", "ogv",
		"vob", "vstream", "ts", "webm",
		//to verify below file formats - reference vlc
		"vro", "tts", "tod", "rmvb", "rec", "ps", "ogx",
		"ogm", "nuv", "nsv", "mxf", "mts", "mpv2", "mpeg1", "mpeg2", "mpeg4",
		"mpe", "mp4v", "mp2v", "mp2", "m2ts",
		"m2t", "m2v", "m1v", "amv", "3gp2"
		//"ttf"
		};

	public static final String supportedAudioFileFormats[] = {   "mp3","wma","ogg","mp2","flac",
			"aac","ac3","amr","pcm","wav",
			"au","aiff","3g2","m4a", "astream",
		//to verify below file formats - reference vlc
			"a52", "adt", "adts", "aif", "aifc",
			"aob", "ape", "awb", "dts", "cda", "it", "m4p",
			"mid", "mka", "mlp", "mod", "mp1", "mp2", "mpc",
			"oga", "oma", "rmi", "s3m", "spx", "tta",
			"voc", "vqf", "w64", "wv", "xa", "xm"
		};		

	public static final String supportedFontFileType[] = {"ttf"};
	public static final String supportedImageFileFormats[] = {"gif","bmp","png","jpg"};
	public static final String supportedAudioStreamFileFormats[] = {"astream"};
	public static final String supportedVideoStreamFileFormats[] = {"vstream"};
	public static String supportedFileFormats[] =concat(supportedAudioFileFormats, supportedVideoFileFormats, supportedFontFileType);

	/**
	 * This method is used to concat 2 string arrays to one
	 * @param A
	 * First string Array
	 * @param B
	 * Second string Array
	 * @return
	 * Concatenated string Array of First and Second
	 */
	public static String[] concat(String[] A, String[] B, String[] C) {
		String[] temp= new String[A.length+B.length+C.length];
		System.arraycopy(A, 0, temp, 0, A.length);
		System.arraycopy(B, 0, temp, A.length, B.length);
		System.arraycopy(C, 0, temp, A.length+B.length, C.length);
		return temp;
	}
}

/** Automatically generated file. DO NOT MODIFY */
package com.andbird.filemanager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
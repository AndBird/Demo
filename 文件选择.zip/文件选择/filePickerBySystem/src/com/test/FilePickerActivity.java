package com.test;

import com.file.picker.R;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

public class FilePickerActivity extends Activity{
	
	private final int OPEN_FILE_CODE = 1001;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		findViewById(R.id.button).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openFileSelector();
			}
		});
	}
	
	private void openFileSelector() {
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType("*/*");
		
		//if(getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null){
			try {
				startActivityForResult(intent, OPEN_FILE_CODE);
			} catch (ActivityNotFoundException e) {
				e.printStackTrace();
			}
		//}
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OPEN_FILE_CODE && resultCode == Activity.RESULT_OK) {

            String path = FilePathHelper.getPath(getApplicationContext(), data.getData());
            
            Log.e("file pick", "file path=" + data.getData().toString());
            Log.e("file pick", "file path=" + path);
        }
    }

}

/** Automatically generated file. DO NOT MODIFY */
package com.file.picker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package com.db.demo;

import java.io.File;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.os.Environment;
import android.util.Log;


public class WordDb extends SQLiteOpenHelper{
	private static final String TAG = WordDb.class.getSimpleName();
	private static int DB_VERSION = 1;//���ݿ�汾��
	private static final String DB_WORD_TABLE = "words";//����1
	private static final String DB_NEW_WORD_TABLE = "new_words";//����2
	public static final String COLUMN_WORD = "word";//��������
	public static final String COLUMN_YINBIAO = "yinbiao";
	public static final String COLUMN_TRANSLATE = "translate";
	public static final String COLUMN_GRADE = "grade";
	public static final String COLUMN_UNIT = "unit";
	public static final String COLUMN_FILENAME = "fileName";
	public static final String COLUMN_START = "start";//���
	public static final String COLUMN_END = "end";
	
	//������
	private final String CREATE_WORD_TABLE_SQL = "create table if not exists " 
											+ DB_WORD_TABLE
											+ "(_id integer primary key autoincrement,"
											+ COLUMN_WORD + " text, "
											+ COLUMN_YINBIAO + " text, "
											+ COLUMN_TRANSLATE + " text, "
											+ COLUMN_GRADE + " integer, "
											+ COLUMN_UNIT + " text, "
											+ COLUMN_FILENAME + " text, "
											+ COLUMN_START + " integer, "
											+ COLUMN_END + " integer "
											+ " ); ";
	
	private final String CREATE_NEW_WORD_TABLE_SQL = "create table if not exists " 
												+ DB_NEW_WORD_TABLE
												+ "(_id integer primary key autoincrement,"
												+ COLUMN_WORD + " text, "
												+ COLUMN_YINBIAO + " text, "
												+ COLUMN_TRANSLATE + " text, "
												+ COLUMN_GRADE + " integer, "
												+ COLUMN_UNIT + " text, "
												+ COLUMN_FILENAME + " text, "
												+ COLUMN_START + " integer, "
												+ COLUMN_END + " integer "
												+ " ); ";
	
	private static String dbName = Environment.getExternalStorageDirectory() + File.separator +  "dbTest" + File.separator + "word.db";
	
	
	public WordDb(Context context, String name, CursorFactory factory, int version) {
		//super(context, name, factory, version);
		super(context, dbName, factory, version);
		this.DB_VERSION = version;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		Log.i("MyDownDBHelper", "create table");
		//db.execSQL(CREATE_TABLE_SQL);
		onUpgrade(db, 0, this.DB_VERSION);
	}


	/*ע��汾������������onUpgrade��ͬʱע�ⲻͬ�汾�ŵļ���*/
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		for (int j = oldVersion + 1; j <= newVersion; j++) {//����for���������� �ò�ͬ�û��Ĳ�ͬ�汾�����ݿⶼ���Լ�������������
			upgradeTo(db, j);
		}
	}

	private void upgradeTo(SQLiteDatabase db, int version) {
		try {
			switch (version) {
				case 1://���������汾1
					db.execSQL(CREATE_WORD_TABLE_SQL);
					db.execSQL(CREATE_NEW_WORD_TABLE_SQL);
					break;
                default:
                    break;
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	private void addColumn(SQLiteDatabase db, String dbTable, String columnName, String columnDefinition) {
		db.execSQL("ALTER TABLE " + dbTable + " ADD COLUMN " + columnName + " " + columnDefinition);
	}
	
	public static long insertWordToWord(SQLiteDatabase db, ContentValues values){
		return db.insert(DB_WORD_TABLE, null, values);
	}
	
	public static long insertWordToNewWord(SQLiteDatabase db, ContentValues values){
		return db.insert(DB_NEW_WORD_TABLE, null, values);
	}
}

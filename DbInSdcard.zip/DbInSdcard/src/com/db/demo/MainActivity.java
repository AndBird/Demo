package com.db.demo;


import com.example.dbinsdcard.R;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.os.Environment;

public class MainActivity extends Activity{
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		WordDb wordDb = new WordDb(getApplicationContext(), Environment.getExternalStorageDirectory() + "/db.db", null, 1);
		
		ContentValues values = new ContentValues();
		values.put(WordDb.COLUMN_WORD, "lineLyric");
		values.put(WordDb.COLUMN_YINBIAO,"YinBiao");
		values.put(WordDb.COLUMN_TRANSLATE, "Translate");
		values.put(WordDb.COLUMN_GRADE, "1");
		values.put(WordDb.COLUMN_UNIT, "unit");
		values.put(WordDb.COLUMN_START, "123");
		values.put(WordDb.COLUMN_END,  "234");
		values.put(WordDb.COLUMN_FILENAME,  "fileName");
		
		WordDb.insertWordToWord(wordDb.getWritableDatabase(), values);
	
	}
}
